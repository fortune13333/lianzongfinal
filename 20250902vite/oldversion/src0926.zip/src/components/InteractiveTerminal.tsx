import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import { toast } from 'react-hot-toast';
import { useStore } from '../store/useStore';
import { createApiUrl } from '../utils/apiUtils';
import Loader from './Loader';
import ProgressToast from './ProgressToast';
import { PlusIcon, TrashIcon } from './AIIcons';

interface InteractiveTerminalProps {
  sessionId: string;
}

const InteractiveTerminal: React.FC<InteractiveTerminalProps> = ({ sessionId }) => {
    const { selectedDevice, currentUser, settings, fetchData } = useStore(state => ({
        selectedDevice: state.selectedDevice!,
        currentUser: state.currentUser!,
        settings: state.settings,
        fetchData: state.fetchData
    }));

    const terminalRef = useRef<HTMLDivElement>(null);
    const termRef = useRef<Terminal | null>(null);
    const fitAddonRef = useRef<FitAddon | null>(null);
    const wsRef = useRef<WebSocket | null>(null);

    const [status, setStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
    const [fontSize, setFontSize] = useState(16);
    const [isSaving, setIsSaving] = useState(false);

    // Terminal Initialization
    useEffect(() => {
        if (terminalRef.current && !termRef.current) {
            const term = new Terminal({
                cursorBlink: true,
                convertEol: true,
                fontFamily: 'Menlo, Monaco, "Courier New", monospace',
                fontSize: fontSize,
                theme: {
                    background: '#09090b', // bg-bg-950
                    foreground: '#d4d4d8', // text-text-300
                    cursor: 'rgb(var(--color-primary-400))',
                    selectionBackground: '#3f3f46', // bg-bg-700
                },
                allowProposedApi: true,
            });
            const fitAddon = new FitAddon();
            
            termRef.current = term;
            fitAddonRef.current = fitAddon;
            
            term.loadAddon(fitAddon);
            term.open(terminalRef.current);
            fitAddon.fit();

            term.onData(data => {
                if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                    wsRef.current.send(data);
                }
            });
        }
        
        const resizeObserver = new ResizeObserver(() => {
            fitAddonRef.current?.fit();
        });
        if (terminalRef.current) {
            resizeObserver.observe(terminalRef.current);
        }

        return () => {
            resizeObserver.disconnect();
            wsRef.current?.close();
            // Do not dispose terminal on unmount to preserve its content
        };
    }, []);

    // Handle Font Size Changes
    useEffect(() => {
        if (termRef.current) {
            termRef.current.options.fontSize = fontSize;
            fitAddonRef.current?.fit();
        }
    }, [fontSize]);

    const connect = useCallback(() => {
        if (wsRef.current || !settings.agentApiUrl || !selectedDevice) return;
        
        setStatus('connecting');
        termRef.current?.reset();
        termRef.current?.writeln('\x1b[1;33m正在连接到设备...\x1b[0m');

        const wsUrl = createApiUrl(settings.agentApiUrl, `/ws/${selectedDevice.id}/${sessionId}`).replace(/^http/, 'ws');
        
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
            setStatus('connected');
            termRef.current?.focus();
        };

        ws.onmessage = (event) => {
            termRef.current?.write(event.data);
        };

        ws.onerror = (event) => {
            console.error("WebSocket Error:", event);
            setStatus('error');
            termRef.current?.writeln('\r\n\x1b[1;31mWebSocket 连接错误。请检查代理服务和网络连接。\x1b[0m');
        };

        ws.onclose = (event) => {
            setStatus('disconnected');
            if (!event.wasClean) {
                termRef.current?.writeln(`\r\n\x1b[1;31m连接意外断开 (代码: ${event.code})。请重试。\x1b[0m`);
            } else {
                termRef.current?.writeln('\r\n\x1b[1;34m连接已关闭。\x1b[0m');
            }
            wsRef.current = null;
        };
    }, [selectedDevice, sessionId, settings.agentApiUrl]);

    const disconnect = useCallback(() => {
        wsRef.current?.close();
    }, []);

    const handleSaveSession = async () => {
        setIsSaving(true);
        const toastId = 'save-session-toast';

        try {
            toast.custom((t) => (
                <ProgressToast t={t} title="正在保存会话..." progress={10} message="[进行中] 正在保存..." />
            ), { id: toastId, duration: Infinity });

            toast.custom((t) => (
                <ProgressToast t={t} title="正在保存会话..." progress={33} message="[✔️] 1. 从设备获取最新配置" />
            ), { id: toastId });
            
            const url = createApiUrl(settings.agentApiUrl!, `/api/sessions/${selectedDevice.id}/save`);
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ operator: currentUser.username, config: '' }),
            });
            
            if (!response.ok) {
                 const errorData = await response.json().catch(() => ({'detail': '代理返回了未知错误。'}));
                 throw new Error(errorData.detail);
            }

            toast.custom((t) => (
                <ProgressToast t={t} title="正在保存会话..." progress={66} message="[..] 2. AI 智能审计分析" />
            ), { id: toastId });
            
            await new Promise(res => setTimeout(res, 1500)); 

            await fetchData(true);
            
            toast.success('会话已成功保存并记录上链！', { id: toastId });
        } catch (error) {
            const msg = error instanceof Error ? error.message : '未知错误。';
            toast.error(`保存失败: ${msg}`, { id: toastId });
        } finally {
            setIsSaving(false);
        }
    };
    
    const isConnected = status === 'connected';

    return (
        <div className="bg-bg-950 rounded-lg shadow-lg flex flex-col h-[65vh] border border-bg-800">
            <div className="flex-shrink-0 flex items-center justify-between p-2 border-b border-bg-800 bg-bg-900/70 rounded-t-lg">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <span className={`h-2.5 w-2.5 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
                        <span className="text-xs font-semibold text-text-300">{isConnected ? '已连接' : '已断开'}</span>
                    </div>
                    {!isConnected ? (
                        <button onClick={connect} disabled={status === 'connecting'} className="text-sm bg-primary-600 hover:bg-primary-700 text-white font-bold py-1 px-3 rounded-md transition-colors disabled:opacity-50">
                            {status === 'connecting' ? '连接中...' : '连接 SSH'}
                        </button>
                    ) : (
                        <button onClick={disconnect} className="text-sm bg-bg-700 hover:bg-bg-600 text-text-200 font-bold py-1 px-3 rounded-md transition-colors">
                            断开连接
                        </button>
                    )}
                </div>
                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1">
                        <span className="text-xs text-text-400">字体:</span>
                        <button onClick={() => setFontSize(s => s - 1)} disabled={fontSize <= 10} className="p-1 rounded-md hover:bg-bg-700 disabled:opacity-50" aria-label="减小字体"><TrashIcon className="h-4 w-4" /></button>
                        <button onClick={() => setFontSize(s => s + 1)} disabled={fontSize >= 24} className="p-1 rounded-md hover:bg-bg-700 disabled:opacity-50" aria-label="增大字体"><PlusIcon className="h-4 w-4" /></button>
                    </div>
                    <button 
                        onClick={handleSaveSession}
                        disabled={isSaving || !isConnected}
                        className="text-sm bg-primary-600 hover:bg-primary-700 text-white font-bold py-1 px-3 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed w-40 flex justify-center"
                    >
                        {isSaving ? <Loader /> : '保存会话并审计'}
                    </button>
                </div>
            </div>
            <div ref={terminalRef} className="flex-grow w-full h-full p-2 overflow-hidden" />
        </div>
    );
};

export default InteractiveTerminal;
