import { GoogleGenAI } from "@google/genai";
import { AppSettings, Device } from '../types';
import { AppError } from "../utils/errors";

let aiInstance: GoogleGenAI | null = null;

export const checkKeyAvailability = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new AppError( "Google Gemini API key is not configured.", 'ERR_GEMINI_API_KEY_MISSING');
    }
};

const getAiClient = (): GoogleGenAI => {
    if (aiInstance) return aiInstance;
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error("Google Gemini API key is not configured. Please set it up in your environment configuration.");
    }
    aiInstance = new GoogleGenAI({ apiKey });
    return aiInstance;
};

// NOTE: The primary analysis function (analyzeConfigurationChange) has been moved to the agent backend (agent.py).
// The frontend's role is now to submit the raw configuration, and the agent orchestrates all AI interactions.
// The functions below are for direct, user-initiated AI features on the client-side.

const generateConfigFromPrompt = async (
  userInput: string,
  deviceType: Device['type'],
  currentConfig: string,
  settings: AppSettings
): Promise<string> => {
    if (!settings.ai.commandGeneration.enabled) {
        throw new Error('AI 命令生成功能已被禁用。');
    }
    const { apiUrl } = settings.ai.commandGeneration;
    
    const syntaxType = {
        'Router': 'Cisco IOS style',
        'Switch': 'Cisco IOS style',
        'Firewall': 'Cisco ASA style'
    }[deviceType];
    
    if (apiUrl) {
        console.log("Generating config with custom command generation API...");
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userInput, deviceType, currentConfig, syntaxType }),
            });
            if (!response.ok) throw new Error(`Custom API failed with status: ${response.status}`);
            const data = await response.json();
            return data.commands || '';
        } catch (error) {
            console.error("Custom command generation API call failed:", error);
            const msg = error instanceof Error ? error.message : "An unknown error occurred.";
            throw new Error(`自定义 AI 接口调用失败: ${msg}`);
        }
    }

    const prompt = `
    You are an expert network configuration assistant. The target device uses ${syntaxType} syntax.
    The user wants to achieve: "${userInput}".
    Current running configuration for context:
    ---
    ${currentConfig}
    ---
    Generate ONLY the necessary configuration commands. Do not include explanations, intro phrases, or markdown. Output only raw command lines.
    `;

    try {
        const ai = getAiClient();
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        return response.text?.trim() ?? '';
    } catch (error) {
        console.error("Gemini config generation failed:", error);
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred with the AI model.";
        throw new Error(`AI command generation failed: ${errorMessage}`);
    }
};

const checkConfiguration = async (
    config: string,
    deviceType: Device['type'],
    settings: AppSettings
): Promise<string> => {
    if (!settings.ai.configCheck.enabled) {
        throw new Error('AI 配置体检功能已被禁用。');
    }
    const { apiUrl } = settings.ai.configCheck;

    const syntaxType = {
        'Router': 'Cisco IOS style',
        'Switch': 'Cisco IOS style',
        'Firewall': 'Cisco ASA style'
    }[deviceType];

    if (apiUrl) {
        console.log("Checking config with custom check API...");
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ config, deviceType, syntaxType }),
            });
            if (!response.ok) throw new Error(`Custom API failed with status: ${response.status}`);
            const data = await response.json();
            return data.report || '自定义接口未返回报告。';
        } catch (error) {
            console.error("Custom config check API call failed:", error);
            const msg = error instanceof Error ? error.message : "An unknown error occurred.";
            throw new Error(`自定义 AI 接口调用失败: ${msg}`);
        }
    }

    const prompt = `
    You are an expert network security auditor. The device uses ${syntaxType} syntax.
    Analyze this configuration. Your task is to:
    1. Identify security vulnerabilities.
    2. Check for best practice violations.
    3. Find logical errors.
    4. Provide actionable recommendations using bullet points.
    If no issues are found, state that the configuration appears solid.
    Provide the response as a single block of text in Simplified Chinese. Do not use markdown.
    Configuration to analyze:
    ---
    ${config}
    ---
    `;

    try {
        const ai = getAiClient();
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        return response.text?.trim() ?? '';
    } catch (error) {
        console.error("Gemini config check failed:", error);
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred with the AI model.";
        throw new Error(`AI config check failed: ${errorMessage}`);
    }
};

export const geminiService = {
  checkKeyAvailability,
  generateConfigFromPrompt,
  checkConfiguration,
};
