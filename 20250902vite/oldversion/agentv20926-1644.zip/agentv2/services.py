# services.py - Business logic layer for the ChainTrace Agent.
# This file sits between the API routes and the database CRUD operations.
# Note: This version is made compatible with the JSON-based data model used by api_routes.py.

import logging
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional, cast
from netmiko import ConnectHandler, NetmikoBaseException # type: ignore
from netmiko.exceptions import NetmikoAuthenticationException # type: ignore
from fastapi import HTTPException
import json

# Import from our own refactored modules
from core import calculate_block_hash, config, genai, SubmissionPayload, RollbackPayload, BlockDict, BlockDataDict, ComplianceReportDict

# --- Simulation Mode Check ---
def is_simulation_mode() -> bool:
    """
    Checks if the agent is in simulation mode by looking for SIM_USER in any credentials section.
    """
    if not config:
        return False
    for section in config.sections():
        if section.lower().startswith('credentials') and config.get(section, 'username', fallback='').upper() == 'SIM_USER':
            logging.info("Simulation mode is ACTIVE because SIM_USER was found.")
            return True
    return False

# --- Authorization Service ---
def verify_admin(data: Dict[str, Any], actor_username: str) -> None:
    """Verifies if the acting user has admin privileges based on the provided data dictionary."""
    users: List[Dict[str, Any]] = data.get("users", [])
    actor = next((u for u in users if u.get("username") == actor_username), None)
    if not actor or actor.get("role") != "admin":
        logging.warning(f"Authorization failed for user '{actor_username}'. Admin role required.")
        raise HTTPException(
            status_code=403,
            detail="Permission denied: Administrator role required."
        )

# --- Session Management for Collaborative View ---
# This remains in-memory as it's ephemeral session data.
ACTIVE_SESSIONS: Dict[str, Dict[str, str]] = {}

def get_sessions_for_device(device_id: str) -> List[Dict[str, str]]:
    device_sessions = ACTIVE_SESSIONS.get(device_id, {})
    return [{"username": u, "sessionId": s} for s, u in device_sessions.items()]

def join_session(device_id: str, username: str, session_id: str) -> None:
    if device_id not in ACTIVE_SESSIONS:
        ACTIVE_SESSIONS[device_id] = {}
    ACTIVE_SESSIONS[device_id][session_id] = username
    logging.info(f"User '{username}' joined session for device '{device_id}' (session: {session_id}).")

def leave_session(device_id: str, session_id: str) -> None:
    if device_id in ACTIVE_SESSIONS and session_id in ACTIVE_SESSIONS[device_id]:
        username = ACTIVE_SESSIONS[device_id].pop(session_id)
        logging.info(f"User '{username}' left session for device '{device_id}' (session: {session_id}).")


# --- AI Service Helpers ---
def _handle_ai_exception(e: Exception) -> None:
    """Centralized handler for AI-related exceptions."""
    logging.error(f"Gemini AI operation failed: {e}")
    if "User location is not supported" in str(e):
        raise HTTPException(
            status_code=403,
            detail="AI analysis failed: The AI service is not available in your region. Please use a VPN or proxy."
        )
    raise HTTPException(
        status_code=504,
        detail=f"AI analysis timed out or failed. Please check your network and API key. Error: {e}"
    )

def _run_compliance_audit(policies: List[Dict[str, Any]], previous_config: str, new_config: str) -> Optional[ComplianceReportDict]:
    """Performs compliance audit against enabled policies."""
    if not genai:
        return {"overall_status": "passed", "results": [], "details": "AI service disabled"}

    enabled_policies = [p for p in policies if p.get('enabled')]
    if not enabled_policies:
        return {"overall_status": "passed", "results": []}

    try:
        model = genai.GenerativeModel('gemini-2.5-flash')
        policy_texts = "\n".join([f"- {p['name']}: {p['rule']}" for p in enabled_policies])
        prompt = (
            "You are a network compliance auditor. Analyze the new config against the old one "
            "based on the following policies. For each policy, determine if it passed or failed and provide details. "
            "Output a JSON object with keys: 'overall_status' ('passed' or 'failed') and 'results' "
            f"(an array of objects, each with 'policy_id', 'policy_name', 'status', 'details').\n\n"
            f"Policies:\n{policy_texts}\n\n"
            f"Old Config:\n```\n{previous_config}\n```\n"
            f"New Config:\n```\n{new_config}\n```"
        )
        
        response = model.generate_content(prompt)
        cleaned_text = response.text.strip().replace('```json', '').replace('```', '')
        report: ComplianceReportDict = json.loads(cleaned_text)

        if report.get('overall_status') == 'failed':
            failed_policies = [
                res['policy_name'] for res in report.get('results', []) if res.get('status') == 'failed'
            ]
            fail_reason = f"Configuration violates compliance policies: {', '.join(failed_policies)}"
            raise HTTPException(status_code=400, detail=fail_reason)
        
        return report
    except HTTPException as e:
        raise e # Re-raise the specific compliance failure
    except Exception as e:
        _handle_ai_exception(e)
        return None 

def _run_ai_analysis(previous_config: str, new_config: str, change_description: str = "") -> Dict[str, Any]:
    """Performs standard AI analysis for summary, diff, etc."""
    if not genai:
        raise HTTPException(status_code=503, detail="Gemini AI service is not configured or available.")

    try:
        model = genai.GenerativeModel('gemini-2.5-flash')
        
        # Modify prompt for rollback scenario
        if "rollback" in change_description.lower():
            prompt_parts = [
                "You are a network rollback expert. A rollback from a 'current' to a 'target' configuration is being performed.",
                f"Current (Problematic) Config:\n```\n{previous_config}\n```",
                f"Target (Stable) Config:\n```\n{new_config}\n```",
                "Your task is to generate a JSON object with keys: 'diff', 'summary', 'analysis', and 'security_risks'. All values must be strings and in Simplified Chinese.",
                "For the 'diff' key, generate a git-style diff comparing the 'Current' config to the 'Target' config. Prefix added lines with '+' and removed lines with '-'.",
                "For the 'analysis' key, the string value must contain two parts:",
                "1. A paragraph summarizing the rollback's purpose.",
                "2. A section titled '回滚计划 (Rollback Plan):' followed by a precise, step-by-step command list for manual rollback.",
                "Example for the 'analysis' string value: '本次回滚旨在...\\n\\n回滚计划 (Rollback Plan):\\nconfigure terminal\\n no ip address...'"
            ]
        else:
            prompt_parts = [
                "You are a network configuration analyst.",
                f"Previous config:\n```\n{previous_config}\n```",
                f"New config:\n```\n{new_config}\n```",
                "Analyze the changes. Provide a git-style diff, a summary, detailed analysis, and security risks in Simplified Chinese.",
                "Format the output as a JSON object with keys: 'diff', 'summary', 'analysis', 'security_risks'."
            ]

        if change_description and "rollback" not in change_description.lower():
            prompt_parts.insert(4, f"Context: {change_description}")

        prompt = "\n".join(prompt_parts)
        response = model.generate_content(prompt)
        cleaned_text = response.text.strip().replace('```json', '').replace('```', '')
        return json.loads(cleaned_text)
    except Exception as e:
        _handle_ai_exception(e)
        return {}

# --- Blockchain Services ---
def perform_add_block(data: Dict[str, Any], device_id: str, payload: SubmissionPayload) -> BlockDict:
    blockchain: List[BlockDict] = data.get('blockchains', {}).get(device_id, [])
    if not blockchain:
        raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}' 的区块链。")
    
    last_block: BlockDict = blockchain[-1]
    previous_config = last_block.get('data', {}).get('config', '')

    analysis_results: Dict[str, Any] = {}
    compliance_report: Optional[ComplianceReportDict] = None
    ai_settings = data.get('settings', {})

    if ai_settings.get("is_ai_analysis_enabled", True):
        try:
            # For regular updates, run compliance audit. Skip for rollbacks.
            if payload.changeType != 'rollback':
                compliance_report = _run_compliance_audit(data.get('policies', []), previous_config, payload.config)
            
            analysis_context = f"Rollback to version {payload.config}" if payload.changeType == 'rollback' else ""
            analysis_results = _run_ai_analysis(previous_config, payload.config, analysis_context)

        except HTTPException as e:
            # This will catch the compliance failure and re-raise it
            raise e
        except Exception as e:
            _handle_ai_exception(e)
            # In case of AI failure, we can decide if we want to proceed or not.
            # For now, let's proceed without AI analysis.
            logging.error(f"AI analysis failed but proceeding to create block. Error: {e}")


    new_index = last_block.get('index', -1) + 1
    timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    
    new_block_data: BlockDataDict = {
        "deviceId": device_id,
        "version": new_index + 1,
        "operator": payload.operator,
        "config": payload.config,
        "diff": analysis_results.get("diff", "Diff generation failed."),
        "changeType": payload.changeType,
        "summary": analysis_results.get("summary", "N/A"),
        "analysis": analysis_results.get("analysis", "AI analysis disabled or failed."),
        "security_risks": analysis_results.get("security_risks", "N/A"),
        "compliance_report": compliance_report,
    }
    
    prev_hash = last_block.get('hash', '0')
    new_hash = calculate_block_hash(new_block_data, new_index, timestamp, prev_hash)
    
    new_block: BlockDict = {
        "index": new_index,
        "timestamp": timestamp,
        "data": new_block_data,
        "prev_hash": prev_hash,
        "hash": new_hash
    }

    blockchain.append(new_block)
    return new_block


def perform_rollback(data: Dict[str, Any], device_id: str, payload: RollbackPayload) -> BlockDict:
    """Handles the specific logic for a rollback operation."""
    blockchain: List[BlockDict] = data.get('blockchains', {}).get(device_id, [])
    if not blockchain:
        raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}' 的区块链。")

    target_block = next((b for b in blockchain if b.get('data', {}).get('version') == payload.target_version), None)
    if not target_block:
        raise HTTPException(status_code=404, detail=f"未找到目标回滚版本 '{payload.target_version}'。")

    target_config = target_block.get('data', {}).get('config', '')
    
    # Use the submission payload for perform_add_block
    submission_payload = SubmissionPayload(
        operator=payload.operator,
        config=target_config,
        changeType='rollback'
    )
    
    try:
        return perform_add_block(data, device_id, submission_payload)
    except HTTPException as e:
        # Catch potential compliance or other errors from add_block and enrich the message
        logging.error(f"Rollback failed during block creation: {e.detail}")
        raise HTTPException(status_code=e.status_code, detail=f"记录回滚失败: {e.detail}")
    except Exception as e:
        logging.error(f"Unexpected error during rollback: {e}")
        raise HTTPException(status_code=500, detail=f"执行回滚时发生意外错误: {e}")


# --- Real-time Config Service ---
def get_device_info(device_id: str) -> Optional[Dict[str, Any]]:
    device_id_upper = device_id.upper()
    if not config.has_section('device_map') or not config.has_option('device_map', device_id_upper):
        return None
    
    try:
        ip, dev_type, creds_section = config.get('device_map', device_id_upper).split(',')
        ip = ip.strip()
        dev_type = dev_type.strip()
        creds_section = creds_section.strip()
        
        if not config.has_section(creds_section):
            return None
        
        username = config.get(creds_section, 'username')
        password = config.get(creds_section, 'password')
        secret = config.get(creds_section, 'secret', fallback=None)

        return {
            "host": ip, "device_type": dev_type,
            "username": username, "password": password,
            "secret": secret, "timeout": 20
        }
    except Exception as e:
        logging.error(f"Error parsing config for device {device_id}: {e}")
        return None

def get_running_config(device_id: str) -> Dict[str, str]:
    """Connects to a device and fetches its running configuration."""
    if is_simulation_mode():
        raise HTTPException(status_code=400, detail="模拟模式下无法获取实时配置。")

    device_info: Optional[Dict[str, Any]] = get_device_info(device_id)
    if not device_info:
        raise HTTPException(status_code=404, detail=f"在配置文件中未找到设备 ID '{device_id}'。")

    try:
        device_type: str = device_info.get('device_type', '').lower()
        with ConnectHandler(**device_info) as net_connect:
            net_connect.enable()
            net_connect.disable_paging()
            
            config_command = 'show running-config'
            if any(vendor in device_type for vendor in ['huawei', 'h3c', 'hp_comware']):
                config_command = 'display current-configuration'
            
            # The type hint for send_command can be broad (Any), so we cast it to str.
            latest_config: str = cast(str, net_connect.send_command(config_command, read_timeout=120))
            
            if not latest_config or "Invalid input detected" in latest_config:
                 raise HTTPException(status_code=500, detail="设备返回无效或空的配置。")
            
            return {"config": latest_config}

    except NetmikoAuthenticationException as e:
        logging.error(f"Netmiko authentication error for {device_id}: {e}")
        raise HTTPException(status_code=401, detail="设备认证失败，请检查凭证。")
    except NetmikoBaseException as e:
        logging.error(f"Netmiko connection error for {device_id}: {e}")
        raise HTTPException(status_code=504, detail="连接设备失败：设备无响应或超时。")
    except Exception as e:
        logging.error(f"Unexpected error in get_running_config for {device_id}: {e}")
        raise HTTPException(status_code=500, detail=f"获取配置时发生未知错误: {e}")