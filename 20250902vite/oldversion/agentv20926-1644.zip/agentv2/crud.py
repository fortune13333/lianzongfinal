# crud.txt - Create, Read, Update, Delete operations for database models.
# This file is the single source of truth for all database interactions.

import json
import logging
import datetime
from typing import Dict, List, Any, Optional
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import desc

# Import models and initial data structures
import models
from core import calculate_block_hash, INITIAL_DATA

# --- Seeding Initial Data ---

def seed_initial_data(db: Session):
    """
    Seeds the database with initial data if it's empty.
    This function is called once on startup.
    """
    # Check if data already exists to prevent re-seeding
    user_count = db.query(models.User).count()
    if user_count > 0:
        logging.info("Database already contains data. Skipping initial data seed.")
        return

    logging.warning("Database is empty. Seeding with initial data...")
    try:
        # Seed Users
        for user_data in INITIAL_DATA.get("users", []):
            db_user = models.User(**user_data)
            db.add(db_user)

        # Seed Devices and their Blockchains
        for device_data in INITIAL_DATA.get("devices", []):
            db_device = models.Device(
                id=device_data["id"],
                name=device_data["name"],
                ipAddress=device_data["ipAddress"],
                type=device_data["type"]
            )
            db.add(db_device)
            
            # Seed Blocks for this device
            blockchain_data = INITIAL_DATA.get("blockchains", {}).get(device_data["id"], [])
            for block_data in blockchain_data:
                db_block = models.Block(
                    device_id=device_data["id"],
                    index=block_data["index"],
                    timestamp=block_data["timestamp"],
                    data=json.dumps(block_data["data"], sort_keys=True, separators=(',', ':'), ensure_ascii=False),
                    prev_hash=block_data["prev_hash"],
                    hash=block_data["hash"]
                )
                db.add(db_block)
        
        # Seed settings
        settings_data = INITIAL_DATA.get("settings", {})
        for key, value in settings_data.items():
            db_setting = models.Setting(key=key, value=str(value))
            db.add(db_setting)

        db.commit()
        logging.info("Initial data seeded successfully.")
    except Exception as e:
        logging.error(f"Error seeding initial data: {e}")
        db.rollback()
        raise

# --- Data Transformation ---

def _format_data_for_frontend(db_devices: List[models.Device], db_users: List[models.User], db_logs: List[models.AuditLog], db_templates: List[models.ConfigTemplate], db_policies: List[models.Policy], db_settings: List[models.Setting]) -> Dict[str, Any]:
    """
    Transforms ORM objects into the JSON structure expected by the frontend.
    """
    blockchains = {}
    for device in db_devices:
        chain = []
        # Sort blocks by index to ensure correct order
        sorted_blocks = sorted(device.blocks, key=lambda b: b.index)
        for block in sorted_blocks:
            chain.append({
                "id": block.id,
                "index": block.index,
                "timestamp": block.timestamp,
                "data": json.loads(block.data), # Deserialize JSON string to object
                "prev_hash": block.prev_hash,
                "hash": block.hash,
            })
        blockchains[device.id] = chain

    settings = {s.key: json.loads(s.value.lower()) if s.value.lower() in ['true', 'false'] else s.value for s in db_settings}

    return {
        "devices": [{"id": d.id, "name": d.name, "ipAddress": d.ipAddress, "type": d.type} for d in db_devices],
        "blockchains": blockchains,
        "users": [{"id": u.id, "username": u.username, "password": u.password, "role": u.role} for u in db_users],
        "audit_log": [{"timestamp": l.timestamp.isoformat().replace('+00:00', 'Z'), "username": l.username, "action": l.action} for l in db_logs],
        "templates": [{"id": t.id, "name": t.name, "content": t.content} for t in db_templates],
        "policies": [{"id": p.id, "name": p.name, "severity": p.severity, "description": p.description, "rule": p.rule, "enabled": p.enabled} for p in db_policies],
        "settings": settings,
    }


# --- CRUD Operations ---

def get_all_data(db: Session) -> Dict[str, Any]:
    devices = db.query(models.Device).options(joinedload(models.Device.blocks)).all()
    users = db.query(models.User).all()
    logs = db.query(models.AuditLog).order_by(desc(models.AuditLog.timestamp)).limit(1000).all()
    templates = db.query(models.ConfigTemplate).all()
    policies = db.query(models.Policy).all()
    settings = db.query(models.Setting).all()
    return _format_data_for_frontend(devices, users, logs, templates, policies, settings)

def reset_all_data(db: Session):
    """Deletes all data from all tables and reseeds initial data."""
    db.query(models.Block).delete()
    db.query(models.Device).delete()
    db.query(models.User).delete()
    db.query(models.AuditLog).delete()
    db.query(models.ConfigTemplate).delete()
    db.query(models.Policy).delete()
    db.query(models.Setting).delete()
    db.commit()
    seed_initial_data(db)

def get_users(db: Session) -> List[models.User]:
    return db.query(models.User).all()

def get_policies(db: Session) -> List[models.Policy]:
    return db.query(models.Policy).all()

def get_settings(db: Session) -> List[models.Setting]:
    return db.query(models.Setting).all()

def get_templates(db: Session) -> List[models.ConfigTemplate]:
    return db.query(models.ConfigTemplate).all()

def get_device(db: Session, device_id: str) -> Optional[models.Device]:
    return db.query(models.Device).filter(models.Device.id == device_id).first()

def create_device_with_genesis_block(db: Session, device: models.Device) -> models.Device:
    # Add device to session
    db.add(device)
    
    # Create genesis block
    genesis_block_data: Dict[str, Any] = {
        "deviceId": device.id, "version": 1, "operator": "system_init",
        "config": f"hostname {device.name}\n!\n! Initial configuration created by ChainTrace.",
        "diff": f"+ hostname {device.name}\n+ !\n+ ! Initial configuration created by ChainTrace.",
        "changeType": "initial", "summary": "设备已创建。",
        "analysis": "这是新设备的第一个配置区块...", "security_risks": "无。",
        "compliance_report": {"overall_status": "passed", "results": []}
    }
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
    prev_hash = "0"
    index = 0
    hash_hex = calculate_block_hash(genesis_block_data, index, timestamp, prev_hash)
    
    db_block = models.Block(
        device_id=device.id,
        index=index,
        timestamp=timestamp,
        data=json.dumps(genesis_block_data, sort_keys=True, separators=(',', ':'), ensure_ascii=False),
        prev_hash=prev_hash,
        hash=hash_hex
    )
    db.add(db_block)
    
    db.commit()
    db.refresh(device)
    return device

def delete_device(db: Session, device_id: str) -> bool:
    db_device = get_device(db, device_id)
    if db_device:
        db.delete(db_device) # Cascade delete will handle blocks
        db.commit()
        return True
    return False

def add_block(db: Session, device_id: str, new_block: Dict[str, Any]) -> Dict[str, Any]:
    block_data_str = json.dumps(new_block["data"], sort_keys=True, separators=(',', ':'), ensure_ascii=False)
    db_block = models.Block(
        device_id=device_id,
        index=new_block["index"],
        timestamp=new_block["timestamp"],
        data=block_data_str,
        prev_hash=new_block["prev_hash"],
        hash=new_block["hash"]
    )
    db.add(db_block)
    db.commit()
    return new_block

def log_action(db: Session, username: str, action: str):
    log_entry = models.AuditLog(username=username, action=action)
    db.add(log_entry)
    db.commit()
