# core.py - Core components for ChainTrace Agent
# Contains configuration loading, data handling, and Pydantic models.

import sys
import configparser
import logging
import json
import threading
import datetime
import hashlib
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional, Set, TypedDict

from pydantic import BaseModel

# --- AI Integration Imports ---
try:
    import google.generativeai as genai
except ImportError:
    genai = None


# --- Basic Setup ---

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Command-line Argument Parsing ---
parser = argparse.ArgumentParser(description="ChainTrace Agent: A LAN collaboration server for network configuration tracking.")
parser.add_argument(
    '--config',
    type=Path,
    default=Path("config.ini"),
    help="Path to the configuration file (default: config.ini)"
)
# Use parse_known_args to prevent conflicts when running with uvicorn
args, _ = parser.parse_known_args()
CONFIG_FILE = args.config

# --- Data File and Lock ---
DATA_FILE = Path("chaintrace_data.json")
data_lock = threading.Lock()
MAX_LOG_ENTRIES = 1000

# --- In-memory store for active user/device sessions ---
ACTIVE_SESSIONS: Dict[str, List[Dict[str, str]]] = {}
sessions_lock = threading.Lock()


# --- Typed Dictionaries for more precise type hinting ---
class ComplianceReportDict(TypedDict, total=False):
    overall_status: str
    results: List[Dict[str, Any]]
    details: Optional[str]

class BlockDataDict(TypedDict):
    deviceId: str
    version: int
    operator: str
    config: str
    diff: str
    changeType: Optional[str]
    summary: str
    analysis: Any # This can be string or dict from old rollback data
    security_risks: str
    compliance_report: Optional[ComplianceReportDict]

class BlockDict(TypedDict):
    index: int
    timestamp: str
    data: BlockDataDict
    prev_hash: str
    hash: str


# --- Hashing Helper ---
def calculate_block_hash(block_data_dict: BlockDataDict, index: int, timestamp: str, prev_hash: str) -> str:
    """Calculates a deterministic SHA-256 hash for a block's content."""
    # Using separators=(',', ':') and sort_keys=True to match JavaScript's deterministic stringify
    block_content_str = (
        f"{index}{timestamp}"
        f"{json.dumps(block_data_dict, sort_keys=True, separators=(',', ':'), ensure_ascii=False)}"
        f"{prev_hash}"
    )
    return hashlib.sha256(block_content_str.encode('utf-8')).hexdigest()

# --- Initial Data Structure ---
INITIAL_DATA_RAW: Dict[str, Any] = {
    "devices": [
        {"id": "RTR01-NYC", "name": "Core Router NYC", "ipAddress": "192.168.1.1", "type": "Router"},
        {"id": "SW01-SFO", "name": "Access Switch SFO", "ipAddress": "10.10.5.254", "type": "Switch"},
        {"id": "FW01-LON", "name": "Edge Firewall London", "ipAddress": "203.0.113.1", "type": "Firewall"},
    ],
    "users": [
        {"id": 1, "username": "admin", "password": "admin", "role": "admin"},
        {"id": 2, "username": "operator1", "password": "password", "role": "operator"},
        {"id": 3, "username": "net_admin", "password": "password123", "role": "operator"},
    ],
    "audit_log": [],
    "templates": [],
    "policies": [],
    "deployment_history": [],
    "settings": {
        "is_ai_analysis_enabled": True
    },
    "blockchains": {
        "RTR01-NYC": [{
            "index": 0, "timestamp": "2023-01-01T10:00:00Z",
            "data": { "deviceId": "RTR01-NYC", "version": 1, "operator": "system_init", "config": "hostname RTR01-NYC\n!\ninterface GigabitEthernet0/0\n ip address 192.168.1.1 255.255.255.0\n no shutdown\n!\nrouter ospf 1\n network 192.168.1.0 0.0.0.255 area 0\n!\nend", "diff": "+ hostname RTR01-NYC\n+ !\n+ interface GigabitEthernet0/0\n+  ip address 192.168.1.1 255.255.255.0\n+  no shutdown\n+ !\n+ router ospf 1\n+  network 192.168.1.0 0.0.0.255 area 0\n+ !\n+ end", "changeType": "initial", "summary": "初始系统配置。", "analysis": "这是设备的第一个配置区块，用于建立基线。", "security_risks": "无。这是一个标准的初始设置。", "compliance_report": {"overall_status": "passed", "results": []}}, "prev_hash": "0"
        }],
        "SW01-SFO": [{
            "index": 0, "timestamp": "2023-01-02T11:30:00Z",
            "data": { "deviceId": "SW01-SFO", "version": 1, "operator": "system_init", "config": "hostname SW01-SFO\n!\nvlan 10\n name USERS\n!\ninterface FastEthernet0/1\n switchport mode access\n switchport access vlan 10\n!\nend", "diff": "+ hostname SW01-SFO\n+ !\n+ vlan 10\n+  name USERS\n+ !\n+ interface FastEthernet0/1\n+  switchport mode access\n+  switchport access vlan 10\n+ !\n+ end", "changeType": "initial", "summary": "初始系统配置。", "analysis": "这是设备的第一个配置区块，用于建立基线。", "security_risks": "无。这是一个标准的初始设置。", "compliance_report": {"overall_status": "passed", "results": []}}, "prev_hash": "0"
        }],
        "FW01-LON": [{
            "index": 0, "timestamp": "2023-01-03T09:00:00Z",
            "data": { "deviceId": "FW01-LON", "version": 1, "operator": "system_init", "config": "hostname FW01-LON\n!\nip access-list extended INCOMING_FILTER\n permit tcp any host 203.0.113.1 eq 443\n deny ip any any log\n!\ninterface GigabitEthernet0/1\n ip access-group INCOMING_FILTER in\n!\nend", "diff": "+ hostname FW01-LON\n+ !\n+ ip access-list extended INCOMING_FILTER\n+  permit tcp any host 203.0.113.1 eq 443\n+  deny ip any any log\n+ !\n+ interface GigabitEthernet0/1\n+  ip access-group INCOMING_FILTER in\n+ !\n+ end", "changeType": "initial", "summary": "初始系统配置。", "analysis": "这是设备的第一个配置区块，用于建立基线。", "security_risks": "无。这是一个标准的初始设置。", "compliance_report": {"overall_status": "passed", "results": []}}, "prev_hash": "0"
        }]
    }
}

def get_initial_data_with_hashes() -> Dict[str, Any]:
    """Calculates initial hashes for the default dataset."""
    data = json.loads(json.dumps(INITIAL_DATA_RAW)) # Deep copy
    for chain in data["blockchains"].values():
        for block in chain:
            block["hash"] = calculate_block_hash(block["data"], block["index"], block["timestamp"], block["prev_hash"])
    return data

INITIAL_DATA = get_initial_data_with_hashes()

# --- Data Handling Functions ---

def log_action(data: Dict[str, Any], username: str, action: str) -> None:
    """Adds a new entry to the audit log."""
    log_entry: Dict[str, str] = {"timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z'), "username": username, "action": action}
    audit_log: List[Dict[str, str]] = data.get("audit_log", [])
    audit_log.insert(0, log_entry)
    data["audit_log"] = audit_log[:MAX_LOG_ENTRIES]

def save_data_nolock(data: Dict[str, Any]) -> None:
    """Saves data to the JSON file without acquiring the lock."""
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f: json.dump(data, f, indent=2, ensure_ascii=False)
    except IOError as e: logging.error(f"Could not write to {DATA_FILE}: {e}")

def load_data_nolock() -> Dict[str, Any]:
    """Loads data from the JSON file without acquiring the lock, ensuring schema."""
    if not DATA_FILE.exists():
        logging.info(f"{DATA_FILE} not found. Creating with initial data."); save_data_nolock(INITIAL_DATA); return INITIAL_DATA
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            data: Dict[str, Any] = json.load(f)
            # Ensure backward compatibility for older data files
            if 'users' not in data: data['users'] = INITIAL_DATA['users']
            if 'audit_log' not in data: data['audit_log'] = []
            if 'templates' not in data: data['templates'] = []
            if 'policies' not in data: data['policies'] = []
            if 'deployment_history' not in data: data['deployment_history'] = []
            if 'settings' not in data: data['settings'] = {"is_ai_analysis_enabled": True}
            return data
    except (json.JSONDecodeError, IOError) as e:
        logging.error(f"Error reading {DATA_FILE}: {e}. Returning empty structure."); return {"devices": [], "blockchains": {}, "users": [], "audit_log": [], "templates": [], "policies": [], "settings": {"is_ai_analysis_enabled": True}}


# --- Configuration Loading ---
config = configparser.ConfigParser()
forbidden_commands: Set[str] = set()
try:
    if not CONFIG_FILE.exists(): raise FileNotFoundError(f"{CONFIG_FILE} not found.")
    config.read(CONFIG_FILE, encoding='utf-8');
    if not config.sections(): raise FileNotFoundError(f"{CONFIG_FILE} is empty.")
    
    # --- Gemini AI Configuration ---
    if genai:
        GEMINI_API_KEY: Optional[str] = config.get('gemini', 'api_key', fallback=None)
        if GEMINI_API_KEY and 'your_gemini_api_key' not in GEMINI_API_KEY:
            try:
                genai.configure(api_key=GEMINI_API_KEY) # type: ignore
                logging.info("Gemini API key loaded and configured successfully.")
            except Exception as e:
                logging.error(f"Failed to configure Gemini API, AI features will be disabled. Error: {e}")
                genai = None
        else:
            logging.warning("Gemini API key not found or is a placeholder in config.ini. AI features will be disabled.")
            genai = None
    else:
        logging.warning("google-generativeai library not found. AI features will be disabled. Please run 'pip install -r requirements.txt'")
    
    # --- Security Configuration ---
    if config.has_section('security'):
        commands_str: str = config.get('security', 'forbidden_commands', fallback='')
        if commands_str:
            # Normalize commands on load: lowercase, strip whitespace, and collapse internal spaces.
            raw_commands = [cmd.strip().lower() for cmd in commands_str.split(',') if cmd.strip()]
            forbidden_commands = {' '.join(cmd.split()) for cmd in raw_commands}
            logging.info(f"Loaded {len(forbidden_commands)} forbidden commands: {', '.join(sorted(list(forbidden_commands)))}")

except (configparser.Error, FileNotFoundError, UnicodeDecodeError) as e:
    logging.error(f"CRITICAL: An unexpected error occurred while reading {CONFIG_FILE}: {e}"); sys.exit(1)

# --- API Models ---
class Device(BaseModel): id: str; name: str; ipAddress: str; type: str
class ConfigPayload(BaseModel): config: str
class SubmissionPayload(BaseModel): 
    operator: str
    config: str
    changeType: Optional[str] = "update"
class RollbackPayload(BaseModel):
    operator: str
    target_version: int
class AuditTriggerPayload(BaseModel): operator: str
class SessionPayload(BaseModel): username: str; sessionId: str
class User(BaseModel): id: int; username: str; password: str; role: str
class UserUpdatePayload(BaseModel): username: str; role: str; password: Optional[str] = None
class ConfigTemplate(BaseModel): id: str; name: str; content: str
class BulkDeployPayload(BaseModel): template_id: str; device_ids: List[str]
class Policy(BaseModel): id: str; name: str; severity: str; description: str; rule: str; enabled: bool
class AISettingsPayload(BaseModel): is_ai_analysis_enabled: bool