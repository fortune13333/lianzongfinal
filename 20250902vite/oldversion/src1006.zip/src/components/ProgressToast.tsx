import React from 'react';
import { toast, Toast } from 'react-hot-toast';
import Loader from './Loader';
import { CheckCircleSolid, XCircleSolid } from './AIIcons';

export interface ProgressStep {
    text: string;
    status: 'pending' | 'loading' | 'done' | 'error';
}

interface ProgressToastProps {
    t: Toast; // Toast object from react-hot-toast
    title: string;
    steps: ProgressStep[];
}

const StepIcon: React.FC<{ status: ProgressStep['status'] }> = ({ status }) => {
    switch (status) {
        case 'loading':
            return <Loader />;
        case 'done':
            return <CheckCircleSolid className="h-5 w-5 text-emerald-500" />;
        case 'error':
            return <XCircleSolid className="h-5 w-5 text-red-500" />;
        case 'pending':
        default:
            return <div className="h-5 w-5 flex items-center justify-center"><div className="h-2 w-2 rounded-full bg-bg-600"></div></div>;
    }
}

const ProgressToast: React.FC<ProgressToastProps> = ({ t, title, steps }) => {
    return (
        <div 
            className={`${t.visible ? 'animate-enter' : 'animate-leave'} max-w-sm w-full bg-bg-800 shadow-lg rounded-lg pointer-events-auto flex ring-1 ring-black ring-opacity-5 border border-bg-700`}
        >
            <div className="flex-1 w-0 p-4">
                <div className="flex items-start">
                    <div className="ml-3 flex-1">
                        <p className="text-sm font-medium text-text-100">{title}</p>
                        <ul className="mt-2 space-y-2">
                            {steps.map((step, index) => (
                                <li key={index} className="flex items-center gap-3 text-sm">
                                    <StepIcon status={step.status} />
                                    <span className={
                                        step.status === 'pending' ? 'text-text-400' : 
                                        step.status === 'error' ? 'text-red-400' : 'text-text-200'
                                    }>
                                        {step.text}
                                    </span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>
            <div className="flex border-l border-bg-700">
                <button
                    onClick={() => toast.dismiss(t.id)}
                    className="w-full border border-transparent rounded-none rounded-r-lg p-4 flex items-center justify-center text-sm font-medium text-primary-500 hover:text-primary-400 focus:outline-none focus:ring-2 focus:ring-primary-500"
                >
                    关闭
                </button>
            </div>
        </div>
    );
};

export default ProgressToast;