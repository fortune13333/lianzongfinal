import React from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import DeviceDetails from './components/DeviceDetails';
import SettingsModal from './components/SettingsModal';
import DeviceEditModal from './components/DeviceEditModal';
import Login from './components/Login';
import ConfirmationModal from './components/ConfirmationModal';
import { Toaster } from 'react-hot-toast';
import { leaveDeviceSessionAPI } from './utils/session';
import AIStatusBanner from './components/AIStatusBanner';
import ApiKeyInstructionsModal from './components/ApiKeyInstructionsModal';
import { useStore } from './store/useStore';


const App: React.FC = () => {
  const currentUser = useStore(state => state.currentUser);
  const selectedDevice = useStore(state => state.selectedDevice);
  const isLoading = useStore(state => state.isLoading);
  const settings = useStore(state => state.settings);
  const agentApiUrl = settings.agentApiUrl;
  const aiStatus = useStore(state => state.aiStatus);
  const openApiKeyModal = useStore(state => state.openApiKeyModal);
  const rollbackTarget = useStore(state => state.rollbackTarget);
  const cancelRollback = useStore(state => state.cancelRollback);
  const executeRollback = useStore(state => state.executeRollback);
  const init = useStore(state => state.init);
  const fetchData = useStore(state => state.fetchData);
  
  const isLoadingRef = React.useRef(isLoading);
  isLoadingRef.current = isLoading;
  
  const sessionId = React.useMemo(() => crypto.randomUUID(), []);

  React.useEffect(() => {
    init();
  }, [init]);

  React.useEffect(() => {
    document.documentElement.setAttribute('data-theme', settings.theme);
    document.documentElement.setAttribute('data-bg-theme', settings.bgTheme);
    document.body.className = 'bg-bg-950 text-text-300 font-sans';
  }, [settings.theme, settings.bgTheme]);

  React.useEffect(() => {
    if (currentUser && agentApiUrl) {
      fetchData(); // Initial fetch
      const intervalId = setInterval(() => {
        if (!document.hidden && !isLoadingRef.current) {
          fetchData(true); // Silent refresh
        }
      }, 5000);
      return () => clearInterval(intervalId);
    }
  }, [agentApiUrl, currentUser, fetchData]);
  
  React.useEffect(() => {
    const handleBeforeUnload = () => {
      if (selectedDevice && agentApiUrl) {
        leaveDeviceSessionAPI(selectedDevice.id, sessionId, agentApiUrl);
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [selectedDevice, sessionId, agentApiUrl]);

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Toaster position="top-center" toastOptions={{ className: '!bg-bg-800 !text-text-100' }} />
        <Login />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Toaster position="top-center" toastOptions={{ className: '!bg-bg-800 !text-text-100' }} />
      {!aiStatus.isOk && (
        <AIStatusBanner 
          message={aiStatus.message} 
          errorCode={aiStatus.code} 
          onShowInstructions={openApiKeyModal} 
        />
      )}
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        {selectedDevice ? (
          <DeviceDetails sessionId={sessionId} />
        ) : (
          <Dashboard />
        )}
      </main>
      <SettingsModal />
      <DeviceEditModal />
      {rollbackTarget && (
        <ConfirmationModal
          isOpen={!!rollbackTarget} 
          onClose={cancelRollback} 
          onConfirm={executeRollback}
          title="确认回滚操作" 
          confirmText="确认回滚" 
          confirmButtonVariant="warning"
        >
          <p className="text-sm text-text-300">
            您确定要将设备 <strong className="font-bold text-white">{rollbackTarget.data.deviceId}</strong> 的配置回滚到 <strong className="font-bold text-white">版本 {rollbackTarget.data.version}</strong> 吗？
          </p>
          <p className="mt-2 text-xs text-text-400">
            此操作将在区块链上创建一个新的配置记录，而不是删除历史记录。
          </p>
        </ConfirmationModal>
      )}
      <ApiKeyInstructionsModal />
    </div>
  );
};

export default App;