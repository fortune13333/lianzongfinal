# websocket_handler.py - WebSocket handling for ChainTrace Agent's interactive console

import logging
import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from fastapi.websockets import WebSocketState
from netmiko import ConnectHandler # type: ignore
from netmiko.exceptions import NetmikoAuthenticationException, NetmikoBaseException # type: ignore
from netmiko.cisco_base_connection import CiscoBaseConnection # type: ignore
from typing import Optional, TypedDict

# Import from our own refactored modules
from core import forbidden_commands
from services import get_device_info # type: ignore

# Type definition for device information
class DeviceInfo(TypedDict, total=False):
    host: str
    device_type: str
    username: str
    password: str
    secret: Optional[str]
    timeout: int

router = APIRouter()

async def unified_io_handler(websocket: WebSocket, net_connect: CiscoBaseConnection, actor_username: str) -> None:
    """
    A unified I/O handler that multiplexes reads from the user's WebSocket and the device's channel.
    This approach restores full interactivity (like tab-completion) while preserving the ability
    to intercept and validate commands before execution.
    """
    line_buffer: str = ""
    loop = asyncio.get_running_loop()

    ws_reader: asyncio.Task[str] = asyncio.create_task(websocket.receive_text())
    device_reader: "asyncio.Future[str]" = loop.run_in_executor(None, net_connect.read_channel)

    try:
        while True:
            done, _ = await asyncio.wait(
                [ws_reader, device_reader],
                return_when=asyncio.FIRST_COMPLETED
            )

            # --- Handle output from the device ---
            if device_reader in done:
                device_output: str = device_reader.result()
                if device_output:
                    await websocket.send_text(device_output)
                device_reader = loop.run_in_executor(None, net_connect.read_channel)

            # --- Handle input from the user ---
            if ws_reader in done:
                user_input: str = ws_reader.result()
                
                is_enter_key = '\r' in user_input or '\n' in user_input

                if is_enter_key:
                    command_to_check = line_buffer.strip().lower()
                    normalized_command = ' '.join(command_to_check.split())
                    
                    logging.info(f"Intercept check: User='{actor_username}', Buffer='{line_buffer.strip()}', Normalized='{normalized_command}'")
                    
                    is_forbidden = False
                    if normalized_command:
                        if any(cmd.startswith(normalized_command) for cmd in forbidden_commands):
                            is_forbidden = True
                    
                    if is_forbidden:
                        logging.warning(f"User '{actor_username}' attempted forbidden command: '{line_buffer.strip()}' (Normalized: '{normalized_command}')")
                        error_msg = (
                            f"\r\n\x1b[31m[ChainTrace Policy Violation] Error: The command '{line_buffer.strip()}' "
                            f"is prohibited.\r\nPlease use \"Save Session & Audit\" to record changes.\x1b[0m\r\n"
                        )
                        await websocket.send_text(error_msg)
                        
                        clear_line_signal = '\x15' # CTRL+U (Kill Line)
                        await loop.run_in_executor(None, net_connect.write_channel, clear_line_signal + '\n')
                    else:
                        await loop.run_in_executor(None, net_connect.write_channel, '\n')
                    
                    line_buffer = ""
                
                elif user_input == '\x7f': # Backspace
                    if line_buffer:
                        line_buffer = line_buffer[:-1]
                    await loop.run_in_executor(None, net_connect.write_channel, '\x7f')
                
                else: # Other characters (including Tab)
                    line_buffer += user_input
                    await loop.run_in_executor(None, net_connect.write_channel, user_input)

                ws_reader = asyncio.create_task(websocket.receive_text())

    except WebSocketDisconnect:
        logging.info(f"WebSocket disconnected for user {actor_username}.")
    except Exception as e:
        logging.error(f"Error in unified_io_handler for user {actor_username}: {e}")
    finally:
        if not ws_reader.done(): ws_reader.cancel()
        if not device_reader.done(): device_reader.cancel()


@router.websocket("/ws/{device_id}/{session_id}")
async def websocket_endpoint(websocket: WebSocket, device_id: str, session_id: str) -> None:
    # FIX: Correctly get username from query parameters as browser WebSocket API does not support headers.
    actor_username = websocket.query_params.get("username", "unknown_ws_user")
    
    await websocket.accept()
    device_info: Optional[DeviceInfo] = get_device_info(device_id)  # type: ignore
    if not device_info:
        await websocket.close(code=1008, reason="在配置文件中未找到设备ID。")
        return
        
    net_connect: Optional[CiscoBaseConnection] = None
    try:
        await websocket.send_text("[1/3] 正在建立SSH连接...\r\n")
        loop = asyncio.get_running_loop()
        
        net_connect = await loop.run_in_executor(None, lambda: ConnectHandler(**device_info)) # type: ignore
        
        await websocket.send_text("[2/3] 连接成功, 正在进入特权模式...\r\n")
        if net_connect: await loop.run_in_executor(None, net_connect.enable)
        await websocket.send_text("[3/3] 特权模式已进入, 正在等待设备响应 (最长5秒)...\r\n")
        
        prompt = ""
        if net_connect: prompt = await loop.run_in_executor(None, lambda: net_connect.find_prompt(delay_factor=2))
        await websocket.send_text(f"\r\n{prompt}")

        if net_connect:
            await unified_io_handler(websocket, net_connect, actor_username)

    except NetmikoBaseException as e:
        error_type = "认证失败" if isinstance(e, NetmikoAuthenticationException) else "连接超时或错误"
        logging.error(f"WS connection failed for {device_id}: {error_type}: {e}")
        await websocket.send_text(f"\r\n--- 连接失败 ---\r\n原因: {error_type}: {e}\r\n")
    except Exception as e:
        logging.error(f"An unexpected WebSocket error occurred for device {device_id}: {e}")
        await websocket.send_text(f"\r\n--- 连接失败 ---\r\n原因: 未知连接错误: {e}\r\n")
    finally:
        if net_connect and net_connect.is_alive():
            net_connect.disconnect()
        if websocket.client_state != WebSocketState.DISCONNECTED:
            await websocket.close()
        logging.info(f"WebSocket connection closed for device {device_id}, session {session_id}")