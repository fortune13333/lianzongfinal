# __init__.py - Makes services functions explicitly available for import

from .services import (
    get_device_info,
    is_simulation_mode,
    verify_admin,
    generate_simple_diff,
    call_gemini_for_analysis,
    call_gemini_for_compliance,
    perform_add_block
)

__all__ = [
    "get_device_info",
    "is_simulation_mode",
    "verify_admin",
    "generate_simple_diff",
    "call_gemini_for_analysis",
    "call_gemini_for_compliance",
    "perform_add_block"
]