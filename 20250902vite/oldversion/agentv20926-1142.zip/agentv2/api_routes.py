# api_routes.py - All HTTP API endpoints for ChainTrace Agent

import logging
import datetime
import uuid
from fastapi import APIRouter, HTTPException, Header, Depends
from typing import Dict, List, Any, cast, Optional

from netmiko import ConnectHandler, NetmikoBaseException # type: ignore

import services
from core import (
    data_lock, load_data_nolock, save_data_nolock, log_action, INITIAL_DATA, config,
    calculate_block_hash, ACTIVE_SESSIONS, sessions_lock,
    Device, ConfigPayload, SubmissionPayload, AuditTriggerPayload, SessionPayload,
    UserUpdatePayload, ConfigTemplate, BulkDeployPayload, Policy, AISettingsPayload, RollbackPayload
)

router = APIRouter()

# --- Authorization Dependency ---
def verify_admin_dep(actor: str = Header(..., alias="X-Actor-Username")) -> str:
    """A FastAPI dependency that verifies the user has admin role."""
    with data_lock:
        data = load_data_nolock()
        services.verify_admin(data, actor)
    return actor

# --- API Endpoints ---
@router.get("/api/data")
def get_all_data() -> Dict[str, Any]:
    with data_lock:
        data = load_data_nolock()
        # Enrich device data with netmiko type from config.ini
        enriched_devices: List[Dict[str, Any]] = []
        for device_dict in data.get('devices', []):
            device_id_upper = device_dict.get('id', '').upper()
            netmiko_type: Optional[str] = None
            if config.has_option('device_map', device_id_upper):
                try:
                    # Split only once on the first comma
                    _, device_type_str, _ = config.get('device_map', device_id_upper).split(',', 2)
                    netmiko_type = device_type_str.strip()
                except ValueError:
                    logging.warning(f"Could not parse netmiko type for {device_id_upper} from config.ini")
            
            enriched_device = device_dict.copy()
            enriched_device['netmiko_device_type'] = netmiko_type
            enriched_devices.append(enriched_device)
        
        response_data = data.copy()
        response_data['devices'] = enriched_devices
        return response_data

@router.post("/api/reset", status_code=204)
def reset_data(actor: str = Depends(verify_admin_dep)) -> None:
    with data_lock:
        data = load_data_nolock()
        log_action(data, actor, "重置了所有应用数据到初始状态。")
        save_data_nolock(INITIAL_DATA)
    return

@router.post("/api/devices", status_code=201)
def add_device(device: Device, actor: str = Depends(verify_admin_dep)) -> Device:
    with data_lock:
        data = load_data_nolock()
        devices_list: List[Dict[str, Any]] = data['devices']
        if any(d['id'] == device.id for d in devices_list): raise HTTPException(status_code=409, detail=f"设备 ID '{device.id}' 已存在。")
        devices_list.append(device.model_dump())
        genesis_block_data: Dict[str, Any] = {"deviceId": device.id, "version": 1, "operator": "system_init", "config": f"hostname {device.name}\n!\n! Initial configuration created by ChainTrace.", "diff": f"+ hostname {device.name}\n+ !\n+ ! Initial configuration created by ChainTrace.", "changeType": "initial", "summary": "设备已创建。", "analysis": "这是新设备的第一个配置区块...", "security_risks": "无。", "compliance_report": {"overall_status": "passed", "results": []}}
        timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
        hash_hex = calculate_block_hash(genesis_block_data, 0, timestamp, "0")
        genesis_block: Dict[str, Any] = {"index": 0, "timestamp": timestamp, "data": genesis_block_data, "prev_hash": "0", "hash": hash_hex}
        data['blockchains'][device.id] = [genesis_block]
        log_action(data, actor, f"添加了新设备 '{device.name}' (ID: {device.id})。")
        save_data_nolock(data)
    return device

@router.delete("/api/devices/{device_id}", status_code=204)
def delete_device(device_id: str, actor: str = Depends(verify_admin_dep)) -> None:
    with data_lock:
        data = load_data_nolock()
        device_to_delete = next((d for d in data['devices'] if d['id'] == device_id), None)
        if not device_to_delete: raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}'。")
        data['devices'] = [d for d in data['devices'] if d['id'] != device_id]
        if device_id in data['blockchains']: del data['blockchains'][device_id]
        log_action(data, actor, f"删除了设备 '{device_to_delete['name']}' (ID: {device_id})。")
        save_data_nolock(data)
    return

@router.post("/api/sessions/{device_id}/save", status_code=200)
def save_session_and_audit(device_id: str, payload: AuditTriggerPayload) -> Dict[str, Any]:
    """Fetches the latest config from the device and creates a new block."""
    if services.is_simulation_mode():
        raise HTTPException(status_code=400, detail="模拟模式下无法保存会话。")
    
    device_info: Optional[Dict[str, Any]] = services.get_device_info(device_id)
    if not device_info:
        raise HTTPException(status_code=404, detail=f"在配置文件中未找到设备 ID '{device_id}'。")

    try:
        device_type: str = device_info.get('device_type', '').lower()
        with ConnectHandler(**device_info) as net_connect:
            net_connect.enable()
            
            logging.info(f"Disabling pagination for device type: {device_type}")
            net_connect.disable_paging()
            
            config_command = 'show running-config'
            if any(vendor in device_type for vendor in ['huawei', 'h3c', 'hp_comware']):
                config_command = 'display current-configuration'
            
            logging.info(f"Executing command '{config_command}' for device {device_id}")
            latest_config: str = cast(str, net_connect.send_command(config_command, read_timeout=120))
        
        audit_payload = SubmissionPayload(operator=payload.operator, config=latest_config)
        
        with data_lock:
            data = load_data_nolock()
            new_block: Dict[str, Any] = services.perform_add_block(data, device_id, audit_payload)
            log_action(data, payload.operator, f"通过交互式会话为设备 '{device_id}' 保存并审计了新配置 (版本 {new_block['data']['version']})。")
            save_data_nolock(data)
        
        return new_block

    except NetmikoBaseException as e:
        logging.error(f"Netmiko error during session save for {device_id}: {e}")
        raise HTTPException(status_code=504, detail="从设备获取配置失败：设备响应超时或返回格式不正确。请检查设备状态和网络连接。")
    except Exception as e:
        logging.error(f"Unexpected error during session save for {device_id}: {e}")
        raise HTTPException(status_code=500, detail=f"保存在线会话时发生意外错误: {e}")

@router.post("/api/device/{device_id}/push_config", status_code=200)
def push_config_to_device(device_id: str, payload: ConfigPayload, actor: str = Header(..., alias="X-Actor-Username")) -> Dict[str, Any]:
    if services.is_simulation_mode():
        logging.info(f"SIMULATION MODE: Simulating config push for {device_id}.")
        return {"status": "success", "message": "配置推送模拟成功。"}
    
    device_info: Optional[Dict[str, Any]] = services.get_device_info(device_id)
    if not device_info:
        raise HTTPException(status_code=404, detail=f"在配置文件中未找到设备 ID '{device_id}'。")
    
    config_commands = payload.config.splitlines()
    if not config_commands:
        raise HTTPException(status_code=400, detail="配置内容不能为空。")
    
    try:
        with ConnectHandler(**device_info) as net_connect:
            net_connect.enable()
            output: str = net_connect.send_config_set(config_commands)
        
        with data_lock:
            data = load_data_nolock()
            log_action(data, actor, f"将配置非交互式地推送到设备 '{device_id}'。")
            save_data_nolock(data)
            
        return {"status": "success", "output": output}
    except NetmikoBaseException as e:
        logging.error(f"Netmiko error during config push for {device_id}: {e}")
        raise HTTPException(status_code=504, detail="推送配置失败：连接设备时出错。请检查设备状态和网络连接。")
    except Exception as e:
        logging.error(f"Unexpected error during config push for {device_id}: {e}")
        raise HTTPException(status_code=500, detail=f"推送配置时发生意外错误: {e}")

@router.post("/api/bulk-deploy")
def bulk_deploy_template(payload: BulkDeployPayload, actor: str = Header(..., alias="X-Actor-Username")) -> Dict[str, Any]:
    with data_lock: data = load_data_nolock()
    
    template = next((t for t in data.get('templates', []) if t['id'] == payload.template_id), None)
    if not template: raise HTTPException(status_code=404, detail="未找到模板。")
    
    success_count = 0
    failures: List[str] = []
    results: List[Dict[str, Any]] = []

    for device_id in payload.device_ids:
        device = next((d for d in data.get('devices', []) if d['id'] == device_id), None)
        if not device:
            failure_str = f"{device_id}: 在数据库中未找到设备元数据。"
            failures.append(failure_str)
            results.append({"device_id": device_id, "device_name": "Unknown", "status": "failure", "message": "在数据库中未找到设备元数据。"})
            continue

        rendered_config = template['content'].replace("{{ device.name }}", device['name'])
        rendered_config = rendered_config.replace("{{ device.id }}", device['id'])
        rendered_config = rendered_config.replace("{{ device.ipAddress }}", device['ipAddress'])
        
        try:
            if not services.is_simulation_mode():
                device_info_dict: Optional[Dict[str, Any]] = services.get_device_info(device_id)
                if not device_info_dict: raise Exception("在 config.ini 中未找到设备。")
                with ConnectHandler(**device_info_dict) as net_connect:
                    net_connect.enable()
                    net_connect.send_config_set(rendered_config.splitlines())
            
            audit_payload = SubmissionPayload(operator=actor, config=rendered_config)
            new_block: Dict[str, Any] = services.perform_add_block(data, device_id, audit_payload)
            log_action(data, actor, f"通过批量部署模板 '{template['name']}' 更新了设备 '{device_id}' (版本 {new_block['data']['version']})。")
            success_count += 1
            results.append({
                "device_id": device_id, 
                "device_name": device['name'], 
                "status": "success", 
                "message": f"部署成功，新版本为 {new_block['data']['version']}。"
            })
            
        except Exception as e:
            failure_str = f"{device_id} ({device['name']}): {e}"
            failures.append(failure_str)
            results.append({
                "device_id": device_id, 
                "device_name": device['name'], 
                "status": "failure", 
                "message": str(e)
            })

    status = "Completed with Errors" if failures else "Completed"
    deployment_record = {
        "id": str(uuid.uuid4()),
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z'),
        "operator": actor,
        "template_name": template['name'],
        "status": status,
        "summary": f"{success_count} 成功, {len(failures)} 失败。",
        "target_devices": payload.device_ids,
        "results": results,
    }
    
    data.setdefault('deployment_history', []).insert(0, deployment_record)
    save_data_nolock(data)
    
    message = f"部署完成。{success_count} 台成功，{len(failures)} 台失败。"
    if failures: return {"message": message, "success_count": success_count, "failures": failures}
    return {"message": message, "success_count": success_count, "failures": []}

# --- Template & Policy Management ---
@router.post("/api/templates", status_code=201)
def create_template(template: ConfigTemplate, actor: str = Depends(verify_admin_dep)) -> ConfigTemplate:
    with data_lock:
        data = load_data_nolock()
        if any(t['name'] == template.name for t in data.get('templates', [])):
            raise HTTPException(status_code=409, detail=f"名为 '{template.name}' 的模板已存在。")
        data.setdefault('templates', []).append(template.model_dump())
        log_action(data, actor, f"创建了新配置模板 '{template.name}'。")
        save_data_nolock(data)
    return template

@router.put("/api/templates/{template_id}")
def update_template(template_id: str, template: ConfigTemplate, actor: str = Depends(verify_admin_dep)) -> ConfigTemplate:
    with data_lock:
        data = load_data_nolock()
        templates: List[Dict[str, Any]] = data.get('templates', [])
        template_to_update = next((t for t in templates if t['id'] == template_id), None)
        if not template_to_update: raise HTTPException(status_code=404, detail="未找到模板。")
        if template_to_update['name'] != template.name and any(t['name'] == template.name for t in templates):
             raise HTTPException(status_code=409, detail=f"名为 '{template.name}' 的模板已存在。")
        template_to_update.update(template.model_dump())
        log_action(data, actor, f"更新了配置模板 '{template.name}'。")
        save_data_nolock(data)
    return template

@router.delete("/api/templates/{template_id}", status_code=204)
def delete_template(template_id: str, actor: str = Depends(verify_admin_dep)) -> None:
    with data_lock:
        data = load_data_nolock()
        templates: List[Dict[str, Any]] = data.get('templates', [])
        template_to_delete = next((t for t in templates if t['id'] == template_id), None)
        if not template_to_delete: raise HTTPException(status_code=404, detail="未找到模板。")
        data['templates'] = [t for t in templates if t['id'] != template_id]
        log_action(data, actor, f"删除了配置模板 '{template_to_delete['name']}'。")
        save_data_nolock(data)
    return

@router.post("/api/policies", status_code=201)
def create_policy(policy: Policy, actor: str = Depends(verify_admin_dep)) -> Policy:
    with data_lock:
        data = load_data_nolock()
        if any(p['name'] == policy.name for p in data.get('policies', [])):
            raise HTTPException(status_code=409, detail=f"名为 '{policy.name}' 的策略已存在。")
        data.setdefault('policies', []).append(policy.model_dump())
        log_action(data, actor, f"创建了新合规策略 '{policy.name}'。")
        save_data_nolock(data)
    return policy

@router.put("/api/policies/{policy_id}")
def update_policy(policy_id: str, policy: Policy, actor: str = Depends(verify_admin_dep)) -> Policy:
    with data_lock:
        data = load_data_nolock()
        policies: List[Dict[str, Any]] = data.get('policies', [])
        policy_to_update = next((p for p in policies if p['id'] == policy_id), None)
        if not policy_to_update: raise HTTPException(status_code=404, detail="未找到策略。")
        if policy_to_update['name'] != policy.name and any(p['name'] == policy.name for p in policies):
             raise HTTPException(status_code=409, detail=f"名为 '{policy.name}' 的策略已存在。")
        policy_to_update.update(policy.model_dump())
        log_action(data, actor, f"更新了合规策略 '{policy.name}'。")
        save_data_nolock(data)
    return policy

@router.delete("/api/policies/{policy_id}", status_code=204)
def delete_policy(policy_id: str, actor: str = Depends(verify_admin_dep)) -> None:
    with data_lock:
        data = load_data_nolock()
        policies: List[Dict[str, Any]] = data.get('policies', [])
        policy_to_delete = next((p for p in policies if p['id'] == policy_id), None)
        if not policy_to_delete: raise HTTPException(status_code=404, detail="未找到策略。")
        data['policies'] = [p for p in policies if p['id'] != policy_id]
        log_action(data, actor, f"删除了合规策略 '{policy_to_delete['name']}'。")
        save_data_nolock(data)
    return

@router.put("/api/settings/ai")
def update_ai_settings(payload: AISettingsPayload, actor: str = Depends(verify_admin_dep)) -> Dict[str, Any]:
    with data_lock:
        data = load_data_nolock()
        data.setdefault('settings', {})['is_ai_analysis_enabled'] = payload.is_ai_analysis_enabled
        action = "启用" if payload.is_ai_analysis_enabled else "禁用"
        log_action(data, actor, f"全局 {action} 了后端AI智能分析功能。")
        save_data_nolock(data)
    return data['settings']

@router.post("/api/blockchains/{device_id}", status_code=201)
def add_block(device_id: str, payload: SubmissionPayload) -> Dict[str, Any]:
    with data_lock:
        data = load_data_nolock()
        new_block: Dict[str, Any] = services.perform_add_block(data, device_id, payload)
        log_action(data, payload.operator, f"为设备 '{device_id}' 添加了新配置 (版本 {new_block['data']['version']})。")
        save_data_nolock(data)
        return new_block

@router.post("/api/blockchains/{device_id}/rollback", status_code=201)
def rollback_to_version(device_id: str, payload: RollbackPayload, actor: str = Depends(verify_admin_dep)) -> Dict[str, Any]:
    with data_lock:
        data = load_data_nolock()
        # Ensure the actor from the dependency is the operator for this high-privilege action
        payload.operator = actor
        new_block: Dict[str, Any] = services.perform_rollback(data, device_id, payload)
        log_action(data, actor, f"将设备 '{device_id}' 回滚至版本 {payload.target_version} (新版本为 {new_block['data']['version']})。")
        save_data_nolock(data)
        return new_block


@router.get("/api/health")
def health_check() -> Dict[str, str]: return {"status": "ok", "mode": "simulation" if services.is_simulation_mode() else "live"}

# --- User & Session Management ---
@router.get("/api/users")
def get_users() -> List[Dict[str, Any]]:
    with data_lock: data = load_data_nolock()
    return data.get("users", [])

@router.post("/api/users", status_code=201)
def create_user(user_payload: UserUpdatePayload, actor: str = Depends(verify_admin_dep)) -> Dict[str, Any]:
    with data_lock:
        data = load_data_nolock()
        users: List[Dict[str, Any]] = data.get("users", [])
        if any(u['username'] == user_payload.username for u in users): raise HTTPException(status_code=409, detail="用户名已存在。")
        if not user_payload.password: raise HTTPException(status_code=400, detail="新用户必须设置密码。")
        new_id = max([u['id'] for u in users] or [0]) + 1
        new_user: Dict[str, Any] = {"id": new_id, "username": user_payload.username, "password": user_payload.password, "role": user_payload.role}
        users.append(new_user)
        data['users'] = users
        log_action(data, actor, f"创建了新用户 '{new_user['username']}'，角色为 '{new_user['role']}'。")
        save_data_nolock(data)
        return new_user

@router.put("/api/users/{user_id}")
def update_user(user_id: int, payload: UserUpdatePayload, actor: str = Depends(verify_admin_dep)) -> Dict[str, Any]:
    with data_lock:
        data = load_data_nolock()
        users: List[Dict[str, Any]] = data.get("users", [])
        user_to_update = next((u for u in users if u['id'] == user_id), None)
        if not user_to_update: raise HTTPException(status_code=404, detail="未找到用户。")
        log_message = f"更新了用户 '{payload.username}' (ID: {user_id}) 的信息。"
        user_to_update['username'] = payload.username; user_to_update['role'] = payload.role
        if payload.password: user_to_update['password'] = payload.password; log_message += " 密码已重置。"
        data['users'] = users
        log_action(data, actor, log_message)
        save_data_nolock(data)
        return user_to_update

@router.delete("/api/users/{user_id}", status_code=204)
def delete_user(user_id: int, actor: str = Depends(verify_admin_dep)) -> None:
    with data_lock:
        data = load_data_nolock()
        users: List[Dict[str, Any]] = data.get("users", [])
        user_to_delete = next((u for u in users if u['id'] == user_id), None)
        if not user_to_delete: raise HTTPException(status_code=404, detail="未找到用户。")
        data['users'] = [u for u in users if u['id'] != user_id]
        log_action(data, actor, f"删除了用户 '{user_to_delete['username']}' (ID: {user_id})。")
        save_data_nolock(data)
    return

@router.get("/api/sessions/{device_id}")
def get_device_sessions(device_id: str) -> List[Dict[str, str]]:
    with sessions_lock: return ACTIVE_SESSIONS.get(device_id, [])

@router.post("/api/sessions/{device_id}", status_code=204)
def join_device_session(device_id: str, payload: SessionPayload) -> None:
    with sessions_lock:
        current_sessions = ACTIVE_SESSIONS.get(device_id, [])
        updated_sessions = [s for s in current_sessions if s['sessionId'] != payload.sessionId]
        updated_sessions.append(payload.model_dump())
        ACTIVE_SESSIONS[device_id] = updated_sessions
    return

@router.delete("/api/sessions/{device_id}/{session_id}", status_code=204)
def leave_device_session_endpoint(device_id: str, session_id: str) -> None:
    with sessions_lock:
        if device_id in ACTIVE_SESSIONS:
            ACTIVE_SESSIONS[device_id] = [s for s in ACTIVE_SESSIONS[device_id] if s['sessionId'] != session_id]
            if not ACTIVE_SESSIONS[device_id]: del ACTIVE_SESSIONS[device_id]
    return