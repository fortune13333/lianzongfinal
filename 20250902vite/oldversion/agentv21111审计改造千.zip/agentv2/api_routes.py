# api_routes.py - All HTTP API endpoints for ChainTrace Agent

import logging
import json
import time
from fastapi import APIRouter, HTTPException, Header, Depends
from typing import Dict, List, Any, Optional

from sqlalchemy.orm import Session
from netmiko import ConnectHandler, NetmikoBaseException # type: ignore

from services import (
    is_simulation_mode,
    get_device_info,
    perform_add_block,
    get_running_config,
    perform_rollback,
    perform_pre_deployment_check,
    perform_ai_command_generation,
    perform_ai_config_check,
    check_command_against_rules
)
import crud
from database import get_db
from core import (
    config as app_config, ACTIVE_WEB_SESSIONS, sessions_lock,
    DevicePayload, ConfigPayload, SubmissionPayload, AuditTriggerPayload, SessionPayload,
    UserUpdatePayload, ConfigTemplate as TemplatePayload, BulkDeployPayload, Policy as PolicyPayload, AISettingsPayload, 
    RollbackPayload, BlockDict, AICommandGenerationRequest, AIConfigCheckRequest
)

router = APIRouter()

# --- New Granular Authorization Dependency ---
def require_permission(required_permission: str):
    """
    Dependency factory for requiring specific atomic permissions.
    - Admins are always granted access.
    - Operators are checked for the specific permission in their 'extra_permissions' field.
    """
    def dependency(actor: str = Header(..., alias="X-Actor-Username"), db: Session = Depends(get_db)) -> str:
        user = crud.get_user_by_username(db, actor)
        if not user:
            raise HTTPException(status_code=403, detail="Permission denied: Invalid user.")
        
        # Admins have all permissions
        if user.role == "admin":
            return actor
        
        # Check for specific permission for operators
        user_permissions = set((user.extra_permissions or "").split(','))
        if required_permission not in user_permissions:
            logging.warning(f"Authorization failed for operator '{actor}'. Required permission '{required_permission}' not found.")
            raise HTTPException(status_code=403, detail=f"Permission denied: Requires '{required_permission}' permission.")
        
        return actor
    return Depends(dependency)

# --- API Endpoints ---
@router.get("/api/data")
def get_all_data(db: Session = Depends(get_db)) -> Dict[str, Any]:
    # The CRUD function now returns the data in the frontend-expected format
    data = crud.get_all_data(db)
    
    # Enrich device data with netmiko type from config.ini
    enriched_devices: List[Dict[str, Any]] = []
    for device_dict in data.get('devices', []):
        device_id_upper = device_dict.get('id', '').upper()
        netmiko_type: Optional[str] = None
        if app_config.has_option('device_map', device_id_upper):
            try:
                # Use .get with a fallback to avoid errors on malformed entries
                parts = app_config.get('device_map', device_id_upper, fallback='').split(',')
                if len(parts) >= 2:
                    netmiko_type = parts[1].strip()
            except Exception:
                logging.warning(f"Could not parse netmiko type for {device_id_upper} from config.ini")
        
        enriched_device = device_dict.copy()
        enriched_device['netmiko_device_type'] = netmiko_type
        enriched_devices.append(enriched_device)
    
    data['devices'] = enriched_devices
    return data

@router.post("/api/reset", status_code=204)
def reset_data(actor: str = require_permission("system:reset"), db: Session = Depends(get_db)) -> None:
    crud.log_action(db, actor, "重置了所有应用数据到初始状态。")
    crud.reset_all_data(db)
    return

@router.post("/api/devices", status_code=201)
def add_device(device: DevicePayload, actor: str = require_permission("device:create"), db: Session = Depends(get_db)) -> DevicePayload:
    db_device = crud.get_device(db, device_id=device.id)
    if db_device:
        raise HTTPException(status_code=409, detail=f"设备 ID '{device.id}' 已存在。")
    
    new_device_orm = crud.create_device_with_genesis_block(db=db, device_payload=device)
    crud.log_action(db, actor, f"添加了新设备 '{device.name}' (ID: {device.id})。")
    
    # Return payload with policyIds included.
    device.policyIds = [p.id for p in new_device_orm.policies]
    return device

@router.put("/api/devices/{device_id}")
def update_device(device_id: str, device: DevicePayload, actor: str = require_permission("device:update"), db: Session = Depends(get_db)) -> DevicePayload:
    updated_device_orm = crud.update_device(db, device_id, device)
    if not updated_device_orm:
        raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}'。")
    
    crud.log_action(db, actor, f"更新了设备 '{device.name}' (ID: {device_id}) 的信息。")
    
    updated_payload = DevicePayload(
        id=updated_device_orm.id,
        name=updated_device_orm.name,
        ipAddress=updated_device_orm.ipAddress,
        type=updated_device_orm.type,
        policyIds=[p.id for p in updated_device_orm.policies]
    )
    return updated_payload


@router.delete("/api/devices/{device_id}", status_code=204)
def delete_device(device_id: str, actor: str = require_permission("device:delete"), db: Session = Depends(get_db)) -> None:
    device_to_delete = crud.get_device(db, device_id)
    if not device_to_delete:
        raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}'。")
    
    device_name = device_to_delete.name
    if crud.delete_device(db, device_id):
        crud.log_action(db, actor, f"删除了设备 '{device_name}' (ID: {device_id})。")
    return

@router.post("/api/sessions/{device_id}/save", status_code=200)
def save_session_and_audit(device_id: str, payload: AuditTriggerPayload, db: Session = Depends(get_db)) -> BlockDict:
    """Fetches the latest config from the device and creates a new block."""
    if is_simulation_mode():
        raise HTTPException(status_code=400, detail="模拟模式下无法保存会话。")
    
    # --- RACE CONDITION FIX ---
    # Immediately mark the session as clean to prevent auto-audit on disconnect.
    if payload.sessionId:
        with sessions_lock:
            if payload.sessionId in ACTIVE_WEB_SESSIONS:
                ACTIVE_WEB_SESSIONS[payload.sessionId]['is_dirty'] = False
                logging.info(f"Session {payload.sessionId} for device {device_id} marked as CLEAN due to explicit save.")

    device_info = get_device_info(device_id)
    if not device_info:
        raise HTTPException(status_code=404, detail=f"在配置文件中未找到设备 ID '{device_id}'。")

    try:
        latest_config_dict = get_running_config(device_id)
        latest_config = latest_config_dict["config"]
        audit_payload = SubmissionPayload(operator=payload.operator, config=latest_config)
        
        new_block = perform_add_block(db, device_id, audit_payload)
        crud.log_action(db, payload.operator, f"通过交互式会话为设备 '{device_id}' 保存并审计了新配置 (版本 {new_block['data']['version']})。")
        
        return new_block

    except NetmikoBaseException as e:
        logging.error(f"Netmiko error during session save for {device_id}: {e}")
        raise HTTPException(status_code=504, detail="从设备获取配置失败：设备响应超时或返回格式不正确。请检查设备状态和网络连接。")
    except Exception as e:
        logging.error(f"Unexpected error during session save for {device_id}: {e}")
        raise HTTPException(status_code=500, detail=f"保存在线会话时发生意外错误: {e}")

@router.post("/api/device/{device_id}/push_config", status_code=200)
def push_config_to_device(device_id: str, payload: ConfigPayload, actor: str = Header(..., alias="X-Actor-Username"), db: Session = Depends(get_db)) -> Dict[str, Any]:
    if is_simulation_mode():
        logging.info(f"SIMULATION MODE: Simulating config push for {device_id}.")
        return {"status": "success", "message": "配置推送模拟成功。"}
    
    # --- SECURITY FIX: Command Interception ---
    config_commands = payload.config.splitlines()
    for command in config_commands:
        violated_rule = check_command_against_rules(command)
        if violated_rule:
            raise HTTPException(status_code=400, detail=f"配置内容违反了实时拦截策略: '{violated_rule}' (命令: '{command}')")

    device_info = get_device_info(device_id)
    if not device_info:
        raise HTTPException(status_code=404, detail=f"在配置文件中未找到设备 ID '{device_id}'。")
    
    if not config_commands:
        raise HTTPException(status_code=400, detail="配置内容不能为空。")
    
    try:
        with ConnectHandler(**device_info) as net_connect:
            net_connect.enable()
            output: str = net_connect.send_config_set(config_commands)
        
        crud.log_action(db, actor, f"将配置非交互式地推送到设备 '{device_id}'。")
        return {"status": "success", "output": output}
    except NetmikoBaseException as e:
        logging.error(f"Netmiko error during config push for {device_id}: {e}")
        raise HTTPException(status_code=504, detail="推送配置失败：连接设备时出错。请检查设备状态和网络连接。")
    except Exception as e:
        logging.error(f"Unexpected error during config push for {device_id}: {e}")
        raise HTTPException(status_code=500, detail=f"推送配置时发生意外错误: {e}")

@router.get("/api/device/{device_id}/running-config")
def get_device_running_config_endpoint(device_id: str, actor: str = Header(..., alias="X-Actor-Username"), db: Session = Depends(get_db)) -> Dict[str, str]:
    if is_simulation_mode():
        db_device = crud.get_device_with_details(db, device_id)
        if not db_device or not db_device.blocks:
            raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}' 的区块链。")
        latest_block_data = json.loads(db_device.blocks[-1].data)
        return {"config": latest_block_data.get("config", "")}

    try:
        return get_running_config(device_id)
    except HTTPException as e:
        raise e
    except Exception as e:
        logging.error(f"Unexpected error getting running-config for {device_id}: {e}")
        raise HTTPException(status_code=500, detail=f"获取设备配置时发生意外错误: {e}")

# --- NEW AI PROXY ENDPOINTS ---
@router.post("/api/ai/generate-command")
def proxy_ai_generate_command(payload: AICommandGenerationRequest, actor: str = Header(..., alias="X-Actor-Username"), db: Session = Depends(get_db)) -> Dict[str, str]:
    try:
        commands = perform_ai_command_generation(payload, db)
        crud.log_action(db, actor, f"为设备 '{payload.device.get('id', 'N/A')}' 使用AI生成了命令。")
        return {"commands": commands}
    except HTTPException as e:
        raise e
    except Exception as e:
        logging.error(f"Error in AI command generation proxy: {e}")
        raise HTTPException(status_code=500, detail=f"AI命令生成时发生意外错误: {e}")

@router.post("/api/ai/check-config")
def proxy_ai_check_config(payload: AIConfigCheckRequest, actor: str = Header(..., alias="X-Actor-Username"), db: Session = Depends(get_db)) -> Dict[str, str]:
    try:
        report = perform_ai_config_check(payload)
        crud.log_action(db, actor, f"为设备 '{payload.device.get('id', 'N/A')}' 执行了AI配置体检。")
        return {"report": report}
    except HTTPException as e:
        raise e
    except Exception as e:
        logging.error(f"Error in AI config check proxy: {e}")
        raise HTTPException(status_code=500, detail=f"AI配置体检时发生意外错误: {e}")

@router.post("/api/bulk-deploy")
def bulk_deploy_template(payload: BulkDeployPayload, actor: str = require_permission("template:manage"), db: Session = Depends(get_db)) -> Dict[str, Any]:
    template = crud.get_template(db, payload.template_id)
    if not template: raise HTTPException(status_code=404, detail="未找到模板。")
    
    success_count = 0
    failures: List[str] = []
    results: List[Dict[str, Any]] = []

    for device_id in payload.device_ids:
        device_name_for_logs = "Unknown"
        try:
            device = crud.get_device(db, device_id)
            if not device:
                raise Exception("在数据库中未找到设备元数据。")
            device_name_for_logs = device.name

            rendered_config = template.content.replace("{{ device.name }}", device.name)
            rendered_config = rendered_config.replace("{{ device.id }}", device.id)
            rendered_config = rendered_config.replace("{{ device.ipAddress }}", device.ipAddress)
            
            # --- SECURITY FIX: Command Interception ---
            for command in rendered_config.splitlines():
                violated_rule = check_command_against_rules(command)
                if violated_rule:
                    raise HTTPException(status_code=400, detail=f"模板内容违反了实时拦截策略: '{violated_rule}' (命令: '{command}')")

            # STEP 1: Perform pre-flight compliance check. This will raise HTTPException on failure.
            perform_pre_deployment_check(db, device_id, rendered_config)
            
            # STEP 2: If check passes, push the configuration to the device.
            if not is_simulation_mode():
                device_info_dict = get_device_info(device_id)
                if not device_info_dict: 
                    raise Exception("在 config.ini 中未找到设备。")
                with ConnectHandler(**device_info_dict) as net_connect:
                    net_connect.enable()
                    net_connect.send_config_set(rendered_config.splitlines())
            
            # STEP 3: If push is successful, get the REAL running config to ensure what's stored is canonical.
            final_config = rendered_config
            if not is_simulation_mode():
                final_config_dict = get_running_config(device_id)
                final_config = final_config_dict["config"]

            # STEP 4: Add the block, skipping the now-redundant compliance check.
            audit_payload = SubmissionPayload(operator=actor, config=final_config)
            new_block = perform_add_block(db, device_id, audit_payload, skip_compliance_check=True)
            
            # If we reach here, everything was successful for this device.
            crud.log_action(db, actor, f"通过批量部署模板 '{template.name}' 更新了设备 '{device_id}' (版本 {new_block['data']['version']})。")
            success_count += 1
            results.append({"device_id": device_id, "device_name": device.name, "status": "success", "message": f"部署成功，新版本为 {new_block['data']['version']}。"})
            
        except HTTPException as e:
            logging.warning(f"Deployment failed for {device_id} due to HTTP Exception: {e.detail}")
            failures.append(f"{device_id} ({device_name_for_logs}): {e.status_code}: {e.detail}")
            results.append({"device_id": device_id, "device_name": device_name_for_logs, "status": "failure", "message": f"{e.status_code}: {e.detail}"})
        except Exception as e:
            logging.error(f"Deployment failed for {device_id} due to generic Exception: {e}")
            failures.append(f"{device_id} ({device_name_for_logs}): {e}")
            results.append({"device_id": device_id, "device_name": device_name_for_logs, "status": "failure", "message": str(e)})

    crud.create_deployment_record(db, actor, template.name, payload.device_ids, results)
    
    message = f"部署完成。{success_count} 台成功，{len(failures)} 台失败。"
    return {"message": message, "success_count": success_count, "failures": failures}


@router.post("/api/templates", status_code=201)
def create_template(template: TemplatePayload, actor: str = require_permission("template:manage"), db: Session = Depends(get_db)) -> TemplatePayload:
    if crud.get_template_by_name(db, template.name):
        raise HTTPException(status_code=409, detail=f"名为 '{template.name}' 的模板已存在。")
    crud.create_template(db, template)
    crud.log_action(db, actor, f"创建了新配置模板 '{template.name}'。")
    return template

@router.put("/api/templates/{template_id}")
def update_template(template_id: str, template: TemplatePayload, actor: str = require_permission("template:manage"), db: Session = Depends(get_db)) -> TemplatePayload:
    db_template = crud.get_template(db, template_id)
    if not db_template:
        raise HTTPException(status_code=404, detail="未找到模板。")
    if db_template.name != template.name and crud.get_template_by_name(db, template.name):
        raise HTTPException(status_code=409, detail=f"名为 '{template.name}' 的模板已存在。")
    crud.update_template(db, template_id, template)
    crud.log_action(db, actor, f"更新了配置模板 '{template.name}'。")
    return template

@router.delete("/api/templates/{template_id}", status_code=204)
def delete_template(template_id: str, actor: str = require_permission("template:manage"), db: Session = Depends(get_db)) -> None:
    template = crud.get_template(db, template_id)
    if not template:
        raise HTTPException(status_code=404, detail="未找到模板。")
    crud.delete_template(db, template_id)
    crud.log_action(db, actor, f"删除了配置模板 '{template.name}'。")
    return

@router.post("/api/policies", status_code=201)
def create_policy(policy: PolicyPayload, actor: str = require_permission("policy:manage"), db: Session = Depends(get_db)) -> PolicyPayload:
    if crud.get_policy_by_name(db, policy.name):
        raise HTTPException(status_code=409, detail=f"名为 '{policy.name}' 的策略已存在。")
    crud.create_policy(db, policy)
    crud.log_action(db, actor, f"创建了新合规策略 '{policy.name}'。")
    return policy

@router.put("/api/policies/{policy_id}")
def update_policy(policy_id: str, policy: PolicyPayload, actor: str = require_permission("policy:manage"), db: Session = Depends(get_db)) -> PolicyPayload:
    db_policy = crud.get_policy(db, policy_id)
    if not db_policy:
        raise HTTPException(status_code=404, detail="未找到策略。")
    if db_policy.name != policy.name and crud.get_policy_by_name(db, policy.name):
        raise HTTPException(status_code=409, detail=f"名为 '{policy.name}' 的策略已存在。")
    crud.update_policy(db, policy_id, policy)
    crud.log_action(db, actor, f"更新了合规策略 '{policy.name}'。")
    return policy

@router.delete("/api/policies/{policy_id}", status_code=204)
def delete_policy(policy_id: str, actor: str = require_permission("policy:manage"), db: Session = Depends(get_db)) -> None:
    policy = crud.get_policy(db, policy_id)
    if not policy:
        raise HTTPException(status_code=404, detail="未找到策略。")
    crud.delete_policy(db, policy_id)
    crud.log_action(db, actor, f"删除了合规策略 '{policy.name}'。")
    return

@router.put("/api/settings/ai")
def update_ai_settings(payload: AISettingsPayload, actor: str = require_permission("system:settings"), db: Session = Depends(get_db)) -> Dict[str, Any]:
    crud.update_setting(db, "is_ai_analysis_enabled", str(payload.is_ai_analysis_enabled))
    action = "启用" if payload.is_ai_analysis_enabled else "禁用"
    crud.log_action(db, actor, f"全局 {action} 了后端AI智能分析功能。")
    
    if payload.auto_audit_ai_analysis_mode:
        crud.update_setting(db, "auto_audit_ai_analysis_mode", payload.auto_audit_ai_analysis_mode)
        mode_text = "“尽力而为”" if payload.auto_audit_ai_analysis_mode == 'best_effort' else "“完全禁用”"
        crud.log_action(db, actor, f"将“断连自动审计”的AI分析模式设置为 {mode_text}。")

    return crud.get_settings_as_dict(db)

@router.post("/api/blockchains/{device_id}", status_code=201)
def add_block(device_id: str, payload: SubmissionPayload, db: Session = Depends(get_db)) -> BlockDict:
    new_block = perform_add_block(db, device_id, payload)
    crud.log_action(db, payload.operator, f"为设备 '{device_id}' 添加了新配置 (版本 {new_block['data']['version']})。")
    return new_block

@router.post("/api/blockchains/{device_id}/rollback", status_code=201)
def rollback_to_version(device_id: str, payload: RollbackPayload, actor: str = require_permission("rollback:execute"), db: Session = Depends(get_db)) -> BlockDict:
    payload.operator = actor
    new_block = perform_rollback(db, device_id, payload)
    crud.log_action(db, actor, f"将设备 '{device_id}' 回滚至版本 {payload.target_version} (新版本为 {new_block['data']['version']})。")
    return new_block

@router.get("/api/health")
def health_check() -> Dict[str, str]: return {"status": "ok", "mode": "simulation" if is_simulation_mode() else "live"}

@router.get("/api/users")
def get_users(db: Session = Depends(get_db)) -> List[Dict[str, Any]]:
    users = crud.get_users(db)
    return [{"id": u.id, "username": u.username, "password": u.password, "role": u.role, "extra_permissions": u.extra_permissions} for u in users]

@router.post("/api/users", status_code=201)
def create_user(user_payload: UserUpdatePayload, actor: str = require_permission("user:manage"), db: Session = Depends(get_db)) -> Dict[str, Any]:
    if crud.get_user_by_username(db, user_payload.username):
        raise HTTPException(status_code=409, detail="用户名已存在。")
    if not user_payload.password:
        raise HTTPException(status_code=400, detail="新用户必须设置密码。")
    
    new_user = crud.create_user(db, user_payload)
    crud.log_action(db, actor, f"创建了新用户 '{new_user.username}'，角色为 '{new_user.role}'。")
    return {"id": new_user.id, "username": new_user.username, "password": new_user.password, "role": new_user.role, "extra_permissions": new_user.extra_permissions}

@router.put("/api/users/{user_id}")
def update_user(user_id: int, payload: UserUpdatePayload, actor: str = require_permission("user:manage"), db: Session = Depends(get_db)) -> Dict[str, Any]:
    user_to_update = crud.get_user(db, user_id)
    if not user_to_update:
        raise HTTPException(status_code=404, detail="未找到用户。")
    
    if payload.username != user_to_update.username and crud.get_user_by_username(db, payload.username):
        raise HTTPException(status_code=409, detail="用户名已存在。")
        
    updated_user = crud.update_user(db, user_id, payload)
    log_message = f"更新了用户 '{payload.username}' (ID: {user_id}) 的信息。"
    if payload.password: log_message += " 密码已重置。"
    crud.log_action(db, actor, log_message)
    return {"id": updated_user.id, "username": updated_user.username, "password": updated_user.password, "role": updated_user.role, "extra_permissions": updated_user.extra_permissions}

@router.delete("/api/users/{user_id}", status_code=204)
def delete_user(user_id: int, actor: str = require_permission("user:manage"), db: Session = Depends(get_db)) -> None:
    user_to_delete = crud.get_user(db, user_id)
    if not user_to_delete:
        raise HTTPException(status_code=404, detail="未找到用户。")
    if user_to_delete.username == actor:
        raise HTTPException(status_code=400, detail="不能删除自己的账户。")
    
    username = user_to_delete.username
    crud.delete_user(db, user_id)
    crud.log_action(db, actor, f"删除了用户 '{username}' (ID: {user_id})。")
    return

# --- SESSION HANDLING REWRITE ---
SESSION_TIMEOUT_SECONDS = 10 # A session is stale if not updated in 10 seconds.

@router.get("/api/sessions/{device_id}")
def get_device_sessions(device_id: str) -> List[Dict[str, str]]:
    """
    Returns a list of active users for a specific device.
    This now iterates through the global session dict, which is keyed by session_id.
    """
    active_users_for_device: List[Dict[str, str]] = []
    now = time.time()
    stale_sessions = []
    with sessions_lock:
        for session_id, session_data in ACTIVE_WEB_SESSIONS.items():
            if (now - session_data['timestamp']) > SESSION_TIMEOUT_SECONDS:
                stale_sessions.append(session_id)
                continue
            if session_data['device_id'] == device_id:
                active_users_for_device.append({
                    'username': session_data['username'],
                    'sessionId': session_id
                })
        # Clean up stale sessions
        for session_id in stale_sessions:
            del ACTIVE_WEB_SESSIONS[session_id]
            
    return active_users_for_device

@router.post("/api/sessions/{device_id}", status_code=204)
def join_device_session(device_id: str, payload: SessionPayload) -> None:
    """
    Acts as a heartbeat endpoint to keep a user's session alive for the 'who is viewing' feature.
    This now correctly updates the session in the global dict keyed by session_id.
    """
    with sessions_lock:
        # Update existing session or create a new one if it doesn't exist (e.g., after agent restart)
        ACTIVE_WEB_SESSIONS[payload.sessionId] = {
            'username': payload.username,
            'sessionId': payload.sessionId, # For consistency in the dict, though redundant with the key
            'device_id': device_id,
            'timestamp': time.time(),
            'is_dirty': ACTIVE_WEB_SESSIONS.get(payload.sessionId, {}).get('is_dirty', False)
        }
    return

@router.delete("/api/sessions/{device_id}/{session_id}", status_code=204)
def leave_device_session_endpoint(device_id: str, session_id: str) -> None:
    """
    Removes a user's session when they navigate away.
    This correctly removes the session by its unique ID.
    """
    with sessions_lock:
        if session_id in ACTIVE_WEB_SESSIONS:
            # We don't need to check device_id here, session_id is unique enough.
            del ACTIVE_WEB_SESSIONS[session_id]
    return