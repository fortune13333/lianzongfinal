# ai_drivers/gemini_driver.py - AI Driver for Google Gemini
import logging
import json
import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold
from fastapi import HTTPException
from typing import Dict, List, Any

from core import config

# --- Gemini AI Configuration ---
try:
    gemini_api_key = config.get('ai_provider', 'gemini_api_key')
    if not gemini_api_key or "your" in gemini_api_key:
        raise ValueError("Gemini API key is missing or is a placeholder in config.ini")
    
    genai.configure(api_key=gemini_api_key)
    logging.info("Gemini AI client configured successfully for gemini_driver.")
    genai_configured = True
except (ValueError, Exception) as e:
    genai_configured = False
    logging.error(f"Failed to configure Gemini client in gemini_driver: {e}")

def _get_model():
    """Initializes and returns the Gemini model instance."""
    # For high-frequency analysis tasks, gemini-2.5-flash is more suitable due to higher rate limits.
    return genai.GenerativeModel(model_name="gemini-2.5-flash")

def _call_gemini_with_error_handling(prompt: str, expect_json: bool = True) -> str:
    """
    Calls the Gemini API with a given prompt, including error handling and retry logic.
    """
    if not genai_configured:
        raise HTTPException(status_code=503, detail="Gemini AI service is not configured or failed to initialize.")
    
    model = _get_model()
    
    generation_config = {
        "temperature": 0.2,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 8192,
    }
    if expect_json:
        generation_config["response_mime_type"] = "application/json"
        
    safety_settings = {
        HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
    }

    try:
        response = model.generate_content(
            prompt,
            generation_config=generation_config, # type: ignore
            safety_settings=safety_settings
        )
        if not response.parts:
            logging.warning("Gemini response was blocked or empty.")
            raise HTTPException(status_code=500, detail="AI response was blocked due to safety settings or was empty.")
        return response.text
    except Exception as e:
        logging.error(f"Gemini API call failed: {e}")
        error_str = str(e).lower()
        if "api key not valid" in error_str:
            raise HTTPException(status_code=401, detail="无效的 Gemini API 密钥。")
        if "user location is not supported" in error_str:
            raise HTTPException(status_code=403, detail="Gemini AI 服务在您所在的地区不可用。请尝试使用网络代理。")
        if "timed out" in error_str or "deadline exceeded" in error_str:
            raise HTTPException(status_code=504, detail="无法连接到 Google AI 服务（请求超时）。请检查服务器的网络连接、防火墙和代理设置。")
        raise HTTPException(status_code=500, detail=f"AI调用时发生未知错误: {e}")

def analyze_changes(previous_config: str, new_config: str, change_description: str) -> Dict[str, Any]:
    """
    Analyzes the difference between two configurations using Gemini AI.
    Handles both standard updates and special rollback analysis.
    """
    if change_description == "rollback":
        prompt = f"""
        你是一位网络回滚专家。
        当前配置（Current Config）:
        ```
        {previous_config}
        ```
        目标配置（Target Config）:
        ```
        {new_config}
        ```
        任务:
        1. 总结回滚的目的。
        2. 生成一份精确的、分步的网络命令清单 (Rollback Plan)，用于从“当前配置”手动恢复到“目标配置”。
        3. 分析这次回滚解决了或规避了哪些具体的技术或安全风险。

        以以下JSON格式返回结果，不要添加任何其他解释:
        {{
            "summary": "...",
            "analysis": {{
                "rollback_purpose": "...",
                "rollback_plan": ["...", "..."]
            }},
            "security_risks": ["...", "..."],
            "diff": "N/A"
        }}
        """
    else:
        prompt = f"""
        你是一位资深的网络工程师，负责代码审查。请分析'Old Config'和'New Config'之间的配置变更。
        'New Config'是最新版本。你的分析必须使用简体中文。
        
        Old Config:
        ```
        {previous_config}
        ```
        
        New Config:
        ```
        {new_config}
        ```

        你的任务是返回一个JSON对象，必须包含四个键："diff", "summary", "analysis", "security_risks"。
        - "diff": 生成一份清晰的、逐行的差异对比。使用'+'表示新增，'-'表示删除。
        - "summary": 用一句精炼的中文总结本次变更的核心目的。
        - "analysis": 提供一份详细的技术分析，解释具体变更内容、技术目的和潜在影响。
        - "security_risks": 提供一份专业的安全评估，指出潜在的安全漏洞、最佳实践违规或改进点。如果没有，请明确说明。
        
        返回纯粹的、原始的JSON对象，不要包含任何额外的文本或Markdown标记。
        """

    response_text = _call_gemini_with_error_handling(prompt, expect_json=True)
    
    try:
        result = json.loads(response_text)
        
        # --- BUG FIX: Robustly handle 'diff' field ---
        # Gemini might return a list of strings for diff instead of a single string.
        if 'diff' in result and isinstance(result['diff'], list):
            logging.warning("Gemini returned 'diff' as a list. Joining into a single string.")
            result['diff'] = '\n'.join(result['diff'])

        return result
    except json.JSONDecodeError as e:
        logging.error(f"Failed to parse Gemini JSON response for analysis: {e}. Response was: {response_text}")
        raise HTTPException(status_code=500, detail="AI返回了无效的JSON格式。")

def audit_compliance(policies: List[Dict[str, Any]], previous_config: str, new_config: str) -> Dict[str, Any]:
    """
    Audits a new configuration against a set of policies using Gemini AI.
    """
    if not policies:
        return {"overall_status": "passed", "results": []}

    policy_texts = "\n".join([f"- Policy ID: '{p['id']}', Name: '{p['name']}', Rule: '{p['rule']}'" for p in policies])
    
    prompt = f"""
    你是一位网络合规审计师。你的任务是判断'New Config'相对于'Old Config'的变更，是否违反了下面列出的任何一条'Compliance Policies'。

    Compliance Policies:
    {policy_texts}

    Old Config:
    ```
    {previous_config}
    ```

    New Config:
    ```
    {new_config}
    ```

    指令:
    1. 分析从旧配置到新配置的变更。
    2. 对于【每一条】策略，判断新配置是否合规。
    3. 为每条策略提供一个简短的'details'字符串（简体中文），解释你的判定理由。
    4. 如果【任何一条】策略被违反，将'overall_status'设为'failed'，否则设为'passed'。

    以如下JSON格式返回结果，不要添加任何其他文本或Markdown标记：
    {{
        "overall_status": "passed_or_failed",
        "results": [
            {{
                "policy_id": "{policies[0]['id']}",
                "policy_name": "{policies[0]['name']}",
                "status": "passed_or_failed",
                "details": "你的精炼中文判定理由。"
            }}
        ]
    }}
    """
    response_text = _call_gemini_with_error_handling(prompt, expect_json=True)
    try:
        report = json.loads(response_text)

        if report.get("overall_status") == "failed":
            failed_policies = [res["policy_name"] for res in report.get("results", []) if res.get("status") == "failed"]
            error_detail = f"配置违反了合规策略: {', '.join(failed_policies)}"
            raise HTTPException(status_code=400, detail=error_detail)

        return report
    except json.JSONDecodeError as e:
        logging.error(f"Failed to parse Gemini JSON response for audit: {e}. Response was: {response_text}")
        raise HTTPException(status_code=500, detail="AI合规性审计返回了无效的JSON格式。")