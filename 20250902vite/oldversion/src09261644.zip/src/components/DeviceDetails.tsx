import React, { useState, useEffect, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { Block, SessionUser } from '../types';
import { verifyChain } from '../utils/crypto';
import { joinDeviceSessionAPI, getActiveSessionsAPI } from '../utils/session';
import HistoryItem from './HistoryItem';
import BlockDetailsModal from './BlockDetailsModal';
import VerificationModal, { VerificationResult } from './VerificationModal';
import { CheckCircleIcon } from './AIIcons';
import InteractiveTerminal from './InteractiveTerminal';

interface DeviceDetailsProps {
  sessionId: string;
}

const DeviceDetails: React.FC<DeviceDetailsProps> = ({ sessionId }) => {
  const {
    selectedDevice,
    blockchains,
    selectDevice,
    currentUser,
    settings,
    promptRollback,
  } = useStore(state => ({
    selectedDevice: state.selectedDevice,
    blockchains: state.blockchains,
    selectDevice: state.selectDevice,
    currentUser: state.currentUser!,
    settings: state.settings,
    promptRollback: state.promptRollback,
  }));

  const [isVerifying, setIsVerifying] = useState(false);
  
  const [selectedBlock, setSelectedBlock] = useState<Block | null>(null);
  const [verificationResults, setVerificationResults] = useState<VerificationResult[]>([]);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [activeSessions, setActiveSessions] = useState<SessionUser[]>([]);

  const deviceChain = useMemo(() => selectedDevice ? blockchains[selectedDevice.id] || [] : [], [blockchains, selectedDevice]);

  useEffect(() => {
    if (!selectedDevice || !settings.agentApiUrl) return;
    
    // Use a stable ID for the dependency array to avoid re-running on every data refresh.
    const deviceId = selectedDevice.id;
    joinDeviceSessionAPI(deviceId, currentUser.username, sessionId, settings.agentApiUrl);

    const fetchSessions = async () => {
        const sessions = await getActiveSessionsAPI(deviceId, settings.agentApiUrl!);
        setActiveSessions(sessions);
    };
    fetchSessions();
    const intervalId = setInterval(fetchSessions, 3000); // More frequent check for better real-time feel

    return () => clearInterval(intervalId);
  }, [selectedDevice?.id, sessionId, currentUser.username, settings.agentApiUrl]);


  const handleVerifyChain = async () => {
    if (!selectedDevice) return;
    const chain = blockchains[selectedDevice.id];
    if (!chain) return;

    setIsVerificationModalOpen(true);
    setIsVerifying(true);
    setVerificationResults(chain.map(block => ({ index: block.index, status: 'pending' })));

    await verifyChain(chain, (index, status, details) => {
      setVerificationResults(prev => prev.map(r => r.index === index ? { ...r, status, details } : r));
    });
    
    setIsVerifying(false);
  };
  
  const handleSelectBlock = (block: Block) => {
    setSelectedBlock(block);
  };

  const otherSessions = activeSessions.filter(s => s.sessionId !== sessionId);

  if (!selectedDevice) {
    return (
      <div className="text-center p-8">
        <p className="text-text-400">设备未选择，请返回仪表盘。</p>
        <button onClick={() => selectDevice(null)} className="mt-4 text-sm bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-md">返回仪表盘</button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex justify-between items-start">
        <div>
            <button onClick={() => selectDevice(null)} className="text-sm text-primary-400 hover:text-primary-300 mb-2">&larr; 返回仪表盘</button>
            <h2 className="text-3xl font-bold text-text-100">{selectedDevice.name}</h2>
            <p className="text-text-400 font-mono">{selectedDevice.ipAddress} ({selectedDevice.type})</p>
            {otherSessions.length > 0 && (
                <div className="mt-2 text-xs text-amber-400 animate-pulse">
                    同时查看: {otherSessions.map(s => s.username).join(', ')}
                </div>
            )}
        </div>
        <div className="flex items-center gap-2">
            <button
                onClick={handleVerifyChain}
                className="flex items-center gap-2 text-sm bg-bg-800 hover:bg-bg-700 text-text-100 font-bold py-2 px-3 rounded-md transition-colors"
                aria-label="验证链完整性"
            >
                <CheckCircleIcon />
                <span>验证链完整性</span>
            </button>
        </div>
      </div>

      {/* Main Content Layout */}
      <div>
        <div className="bg-bg-900 rounded-lg shadow-lg overflow-hidden">
            <InteractiveTerminal
              sessionId={sessionId}
            />
        </div>

        <div className="mt-8">
            <h3 className="text-xl font-semibold text-text-200 border-b-2 border-bg-800 pb-2 mb-4">配置历史 ({deviceChain.length})</h3>
            <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
            {deviceChain.slice().reverse().map((block, index) => (
                <HistoryItem
                key={block.hash}
                block={block}
                isLatest={index === 0}
                onSelectBlock={() => handleSelectBlock(block)}
                onRollback={() => promptRollback(block)}
                />
            ))}
            </div>
        </div>
      </div>
      
      {/* Modals */}
      {selectedBlock && (
        <BlockDetailsModal 
            block={selectedBlock}
            prevConfig={deviceChain.find(b => b.index === selectedBlock.index - 1)?.data.config || ''}
            onClose={() => setSelectedBlock(null)}
        />
      )}
      {isVerificationModalOpen && (
        <VerificationModal 
            results={verificationResults}
            chain={deviceChain}
            isVerifying={isVerifying}
            onClose={() => setIsVerificationModalOpen(false)}
        />
      )}
    </div>
  );
};

export default DeviceDetails;