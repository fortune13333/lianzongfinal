// FIX: Import React to use React.createElement for custom components in toast messages.
import React from 'react';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { Device, Block, AppSettings, User, AuditLogEntry, ConfigTemplate, Policy, BackendSettings, DeploymentRecord } from '../types';
import { toast } from 'react-hot-toast';
import { createApiUrl } from '../utils/apiUtils';
import { AppError } from '../utils/errors';
import { geminiService } from '../services/geminiService';
import ProgressToast, { ProgressStep } from '../components/ProgressToast';

// --- State and Actions Interfaces ---
interface AppState {
    devices: Device[];
    allUsers: User[];
    auditLog: AuditLogEntry[];
    templates: ConfigTemplate[];
    policies: Policy[];
    deploymentHistory: DeploymentRecord[];
    blockchains: Record<string, Block[]>;
    openDeviceIds: string[];
    activeDeviceId: string | null;
    isLoading: boolean;
    settings: AppSettings;
    backendSettings: BackendSettings;
    currentUser: User | null;
    agentMode: 'live' | 'simulation';
    aiStatus: { isOk: boolean; message: string; code: string };
    isSettingsModalOpen: boolean;
    isDeviceModalOpen: boolean;
    deviceToEdit: Device | null;
    isApiKeyModalOpen: boolean;
    rollbackTarget: Block | null;
}

interface AppActions {
    init: () => void;
    login: (user: User, agentUrl: string) => void;
    logout: () => void;
    fetchData: (isSilent?: boolean) => Promise<void>;
    openSettingsModal: () => void;
    closeSettingsModal: () => void;
    openDeviceModalForAdd: () => void;
    openDeviceModalForEdit: (device: Device) => void;
    closeDeviceModal: () => void;
    openApiKeyModal: () => void;
    closeApiKeyModal: () => void;
    updateSettings: (newSettings: Partial<AppSettings>) => void;
    updateBackendAISettings: (newSettings: BackendSettings) => Promise<void>;
    addAgentUrlToHistory: (url: string) => void;
    openDeviceTab: (deviceId: string) => void;
    closeDeviceTab: (deviceId: string) => void;
    setActiveDeviceTab: (deviceId: string) => void;
    resetData: () => Promise<void>;
    addNewDevice: (deviceData: Omit<Device, 'ipAddress'> & { ipAddress: string; policyIds?: string[] }) => Promise<void>;
    updateDevice: (deviceId: string, deviceData: Omit<Device, 'ipAddress'> & { ipAddress: string; policyIds?: string[] }) => Promise<void>;
    deleteDevice: (deviceId: string) => Promise<void>;
    promptRollback: (targetBlock: Block) => void;
    cancelRollback: () => void;
    executeRollback: () => Promise<void>;
}

// --- Default State Definitions ---
const DEFAULT_SETTINGS: AppSettings = {
  ai: {
    analysis: { apiUrl: '' },
    commandGeneration: { enabled: true, apiUrl: '' },
    configCheck: { enabled: true, apiUrl: '' },
  },
  agentApiUrl: '',
  theme: 'cyan',
  bgTheme: 'zinc',
  agentUrlHistory: [],
};

const DEFAULT_BACKEND_SETTINGS: BackendSettings = {
    is_ai_analysis_enabled: true,
};

const INITIAL_STATE: AppState = {
    devices: [],
    allUsers: [],
    auditLog: [],
    templates: [],
    policies: [],
    deploymentHistory: [],
    blockchains: {},
    openDeviceIds: [],
    activeDeviceId: null,
    isLoading: true,
    settings: DEFAULT_SETTINGS,
    backendSettings: DEFAULT_BACKEND_SETTINGS,
    currentUser: null,
    agentMode: 'live',
    aiStatus: { isOk: true, message: '', code: '' },
    isSettingsModalOpen: false,
    isDeviceModalOpen: false,
    deviceToEdit: null,
    isApiKeyModalOpen: false,
    rollbackTarget: null,
};

// --- Zustand Store Creation ---
export const useStore = create<AppState & AppActions>()(
    persist(
        (set, get) => ({
            ...INITIAL_STATE,

            // --- Initialization and Auth ---
            init: () => {
                const storedUser = sessionStorage.getItem('chaintrace_user');
                if (storedUser) {
                    set({ currentUser: JSON.parse(storedUser) });
                }
                try {
                    geminiService.checkKeyAvailability();
                } catch (error) {
                    if (error instanceof AppError) set({ aiStatus: { isOk: false, message: 'Google Gemini API 密钥未配置。', code: error.code } });
                    else if (error instanceof Error) set({ aiStatus: { isOk: false, message: error.message, code: 'UNKNOWN_RUNTIME_ERROR' } });
                }
            },
            login: (user, agentUrl) => {
                get().updateSettings({ agentApiUrl: agentUrl });
                get().addAgentUrlToHistory(agentUrl);
                set({ currentUser: user });
                sessionStorage.setItem('chaintrace_user', JSON.stringify(user));
                toast.success(`欢迎, ${user.username}!`);
            },
            logout: () => {
                set({ currentUser: null, openDeviceIds: [], activeDeviceId: null });
                sessionStorage.removeItem('chaintrace_user');
                toast.success('您已成功登出。');
            },

            // --- Data Fetching ---
            fetchData: async (isSilent = false) => {
                const { agentApiUrl } = get().settings;
                if (!agentApiUrl) {
                    set({
                        isLoading: false,
                        agentMode: 'simulation',
                        devices: [],
                        blockchains: {},
                        allUsers: [],
                        auditLog: [],
                        templates: [],
                        policies: [],
                        deploymentHistory: [],
                    });
                    toast.error("未配置代理 API 地址，无法获取数据。");
                    return;
                }
                if (!isSilent) {
                    set({ isLoading: true });
                }
                try {
                    const url = createApiUrl(agentApiUrl, '/api/data');
                    const response = await fetch(url, { cache: 'no-cache' });
                    if (!response.ok) {
                        throw new Error(`无法连接到代理或代理返回错误 (${response.status})。`);
                    }
                    const data = await response.json();
                    
                    set({
                        devices: data.devices,
                        blockchains: data.blockchains,
                        allUsers: data.users,
                        auditLog: data.audit_log,
                        templates: data.templates,
                        policies: data.policies,
                        deploymentHistory: data.deployment_history || [],
                        backendSettings: data.settings || DEFAULT_BACKEND_SETTINGS,
                        agentMode: 'live',
                        isLoading: false,
                    });
                } catch (error) {
                    const msg = error instanceof Error ? error.message : '未知错误。';
                    toast.error(`数据加载失败: ${msg}`);
                    set({ isLoading: false, agentMode: 'simulation' });
                }
            },

            // --- Modals ---
            openSettingsModal: () => set({ isSettingsModalOpen: true }),
            closeSettingsModal: () => set({ isSettingsModalOpen: false }),
            openDeviceModalForAdd: () => set({ isDeviceModalOpen: true, deviceToEdit: null }),
            openDeviceModalForEdit: (device) => set({ isDeviceModalOpen: true, deviceToEdit: device }),
            closeDeviceModal: () => set({ isDeviceModalOpen: false, deviceToEdit: null }),
            openApiKeyModal: () => set({ isApiKeyModalOpen: true }),
            closeApiKeyModal: () => set({ isApiKeyModalOpen: false }),
            
            // --- Settings ---
            updateSettings: (newSettings) => set((state) => ({
                settings: { ...state.settings, ...newSettings }
            })),
            updateBackendAISettings: async (newSettings) => {
                const { agentApiUrl } = get().settings;
                const { currentUser } = get();
                if (!agentApiUrl || !currentUser) {
                    toast.error("无法更新后端设置：未连接到代理或未登录。");
                    return;
                }
                const toastId = toast.loading("正在更新全局 AI 设置...");
                try {
                    const url = createApiUrl(agentApiUrl, '/api/settings/ai');
                    const response = await fetch(url, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Actor-Username': currentUser.username
                        },
                        body: JSON.stringify(newSettings),
                    });
                    if (!response.ok) {
                        const err = await response.json().catch(() => ({ detail: '未知错误' }));
                        throw new Error(err.detail);
                    }
                    const updatedSettings = await response.json();
                    set({ backendSettings: updatedSettings });
                    toast.success("全局 AI 设置已更新。", { id: toastId });
                } catch (error) {
                    const msg = error instanceof Error ? error.message : "请求失败。";
                    toast.error(`更新失败: ${msg}`, { id: toastId });
                }
            },
            addAgentUrlToHistory: (url) => {
                if (!url) return;
                set(state => {
                    const history = [url, ...state.settings.agentUrlHistory.filter(u => u !== url)];
                    return {
                        settings: {
                            ...state.settings,
                            agentUrlHistory: history.slice(0, 5) // Keep last 5
                        }
                    };
                });
            },
            
            // --- Device and Blockchain Actions ---
            openDeviceTab: (deviceId) => {
                set(state => {
                    if (state.openDeviceIds.includes(deviceId)) {
                        return { activeDeviceId: deviceId };
                    }
                    return {
                        openDeviceIds: [...state.openDeviceIds, deviceId],
                        activeDeviceId: deviceId
                    };
                });
            },
            closeDeviceTab: (deviceId) => {
                set(state => {
                    const newOpenDeviceIds = state.openDeviceIds.filter(id => id !== deviceId);
                    let newActiveDeviceId = state.activeDeviceId;
                    if (state.activeDeviceId === deviceId) {
                        newActiveDeviceId = newOpenDeviceIds[newOpenDeviceIds.length - 1] || null;
                    }
                    return {
                        openDeviceIds: newOpenDeviceIds,
                        activeDeviceId: newActiveDeviceId
                    };
                });
            },
            setActiveDeviceTab: (deviceId) => set({ activeDeviceId: deviceId }),
            resetData: async () => {
                if (!window.confirm("确定要重置所有数据吗？此操作将删除所有设备和区块链，并恢复到初始状态。")) {
                    return;
                }
                const { agentApiUrl } = get().settings;
                const { currentUser } = get();
                if (!agentApiUrl || !currentUser) return;
                const toastId = toast.loading('正在重置数据...');
                try {
                    const url = createApiUrl(agentApiUrl, '/api/reset');
                    const response = await fetch(url, {
                        method: 'POST',
                        headers: { 'X-Actor-Username': currentUser.username },
                    });
                    if (!response.ok) throw new Error('重置失败。');
                    toast.success('数据已重置。', { id: toastId });
                    await get().fetchData();
                } catch (error) {
                    const msg = error instanceof Error ? error.message : "未知错误。";
                    toast.error(`重置失败: ${msg}`, { id: toastId });
                }
            },
            addNewDevice: async (deviceData) => {
                const { settings, currentUser } = get();
                if (!settings.agentApiUrl || !currentUser) return;
                const toastId = toast.loading('正在添加新设备...');
                try {
                    const url = createApiUrl(settings.agentApiUrl, '/api/devices');
                    const response = await fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Actor-Username': currentUser.username,
                        },
                        body: JSON.stringify(deviceData),
                    });
                    if (!response.ok) {
                        const errorData = await response.json().catch(() => ({ detail: '代理返回错误。' }));
                        throw new Error(errorData.detail);
                    }
                    toast.success(`设备 "${deviceData.name}" 添加成功！`, { id: toastId });
                    set({ isDeviceModalOpen: false, deviceToEdit: null });
                    await get().fetchData(true);
                } catch (error) {
                    const msg = error instanceof Error ? error.message : "未知错误。";
                    toast.error(`添加失败: ${msg}`, { id: toastId });
                }
            },
             updateDevice: async (deviceId, deviceData) => {
                const { settings, currentUser } = get();
                if (!settings.agentApiUrl || !currentUser) return;
                const toastId = toast.loading(`正在更新设备 "${deviceData.name}"...`);
                try {
                    const url = createApiUrl(settings.agentApiUrl, `/api/devices/${deviceId}`);
                    const response = await fetch(url, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Actor-Username': currentUser.username,
                        },
                        body: JSON.stringify(deviceData),
                    });
                    if (!response.ok) {
                        const errorData = await response.json().catch(() => ({ detail: '代理返回错误。' }));
                        throw new Error(errorData.detail);
                    }
                    toast.success(`设备 "${deviceData.name}" 更新成功！`, { id: toastId });
                    set({ isDeviceModalOpen: false, deviceToEdit: null });
                    await get().fetchData(true);
                } catch (error) {
                    const msg = error instanceof Error ? error.message : "未知错误。";
                    toast.error(`更新失败: ${msg}`, { id: toastId });
                }
            },
            deleteDevice: async (deviceId) => {
                if (!window.confirm("确定要删除此设备及其所有历史记录吗？此操作不可撤销。")) {
                    return;
                }
                const { settings, currentUser, closeDeviceTab } = get();
                if (!settings.agentApiUrl || !currentUser) return;

                closeDeviceTab(deviceId);

                const toastId = toast.loading('正在删除设备...');
                try {
                    const url = createApiUrl(settings.agentApiUrl, `/api/devices/${deviceId}`);
                    const response = await fetch(url, {
                        method: 'DELETE',
                        headers: { 'X-Actor-Username': currentUser.username },
                    });
                    if (!response.ok) {
                         const errorData = await response.json().catch(() => ({ detail: '代理返回错误。' }));
                        throw new Error(errorData.detail);
                    }
                    toast.success('设备已删除。', { id: toastId });
                    await get().fetchData(true);
                } catch (error) {
                    const msg = error instanceof Error ? error.message : "未知错误。";
                    toast.error(`删除失败: ${msg}`, { id: toastId });
                }
            },
            promptRollback: (targetBlock) => set({ rollbackTarget: targetBlock }),
            cancelRollback: () => set({ rollbackTarget: null }),
            executeRollback: async () => {
                const { rollbackTarget, currentUser, settings, fetchData } = get();
                if (!rollbackTarget || !settings.agentApiUrl || !currentUser) {
                    set({ rollbackTarget: null });
                    return;
                }

                const initialSteps: ProgressStep[] = [
                    { text: '发送回滚请求', status: 'loading' },
                    { text: '后端 AI 智能分析', status: 'pending' },
                    { text: '写入新区块', status: 'pending' },
                ];
                
                const toastId = toast.custom((t) =>
                    React.createElement(ProgressToast, { t, title: `正在回滚至版本 ${rollbackTarget.data.version}...`, steps: initialSteps })
                , { duration: Infinity });
                
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort('Rollback timed out'), 90000);

                try {
                    const url = createApiUrl(settings.agentApiUrl, `/api/blockchains/${rollbackTarget.data.deviceId}/rollback`);
                    const response = await fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Actor-Username': currentUser.username
                        },
                        body: JSON.stringify({
                            operator: currentUser.username,
                            target_version: rollbackTarget.data.version
                        }),
                        signal: controller.signal,
                    });

                    if (!response.ok) {
                        const errorData = await response.json().catch(() => ({'detail': '代理返回错误。'}));
                        throw new Error(errorData.detail);
                    }
                    
                    const finalSteps: ProgressStep[] = [
                        { text: '发送回滚请求', status: 'done' },
                        { text: '后端 AI 智能分析', status: 'done' },
                        { text: '写入新区块', status: 'done' },
                    ];
                    toast.custom((t) => React.createElement(ProgressToast, { t, title: "回滚成功！", steps: finalSteps }), { id: toastId, duration: 4000 });
                    
                    await fetchData(true);

                } catch (error) {
                     const isAbort = error instanceof Error && error.name === 'AbortError';
                     const msg = isAbort ? '操作超时 (超过 90 秒)。' : error instanceof Error ? error.message : '未知错误。';
                     const finalSteps: ProgressStep[] = [
                        { text: '发送回滚请求', status: 'done' },
                        { text: '后端 AI 智能分析', status: 'error' },
                        { text: '写入新区块', status: 'pending' },
                    ];
                    toast.custom((t) => React.createElement(ProgressToast, { t, title: `回滚失败: ${msg}`, steps: finalSteps }), { id: toastId, duration: 6000 });
                } finally {
                    clearTimeout(timeoutId);
                    set({ rollbackTarget: null });
                }
            },
        }),
        {
            name: 'chaintrace-storage',
            storage: createJSONStorage(() => localStorage),
            partialize: (state) => ({ settings: state.settings }),
        }
    )
);