import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import { toast } from 'react-hot-toast';
import { useStore } from '../store/useStore';
import { createApiUrl } from '../utils/apiUtils';
import { geminiService } from '../services/geminiService';
import { getAIFailureMessage } from '../utils/errorUtils';
import Loader from './Loader';
import ProgressToast from './ProgressToast';
import ConfigCheckReportModal from './ConfigCheckReportModal';
import { PlusIcon, MinusIcon, BrainIcon, SparklesIcon, ClipboardIcon } from './AIIcons';

interface AICommandAssistantProps {
  onInsert: (text: string) => void;
}

const AICommandAssistant: React.FC<AICommandAssistantProps> = ({ onInsert }) => {
    const { selectedDevice, settings } = useStore(state => ({
        selectedDevice: state.selectedDevice!,
        settings: state.settings,
    }));
    const [prompt, setPrompt] = useState('');
    const [generatedCommands, setGeneratedCommands] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            toast.error('请输入您的指令。');
            return;
        }
        setIsLoading(true);
        const toastId = toast.loading('AI 正在生成命令...');
        try {
            // First, fetch the current config for context
            const configUrl = createApiUrl(settings.agentApiUrl!, `/api/device/${selectedDevice.id}/running-config`);
            const configResponse = await fetch(configUrl, { headers: { 'X-Actor-Username': useStore.getState().currentUser!.username } });
            if (!configResponse.ok) throw new Error('获取设备当前配置失败。');
            const { config: currentConfig } = await configResponse.json();

            // Then, call the generation service
            const commands = await geminiService.generateConfigFromPrompt(prompt, selectedDevice, currentConfig);
            
            if (commands) {
                setGeneratedCommands(commands);
                toast.success('AI 命令已生成！', { id: toastId });
            } else {
                setGeneratedCommands(''); // Clear any previous commands
                toast.error('AI 未能生成有效命令，请尝试调整您的问题或指令。', { id: toastId });
            }
        } catch (error) {
            toast.error(`生成失败: ${getAIFailureMessage(error)}`, { id: toastId });
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCopy = () => {
        navigator.clipboard.writeText(generatedCommands);
        toast.success('已复制到剪贴板！');
    };

    const handleInsert = () => {
        if(generatedCommands) {
            onInsert(generatedCommands + '\n');
        }
    };

    return (
        <div className="bg-bg-900/50 p-3 border-t border-bg-800">
            <div className="flex items-center gap-2">
                <SparklesIcon className="h-5 w-5 text-primary-400 flex-shrink-0" />
                <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="用自然语言描述您的配置需求..."
                    className="flex-grow bg-bg-950 border border-bg-700 rounded-md p-2 text-sm text-text-200 focus:ring-2 focus:ring-primary-500"
                    disabled={isLoading}
                />
                <button
                    onClick={handleGenerate}
                    disabled={isLoading}
                    className="bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-3 rounded-md transition-colors disabled:opacity-50 w-28 flex justify-center"
                >
                    {isLoading ? <Loader /> : '生成命令'}
                </button>
            </div>
            {generatedCommands && (
                <div className="mt-2">
                    <textarea
                        readOnly
                        value={generatedCommands}
                        className="w-full h-24 bg-bg-950 border border-bg-700 rounded-md p-2 font-mono text-xs text-text-400"
                    />
                    <div className="flex justify-end gap-2 mt-1">
                        <button onClick={handleCopy} className="flex items-center gap-1 text-xs bg-bg-700 hover:bg-bg-600 px-2 py-1 rounded-md"><ClipboardIcon className="h-4 w-4" /> 复制</button>
                        <button onClick={handleInsert} className="text-xs bg-bg-700 hover:bg-bg-600 px-2 py-1 rounded-md">插入到终端</button>
                    </div>
                </div>
            )}
        </div>
    );
};


interface InteractiveTerminalProps {
  sessionId: string;
}

const InteractiveTerminal: React.FC<InteractiveTerminalProps> = ({ sessionId }) => {
    const { selectedDevice, currentUser, settings, fetchData } = useStore(state => ({
        selectedDevice: state.selectedDevice!,
        currentUser: state.currentUser!,
        settings: state.settings,
        fetchData: state.fetchData
    }));

    const terminalRef = useRef<HTMLDivElement>(null);
    const termRef = useRef<Terminal | null>(null);
    const fitAddonRef = useRef<FitAddon | null>(null);
    const wsRef = useRef<WebSocket | null>(null);

    const [status, setStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
    const [fontSize, setFontSize] = useState(16);
    const [isSaving, setIsSaving] = useState(false);
    const [isAiChecking, setIsAiChecking] = useState(false);
    const [configCheckReport, setConfigCheckReport] = useState('');
    const [isConfigCheckModalOpen, setIsConfigCheckModalOpen] = useState(false);
    const [showAiAssistant, setShowAiAssistant] = useState(false);

    // Terminal Initialization
    useEffect(() => {
        // This effect should only run ONCE to initialize the terminal instance.
        if (terminalRef.current && !termRef.current) {
            const term = new Terminal({
                cursorBlink: true,
                convertEol: true,
                fontFamily: 'Menlo, Monaco, "Courier New", monospace',
                fontSize: fontSize,
                theme: {
                    background: '#09090b', 
                    foreground: '#d4d4d8', 
                    cursor: 'rgb(var(--color-primary-400))',
                    selectionBackground: '#3f3f46',
                },
                allowProposedApi: true,
            });
            const fitAddon = new FitAddon();
            
            termRef.current = term;
            fitAddonRef.current = fitAddon;
            
            term.loadAddon(fitAddon);
            term.open(terminalRef.current);
            fitAddon.fit();

            term.onData(data => {
                if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                    wsRef.current.send(data);
                }
            });
        }
        
        const resizeObserver = new ResizeObserver(() => {
            fitAddonRef.current?.fit();
        });
        if (terminalRef.current) {
            resizeObserver.observe(terminalRef.current);
        }

        return () => {
            resizeObserver.disconnect();
            wsRef.current?.close();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); // <-- THE FIX: Empty dependency array.
             // We disable the lint warning because `fontSize` is intentionally used only
             // for the initial setup. The font size is then managed by a separate effect.
             // This prevents the WebSocket connection from being closed on font size change.

    // Handle Font Size Changes
    useEffect(() => {
        if (termRef.current) {
            termRef.current.options.fontSize = fontSize;
            fitAddonRef.current?.fit();
        }
    }, [fontSize]);

    const connect = useCallback(() => {
        if (wsRef.current || !settings.agentApiUrl || !selectedDevice) return;
        
        setStatus('connecting');
        termRef.current?.reset();
        termRef.current?.writeln('\x1b[1;33m正在连接到设备...\x1b[0m');

        // FIX: The browser WebSocket API constructor does not support custom headers, which was causing an error with too many arguments.
        // Authentication is now handled by passing the username as a query parameter.
        const wsPathWithAuth = `/ws/${selectedDevice.id}/${sessionId}?username=${encodeURIComponent(currentUser.username)}`;
        const wsUrl = createApiUrl(settings.agentApiUrl, wsPathWithAuth).replace(/^http/, 'ws');
        
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
            setStatus('connected');
            termRef.current?.focus();
        };

        ws.onmessage = (event) => {
            termRef.current?.write(event.data);
        };

        ws.onerror = (event) => {
            console.error("WebSocket Error:", event);
            setStatus('error');
            termRef.current?.writeln('\r\n\x1b[1;31mWebSocket 连接错误。请检查代理服务和网络连接。\x1b[0m');
        };

        ws.onclose = (event) => {
            setStatus('disconnected');
            if (!event.wasClean) {
                termRef.current?.writeln(`\r\n\x1b[1;31m连接意外断开 (代码: ${event.code})。请重试。\x1b[0m`);
            } else {
                termRef.current?.writeln('\r\n\x1b[1;34m连接已关闭。\x1b[0m');
            }
            wsRef.current = null;
        };
    }, [selectedDevice, sessionId, settings.agentApiUrl, currentUser.username]);

    const disconnect = useCallback(() => {
        wsRef.current?.close();
    }, []);

    const handleSaveSession = async () => {
        setIsSaving(true);
        const toastId = 'save-session-toast';

        try {
            toast.custom((t) => (
                <ProgressToast t={t} title="正在保存会话..." steps={[
                    { text: "正在从设备获取最新配置", status: 'loading' },
                    { text: "AI 智能审计分析", status: 'pending' },
                    { text: "写入区块链", status: 'pending' }
                ]} />
            ), { id: toastId, duration: Infinity });
            
            const url = createApiUrl(settings.agentApiUrl!, `/api/sessions/${selectedDevice.id}/save`);
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-Actor-Username': currentUser.username },
                body: JSON.stringify({ operator: currentUser.username }),
            });
            
            if (!response.ok) {
                 const errorData = await response.json().catch(() => ({'detail': '代理返回了未知错误。'}));
                 throw new Error(errorData.detail);
            }
            
            await fetchData(true);
            
             toast.custom((t) => (
                <ProgressToast t={t} title="保存成功！" steps={[
                    { text: "从设备获取最新配置", status: 'done' },
                    { text: "AI 智能审计分析", status: 'done' },
                    { text: "写入区块链", status: 'done' }
                ]} />
            ), { id: toastId, duration: 4000 });
        } catch (error) {
            const msg = error instanceof Error ? error.message : '未知错误。';
            toast.error(`保存失败: ${msg}`, { id: toastId, duration: 6000 });
        } finally {
            setIsSaving(false);
        }
    };
    
    const handleConfigCheck = async () => {
        setIsAiChecking(true);
        const toastId = toast.loading('正在从设备获取配置以进行分析...');
        try {
            const url = createApiUrl(settings.agentApiUrl!, `/api/device/${selectedDevice.id}/running-config`);
            const response = await fetch(url, {
                headers: { 'X-Actor-Username': currentUser.username }
            });

            if (!response.ok) {
                const error = await response.json().catch(() => ({detail: '未知错误'}));
                throw new Error(error.detail);
            }
            const data = await response.json();
            
            toast.loading('AI 正在分析配置...', { id: toastId });
            
            const report = await geminiService.checkConfiguration(data.config, selectedDevice.type);
            setConfigCheckReport(report);
            setIsConfigCheckModalOpen(true);
            toast.success('AI 配置体检完成！', { id: toastId });
        } catch(error) {
            toast.error(`操作失败: ${getAIFailureMessage(error)}`, { id: toastId });
        } finally {
            setIsAiChecking(false);
        }
    };

    const isConnected = status === 'connected';

    return (
        <div className="bg-bg-950 rounded-lg shadow-lg flex flex-col min-h-[65vh] border border-bg-800">
            <div className="flex-shrink-0 flex items-center justify-between p-2 border-b border-bg-800 bg-bg-900/70 rounded-t-lg flex-wrap gap-2">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <span className={`h-2.5 w-2.5 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
                        <span className="text-xs font-semibold text-text-300">{isConnected ? '已连接' : '已断开'}</span>
                    </div>
                    {!isConnected ? (
                        <button onClick={connect} disabled={status === 'connecting'} className="text-sm bg-primary-600 hover:bg-primary-700 text-white font-bold py-1 px-3 rounded-md transition-colors disabled:opacity-50">
                            {status === 'connecting' ? '连接中...' : '连接 SSH'}
                        </button>
                    ) : (
                        <button onClick={disconnect} className="text-sm bg-bg-700 hover:bg-bg-600 text-text-200 font-bold py-1 px-3 rounded-md transition-colors">
                            断开连接
                        </button>
                    )}
                </div>
                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1">
                        <span className="text-xs text-text-400">字体:</span>
                        <button onClick={() => setFontSize(s => Math.max(10, s - 1))} className="p-1 rounded-md hover:bg-bg-700 disabled:opacity-50" aria-label="减小字体"><MinusIcon className="h-4 w-4" /></button>
                        <button onClick={() => setFontSize(s => Math.min(24, s + 1))} className="p-1 rounded-md hover:bg-bg-700 disabled:opacity-50" aria-label="增大字体"><PlusIcon className="h-4 w-4" /></button>
                    </div>
                     <button onClick={() => setShowAiAssistant(prev => !prev)} className={`text-sm ${showAiAssistant ? 'bg-primary-700' : 'bg-bg-700'} hover:bg-primary-700/80 text-white font-bold py-1 px-3 rounded-md transition-colors flex items-center gap-2`}>
                        <SparklesIcon className="h-4 w-4" /> AI 助手
                    </button>
                    <button onClick={handleConfigCheck} disabled={isAiChecking || !isConnected} className="text-sm bg-bg-700 hover:bg-bg-600 text-text-200 font-bold py-1 px-3 rounded-md transition-colors disabled:opacity-50 flex items-center gap-2">
                        {isAiChecking ? <Loader /> : <><BrainIcon className="h-4 w-4" /> AI 配置体检</>}
                    </button>
                    <button 
                        onClick={handleSaveSession}
                        disabled={isSaving || !isConnected}
                        className="text-sm bg-primary-600 hover:bg-primary-700 text-white font-bold py-1 px-3 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed w-36 flex justify-center"
                    >
                        {isSaving ? <Loader /> : '保存会话并审计'}
                    </button>
                </div>
            </div>
            <div ref={terminalRef} className="flex-grow w-full h-full p-2 overflow-hidden" />
            {showAiAssistant && (
                <AICommandAssistant onInsert={(text) => termRef.current?.write(text)} />
            )}
            {isConfigCheckModalOpen && (
              <ConfigCheckReportModal 
                isOpen={isConfigCheckModalOpen}
                report={configCheckReport}
                onClose={() => setIsConfigCheckModalOpen(false)}
              />
          )}
        </div>
    );
};

export default InteractiveTerminal;