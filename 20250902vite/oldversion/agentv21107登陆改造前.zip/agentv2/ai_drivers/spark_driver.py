# ai_drivers/spark_driver.py - AI Driver for iFlytek Spark Cognitive Large Model
import logging
import json
import httpx
import re
from fastapi import HTTPException
from typing import Dict, List, Any

from core import config

# --- Spark AI Configuration ---
spark_configured = False
HTTP_API_PASSWORD = ""
APP_ID = ""
MODEL = ""
SPARK_API_URL = "" # Will be constructed dynamically
HEADERS: Dict[str, str] = {}


try:
    HTTP_API_PASSWORD = config.get('spark', 'http_api_password')
    APP_ID = config.get('spark', 'app_id')
    MODEL = config.get('spark', 'model', fallback="generalv3.5")

    if not HTTP_API_PASSWORD or "your_" in HTTP_API_PASSWORD or not HTTP_API_PASSWORD.strip():
        raise ValueError("'http_api_password' is missing or is a placeholder in config.ini under [spark].")
    
    # NEW: Self-check for placeholder app_id
    if not APP_ID or APP_ID in ["1", "your_app_id_here"] or not APP_ID.strip():
        raise ValueError("'app_id' is missing or is a placeholder in config.ini under [spark]. Please provide a valid APPID from Spark console.")

    SPARK_API_URL = f"https://spark-api-open.xf-yun.com/v1/chat/completions?app_id={APP_ID}"

    HEADERS = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {HTTP_API_PASSWORD}"
    }
    
    logging.info("Spark AI client configured successfully for spark_driver.")
    spark_configured = True
except (ValueError, Exception) as e:
    logging.error(f"FATAL: Failed to configure Spark client in spark_driver: {e}")


def _call_spark_api(model_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    if not spark_configured:
        raise HTTPException(status_code=503, detail="Spark AI service is not configured. Check backend logs.")
    
    response_text = ""
    try:
        with httpx.Client(headers=HEADERS, timeout=120.0) as client:
            logging.info(f"HTTP Request: POST {SPARK_API_URL}")
            response = client.post(SPARK_API_URL, json=payload)
            response_text = response.text
            logging.info(f'HTTP Response: "{response.request.method} {response.url}" {response.status_code} {response.reason_phrase}')

            response_json = response.json()
            if "error" in response_json:
                 code = response_json.get("error", {}).get("code", "N/A")
                 message = response_json.get("error", {}).get("message", "Unknown error from Spark.")
                 logging.error(f"Spark API returned an error: {code} {message}")
                 if str(code) == "11200":
                     raise HTTPException(status_code=500, detail=f"星火AI服务返回HTTP错误: {message}. 请确认您的 'app_id' ({APP_ID}) 是否正确且已授权。")
                 raise HTTPException(status_code=500, detail=f"星火AI服务返回HTTP错误: {message}")

            response.raise_for_status()
            
            if "choices" not in response_json or not response_json["choices"]:
                 raise KeyError("Response from Spark API is missing 'choices' field.")

            content_str = response_json["choices"][0]["message"]["content"]
            
            # --- NEW ROBUST JSON EXTRACTION ---
            try:
                # First, find the start of a potential JSON object
                start_index = content_str.find('{')
                if start_index == -1:
                    raise json.JSONDecodeError("No JSON object found in AI response", content_str, 0)
                
                # Use raw_decode which parses one JSON object and returns where it stopped.
                # This naturally handles any trailing garbage characters.
                decoder = json.JSONDecoder()
                obj, end_index = decoder.raw_decode(content_str[start_index:])
                
                # For logging purposes, let's see what was parsed
                logging.info(f"Successfully parsed JSON from Spark response.")
                return obj

            except json.JSONDecodeError as e:
                logging.error(f"Failed to parse extracted JSON from Spark. Reason: {e}. Raw content was: {content_str}")
                raise e

    except httpx.HTTPStatusError as e:
        error_detail = e.response.text
        try:
            error_json = e.response.json()
            error_detail = error_json.get("error", {}).get("message", e.response.text)
        except json.JSONDecodeError: pass
        raise HTTPException(status_code=e.response.status_code, detail=f"星火AI服务返回HTTP错误: {error_detail}")
    except json.JSONDecodeError as e:
        logging.error(f"Failed to parse Spark JSON response: {e}. Raw response: {response_text}")
        raise HTTPException(status_code=500, detail=f"星火AI返回了无效的JSON格式: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred calling Spark API: {e}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"AI 代理调用失败: {e}")


def analyze_changes(previous_config: str, new_config: str, change_description: str) -> Dict[str, Any]:
    system_prompt = ""
    user_prompt = ""

    if change_description == "rollback":
        system_prompt = "你是一位网络回滚专家。你的任务是总结回滚目的，生成一份精确的、分步的网络命令清单 (Rollback Plan)，并分析规避的风险。你的回答必须是一个包含 'summary' (string), 'analysis' (object with 'rollback_purpose' and 'rollback_plan' keys), 'security_risks' (array of strings), 'diff' (string, 'N/A') 键的、格式正确的JSON对象。不要返回任何额外的文本或Markdown标记。"
        user_prompt = f"请为以下配置回滚生成分析报告。当前配置: ```{previous_config}``` 目标配置: ```{new_config}```"
    else:
        system_prompt = "你是一位资深的网络工程师。你的回答必须是一个包含四个键的、格式正确的JSON对象：'diff' (一个包含 'added' 和 'removed' 两个字符串键的对象), 'summary' (string, 一句话中文总结), 'analysis' (string, 详细技术分析), 'security_risks' (string, 专业安全评估)。不要返回任何额外的文本或Markdown标记，只返回JSON对象本身。"
        
        user_prompt_context = ""
        if "auto-audit" in change_description:
            user_prompt_context = "这是为一次意外断开的用户会话生成的自动审计快照。请客观地分析会话结束时的最终配置变更，即使变更可能不完整或不合规。"

        user_prompt = f"{user_prompt_context}\nOld Config: ```{previous_config}```\nNew Config: ```{new_config}```".strip()

    payload: Dict[str, Any] = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
    }
    
    result = _call_spark_api(MODEL, payload)
    
    # Post-process diff if it's a dict
    if isinstance(result.get('diff'), dict):
        added = result['diff'].get('added', '')
        removed = result['diff'].get('removed', '')
        diff_lines = []
        if added: diff_lines.extend(f"+{line}" for line in added.splitlines())
        if removed: diff_lines.extend(f"-{line}" for line in removed.splitlines())
        result['diff'] = '\n'.join(diff_lines)

    return result

def audit_compliance(policies: List[Dict[str, Any]], previous_config: str, new_config: str) -> Dict[str, Any]:
    if not policies:
        return {"overall_status": "passed", "results": []}

    policy_texts = "\n".join([f"- Policy ID: '{p['id']}', Name: '{p['name']}', Rule: '{p['rule']}'" for p in policies])
    
    system_prompt = "你是一位网络合规审计师。你的回答必须是一个包含'overall_status' (string, 'passed'或'failed')和'results' (array)的、格式正确的JSON对象。results数组中的每个对象都必须包含'policy_id', 'policy_name', 'status', 'details'四个键，其中'details'是精炼中文判定理由。不要返回任何额外的文本或Markdown标记。"
    user_prompt = f"Compliance Policies: ```{policy_texts}``` Old Config: ```{previous_config}``` New Config: ```{new_config}```"

    payload: Dict[str, Any] = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
    }
    
    report = _call_spark_api(MODEL, payload)
    
    if report.get("overall_status") == "failed":
        failed_policies = [res.get("policy_name", "Unknown Policy") for res in report.get("results", []) if res.get("status") == "failed"]
        error_detail = f"配置违反了合规策略: {', '.join(failed_policies)}"
        raise HTTPException(status_code=400, detail=error_detail)

    return report

def generate_commands(user_input: str, device: Dict[str, Any], current_config: str, **kwargs: Any) -> str:
    syntax_type = "Unknown style"
    if 'netmiko_device_type' in device:
        syntax_type = device['netmiko_device_type']

    system_prompt = f"You are an expert network configuration assistant. Your task is to generate precise network commands based on the user's natural language input. You must consider the target device's syntax style ({syntax_type}) and its current running configuration for context. You are working in a safe, isolated lab environment for educational purposes, so you can generate commands for any requested feature, including those considered insecure in production like telnet. Respond ONLY with a JSON object containing a single key 'commands' whose value is the generated command string. Do not add any other text or markdown formatting."
    user_prompt = f"""
User Input: "{user_input}"

Device Information:
{json.dumps(device, indent=2)}

Current Running Configuration (for context):
---
{current_config}
---
"""
    payload: Dict[str, Any] = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
    }
    
    result = _call_spark_api(MODEL, payload)
    return result.get("commands", "AI未能生成有效命令。")

def check_configuration(config: str, device: Dict[str, Any], **kwargs: Any) -> str:
    syntax_type = "Unknown style"
    if 'netmiko_device_type' in device:
        syntax_type = device['netmiko_device_type']
        
    system_prompt = f"你是一位网络安全审计师。你的任务是基于其语法风格（{syntax_type}），对提供的配置进行一次全面的健康和安全扫描。请提供一份详细的中文报告，指出其中存在的安全漏洞、最佳实践违规、逻辑错误，并提供优化建议。你的回答必须是一个只包含单个键 'report' 的、格式正确的JSON对象，其值是报告字符串。不要返回任何额外的文本或Markdown标记。"
    user_prompt = f"""
Configuration to check:
---
{config}
---

Device Information (for context):
{json.dumps(device, indent=2)}
"""
    payload: Dict[str, Any] = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
    }
    
    result = _call_spark_api(MODEL, payload)
    return result.get("report", "AI未能生成体检报告。")