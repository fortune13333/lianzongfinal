# ai_drivers/spark_driver.py - AI Driver for iFlytek Spark Cognitive Large Model
import logging
import json
import httpx
from urllib.parse import urlparse, urlunparse, urlencode # Import for URL manipulation
from fastapi import HTTPException
from typing import Dict, List, Any

from core import config

# --- Spark AI Configuration ---
spark_configured = False
DYNAMIC_URL = ""
try:
    APP_ID = config.get('spark', 'app_id')
    API_PASSWORD = config.get('spark', 'http_api_password')
    ANALYSIS_MODEL = config.get('spark', 'analysis_model', fallback="generalv3.5")
    AUDIT_MODEL = config.get('spark', 'audit_model', fallback="generalv3")

    if not APP_ID or "your_app_id_here" in APP_ID or APP_ID == "1":
        raise ValueError("A valid 'app_id' is required in config.ini under [spark].")
    if not API_PASSWORD or "your_http_api_password_here" in API_PASSWORD:
        raise ValueError("A valid 'http_api_password' is required in config.ini under [spark].")

    # --- CRITICAL FIX: Dynamically construct the request URL with app_id ---
    BASE_URL_STATIC = "https://spark-api-open.xf-yun.com/v1/chat/completions"
    url_parts = list(urlparse(BASE_URL_STATIC))
    query = {'app_id': APP_ID}
    url_parts[4] = urlencode(query)
    DYNAMIC_URL = urlunparse(url_parts)

    HEADERS = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_PASSWORD}"
    }
    
    logging.info(f"Spark AI client configured. Requests will be sent to: {DYNAMIC_URL}")
    spark_configured = True
except (ValueError, Exception) as e:
    logging.error(f"FATAL: Failed to configure Spark client in spark_driver: {e}")
    logging.error("Please check your config.ini file for the [spark] section.")


def _call_spark_api(payload: Dict[str, Any]) -> Dict[str, Any]:
    if not spark_configured:
        raise HTTPException(status_code=503, detail="Spark AI service is not configured. Check backend logs.")
    
    # Ensure the user field is not part of the payload, as it's incorrect for Spark's OpenAI API
    payload.pop("user", None)
    
    response_text = ""
    try:
        with httpx.Client(headers=HEADERS, timeout=120.0) as client:
            # Always use the dynamically constructed URL
            response = client.post(DYNAMIC_URL, json=payload)
            response_text = response.text
            response.raise_for_status()
            
            response_json = response.json()
            
            # Check for Spark-specific error codes in the response header
            if "header" in response_json and response_json["header"].get("code", 0) != 0:
                 error_code = response_json["header"].get("code", "N/A")
                 error_message = response_json["header"].get("message", "Unknown error from Spark API.")
                 raise httpx.HTTPStatusError(f"Error code {error_code}: {error_message}", request=response.request, response=response)

            if "choices" not in response_json or not response_json["choices"]:
                 raise KeyError("Response from Spark API is missing 'choices' field.")

            content_str = response_json["choices"][0]["message"]["content"]
            
            # Clean up potential markdown code block wrapping
            if content_str.strip().startswith("```json"):
                content_str = content_str.strip()[7:-3]
            
            return json.loads(content_str)

    except httpx.HTTPStatusError as e:
        logging.error(f"Spark API returned an error: {e.response.status_code} {e.response.text}")
        error_detail = e.response.text
        try:
            error_json = e.response.json()
            error_msg_from_payload = ""
            if "error" in error_json and "message" in error_json["error"]:
                error_msg_from_payload = error_json["error"]["message"]
            
            # Provide a more helpful error message for the specific auth error
            if "AppIdNoAuthError" in error_msg_from_payload:
                 error_detail = f"{error_msg_from_payload}. 请再次确认您的 'app_id' ({APP_ID}) 和 'http_api_password' 是否正确且已授权。"
            else:
                error_detail = error_msg_from_payload
        except json.JSONDecodeError:
            pass # Keep the original error text if it's not JSON
        raise HTTPException(status_code=e.response.status_code, detail=f"星火AI服务返回HTTP错误: {error_detail}")
    except (json.JSONDecodeError, KeyError, IndexError) as e:
        logging.error(f"Failed to parse Spark JSON response: {e}. Raw response: {response_text}")
        raise HTTPException(status_code=500, detail=f"星火AI返回了无效的JSON格式: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred calling Spark API: {e}")
        raise HTTPException(status_code=500, detail=f"调用星火AI服务时发生未知错误: {e}")


def analyze_changes(previous_config: str, new_config: str, change_description: str) -> Dict[str, Any]:
    if change_description == "rollback":
        system_prompt = "你是一位网络回滚专家。你的任务是总结回滚目的，生成一份精确的、分步的网络命令清单 (Rollback Plan)，并分析规避的风险。你的回答必须是一个包含 'summary' (string), 'analysis' (object with 'rollback_purpose' and 'rollback_plan' keys), 'security_risks' (array of strings), 'diff' (string, 'N/A') 键的、格式正确的JSON对象。不要返回任何额外的文本或Markdown标记。"
        user_prompt = f"请为以下配置回滚生成分析报告。当前配置: ```{previous_config}``` 目标配置: ```{new_config}```"
    else:
        # Default system prompt for both 'update' and 'auto-audit'
        system_prompt = "你是一位资深的网络工程师。请分析新旧配置之间的变更。你的回答必须是一个包含四个键的、格式正确的JSON对象：'diff' (string, 逐行差异, '+'表示新增, '-'表示删除), 'summary' (string, 一句话中文总结), 'analysis' (string, 详细技术分析), 'security_risks' (string, 专业安全评估)。不要返回任何额外的文本或Markdown标记，只返回JSON对象本身。"
        
        # Add specific context to the user prompt based on change_description
        user_prompt_context = ""
        if "auto-audit" in change_description:
            user_prompt_context = "这是为一次意外断开的用户会话生成的自动审计快照。请客观地分析会话结束时的最终配置变更，即使变更可能不完整或不合规。"

        user_prompt = f"{user_prompt_context}\nOld Config: ```{previous_config}```\nNew Config: ```{new_config}```".strip()

    payload = {
        "model": ANALYSIS_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "response_format": {"type": "json_object"}
    }
    
    return _call_spark_api(payload)

def audit_compliance(policies: List[Dict[str, Any]], previous_config: str, new_config: str) -> Dict[str, Any]:
    if not policies:
        return {"overall_status": "passed", "results": []}

    policy_texts = "\n".join([f"- Policy ID: '{p['id']}', Name: '{p['name']}', Rule: '{p['rule']}'" for p in policies])
    
    system_prompt = "你是一位网络合规审计师。你的任务是判断'New Config'相对于'Old Config'的变更，是否违反了给定的任何一条'Compliance Policies'。你的回答必须是一个包含'overall_status' (string, 'passed'或'failed')和'results' (array)的、格式正确的JSON对象。results数组中的每个对象都必须包含'policy_id', 'policy_name', 'status', 'details'四个键。不要返回任何额外的文本或Markdown标记，只返回JSON对象本身。"
    user_prompt = f"Compliance Policies: ```{policy_texts}``` Old Config: ```{previous_config}``` New Config: ```{new_config}```"

    payload = {
        "model": AUDIT_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "response_format": {"type": "json_object"}
    }
    
    report = _call_spark_api(payload)
    
    if report.get("overall_status") == "failed":
        failed_policies = [res.get("policy_name", "Unknown Policy") for res in report.get("results", []) if res.get("status") == "failed"]
        error_detail = f"配置违反了合规策略: {', '.join(failed_policies)}"
        raise HTTPException(status_code=400, detail=error_detail)

    return report