# services.py - Business logic layer for the ChainTrace Agent.
# This file sits between the API routes and the database CRUD operations.

import logging
import json
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional, cast

from sqlalchemy.orm import Session
from netmiko import ConnectHandler, NetmikoBaseException # type: ignore
from netmiko.exceptions import NetmikoAuthenticationException # type: ignore
from fastapi import HTTPException

import crud
from core import calculate_block_hash, config, genai, SubmissionPayload, RollbackPayload, BlockDict, BlockDataDict, ComplianceReportDict

# --- Simulation Mode Check ---
def is_simulation_mode() -> bool:
    if not config: return False
    for section in config.sections():
        if section.lower().startswith('credentials') and config.get(section, 'username', fallback='').upper() == 'SIM_USER':
            logging.info("Simulation mode is ACTIVE because SIM_USER was found.")
            return True
    return False

# --- Authorization Service ---
def verify_admin(db: Session, actor_username: str) -> None:
    """Verifies if the acting user has admin privileges based on the database."""
    actor = crud.get_user_by_username(db, actor_username)
    if not actor or actor.role != "admin":
        logging.warning(f"Authorization failed for user '{actor_username}'. Admin role required.")
        raise HTTPException(status_code=403, detail="Permission denied: Administrator role required.")

# --- AI Service Helpers ---
def _handle_ai_exception(e: Exception) -> None:
    logging.error(f"Gemini AI operation failed: {e}")
    if "User location is not supported" in str(e):
        raise HTTPException(status_code=403, detail="AI analysis failed: The AI service is not available in your region.")
    raise HTTPException(status_code=504, detail=f"AI analysis timed out or failed. Error: {e}")

def _run_compliance_audit(policies: List[Dict[str, Any]], previous_config: str, new_config: str) -> Optional[ComplianceReportDict]:
    if not genai: return {"overall_status": "passed", "results": [], "details": "AI service disabled"}
    enabled_policies = [p for p in policies if p.get('enabled')]
    if not enabled_policies: return {"overall_status": "passed", "results": []}

    try:
        model = genai.GenerativeModel('gemini-2.5-flash')
        policy_texts = "\n".join([f"- {p['name']}: {p['rule']}" for p in enabled_policies])
        prompt = (f"You are a network compliance auditor. Analyze the new config against the old one "
                  f"based on the following policies. For each policy, determine if it passed or failed and provide a very short, one-sentence reason in the 'details' field. "
                  f"Focus on whether the rule in the policy is violated. "
                  f"Output a JSON object with keys: 'overall_status' ('passed' or 'failed') and 'results' "
                  f"(an array of objects, each with 'policy_id', 'policy_name', 'status', 'details').\n\n"
                  f"Policies:\n{policy_texts}\n\nOld Config:\n```\n{previous_config}\n```\nNew Config:\n```\n{new_config}\n```")
        
        response = model.generate_content(prompt)
        # Clean potential markdown fences from the response
        cleaned_response_text = response.text.strip().replace('```json', '').replace('```', '')
        report: ComplianceReportDict = json.loads(cleaned_response_text)
        
        if report.get('overall_status') == 'failed':
            failed_policies = [res['policy_name'] for res in report.get('results', []) if res.get('status') == 'failed']
            raise HTTPException(status_code=400, detail=f"Configuration violates compliance policies: {', '.join(failed_policies)}")
        
        return report
    except HTTPException as e: raise e
    except Exception as e: _handle_ai_exception(e); return None 

def _run_ai_analysis(previous_config: str, new_config: str, change_description: str = "") -> Dict[str, Any]:
    if not genai: raise HTTPException(status_code=503, detail="Gemini AI service is not configured or available.")
    try:
        model = genai.GenerativeModel('gemini-2.5-flash')
        prompt_parts = [
            "You are a network rollback expert..." if "rollback" in change_description.lower() else "You are a network configuration analyst.",
            f"Previous config:\n```\n{previous_config}\n```", f"New config:\n```\n{new_config}\n```",
            "Analyze the changes. Provide a git-style diff, a summary, detailed analysis, and security risks in Simplified Chinese.",
            "Format the output as a JSON object with keys: 'diff', 'summary', 'analysis', 'security_risks'."
        ]
        if "rollback" in change_description.lower():
            prompt_parts[3] = "For the 'analysis' key, the value must be a JSON object containing 'rollback_purpose' (string), 'rollback_plan' (array of strings for commands), and 'security_risks' (array of strings describing risks averted)."
        
        prompt = "\n".join(prompt_parts)
        response = model.generate_content(prompt)
        cleaned_response_text = response.text.strip().replace('```json', '').replace('```', '')
        return json.loads(cleaned_response_text)
    except Exception as e: _handle_ai_exception(e); return {}

# --- Blockchain Services ---
def perform_add_block(db: Session, device_id: str, payload: SubmissionPayload, skip_compliance_check: bool = False) -> BlockDict:
    device = crud.get_device_with_details(db, device_id)
    if not device:
        raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}' 的区块链。")
    
    last_block = sorted(device.blocks, key=lambda b: b.index)[-1] if device.blocks else None
    previous_config = json.loads(last_block.data).get('config', '') if last_block else ''
    
    policies_for_audit = device.policies
    settings = crud.get_settings_as_dict(db)
    compliance_report: Optional[ComplianceReportDict] = None

    if settings.get("is_ai_analysis_enabled", True):
        try:
            if payload.changeType != 'rollback' and not skip_compliance_check:
                compliance_report = _run_compliance_audit([p.__dict__ for p in policies_for_audit], previous_config, payload.config)
            
            analysis_context = "rollback" if payload.changeType == 'rollback' else ""
            analysis_results = _run_ai_analysis(previous_config, payload.config, analysis_context)
        except HTTPException as e:
            raise e
        except Exception as e:
            logging.error(f"AI analysis failed but proceeding. Error: {e}")
            analysis_results = {"diff": "Diff generation failed.", "summary": "AI analysis failed.", "analysis": str(e), "security_risks": "N/A"}
    else:
        analysis_results = {"diff": "N/A", "summary": "AI analysis disabled.", "analysis": "N/A", "security_risks": "N/A"}

    new_index = last_block.index + 1 if last_block else 0
    timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    prev_hash = last_block.hash if last_block else "0"
    
    new_block_data: BlockDataDict = {
        "deviceId": device_id, "version": new_index + 1, "operator": payload.operator,
        "config": payload.config, 
        "diff": analysis_results.get("diff", "差异信息不可用。"), 
        "changeType": payload.changeType,
        "summary": analysis_results.get("summary", "摘要信息不可用。"), 
        "analysis": analysis_results.get("analysis"),
        "security_risks": analysis_results.get("security_risks"), 
        "compliance_report": compliance_report,
    }
    
    new_hash = calculate_block_hash(new_block_data, new_index, timestamp, prev_hash)
    new_block = {"index": new_index, "timestamp": timestamp, "data": new_block_data, "prev_hash": prev_hash, "hash": new_hash}

    return crud.add_block(db, device_id, new_block)

def perform_rollback(db: Session, device_id: str, payload: RollbackPayload) -> BlockDict:
    device = crud.get_device_with_details(db, device_id)
    if not device: raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}' 的区块链。")
    
    target_block = next((b for b in device.blocks if json.loads(b.data)['version'] == payload.target_version), None)
    if not target_block: raise HTTPException(status_code=404, detail=f"未找到目标回滚版本 '{payload.target_version}'。")

    target_config = json.loads(target_block.data).get('config', '')
    submission_payload = SubmissionPayload(operator=payload.operator, config=target_config, changeType='rollback')
    
    try:
        return perform_add_block(db, device_id, submission_payload)
    except HTTPException as e:
        raise HTTPException(status_code=e.status_code, detail=f"记录回滚失败: {e.detail}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"执行回滚时发生意外错误: {e}")

def perform_pre_deployment_check(db: Session, device_id: str, new_config: str) -> None:
    """
    Performs a pre-deployment compliance check against the latest config in the database.
    This function is designed to be called BEFORE a configuration is pushed to a device.
    It will raise an HTTPException if the compliance check fails.
    """
    device = crud.get_device_with_details(db, device_id)
    if not device:
        raise HTTPException(status_code=404, detail=f"Device {device_id} not found for pre-check.")
    
    last_block = sorted(device.blocks, key=lambda b: b.index)[-1] if device.blocks else None
    previous_config = json.loads(last_block.data).get('config', '') if last_block else ''
    
    policies_for_audit = device.policies
    settings = crud.get_settings_as_dict(db)

    if settings.get("is_ai_analysis_enabled", True):
        # This call will raise an HTTPException on failure, which is the intended behavior.
        _run_compliance_audit([p.__dict__ for p in policies_for_audit], previous_config, new_config)

# --- Real-time Config Service ---
def get_device_info(device_id: str) -> Optional[Dict[str, Any]]:
    device_id_upper = device_id.upper()
    if not config.has_section('device_map') or not config.has_option('device_map', device_id_upper): return None
    try:
        ip, dev_type, creds_section = [s.strip() for s in config.get('device_map', device_id_upper).split(',', 2)]
        if not config.has_section(creds_section): return None
        return {"host": ip, "device_type": dev_type, "username": config.get(creds_section, 'username'), "password": config.get(creds_section, 'password'), "secret": config.get(creds_section, 'secret', fallback=None), "timeout": 20}
    except Exception as e:
        logging.error(f"Error parsing config for device {device_id}: {e}")
        return None

def get_running_config(device_id: str) -> Dict[str, str]:
    if is_simulation_mode(): raise HTTPException(status_code=400, detail="模拟模式下无法获取实时配置。")
    device_info = get_device_info(device_id)
    if not device_info: raise HTTPException(status_code=404, detail=f"在配置文件中未找到设备 ID '{device_id}'。")
    try:
        with ConnectHandler(**device_info) as net_connect:
            net_connect.enable()
            net_connect.disable_paging()
            cmd = 'display current-configuration' if any(v in device_info.get('device_type', '').lower() for v in ['huawei', 'h3c']) else 'show running-config'
            latest_config = cast(str, net_connect.send_command(cmd, read_timeout=120))
            if not latest_config or "Invalid input detected" in latest_config: raise HTTPException(status_code=500, detail="设备返回无效或空的配置。")
            return {"config": latest_config}
    except NetmikoAuthenticationException as e: raise HTTPException(status_code=401, detail=f"设备认证失败: {e}")
    except NetmikoBaseException as e: raise HTTPException(status_code=504, detail=f"连接设备失败: {e}")
    except Exception as e: raise HTTPException(status_code=500, detail=f"获取配置时发生未知错误: {e}")