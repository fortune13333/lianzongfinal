# websocket_handler.py - WebSocket handling for ChainTrace Agent's interactive console

import logging
import asyncio
import threading
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from fastapi.websockets import WebSocketState
from netmiko import ConnectHandler # type: ignore
from netmiko.exceptions import NetmikoAuthenticationException, NetmikoBaseException # type: ignore
from netmiko.cisco_base_connection import CiscoBaseConnection # type: ignore
from typing import Optional, TypedDict

from sqlalchemy.orm import Session

# Import from our own refactored modules
from core import ACTIVE_WEB_SESSIONS, sessions_lock, SessionState
from services import get_device_info, perform_auto_audit, check_command_against_rules
from database import get_db

# --- New In-memory "Dirty" Session Tracking ---
# This store will track which sessions have had potential config changes.
READ_ONLY_COMMANDS = ('show', 'display', 'dir', 'ping', 'traceroute')


# Type definition for device information
class DeviceInfo(TypedDict, total=False):
    host: str
    device_type: str
    username: str
    password: str
    secret: Optional[str]
    timeout: int

router = APIRouter()


async def unified_io_handler(websocket: WebSocket, net_connect: CiscoBaseConnection, actor_username: str, session_id: str, device_id: str, db: Session) -> None:
    """
    A unified I/O handler that now performs real-time interception checks and handles multi-line pasted input correctly.
    This version fixes the critical race condition bug in command interception.
    """
    line_buffer: str = ""
    loop = asyncio.get_running_loop()

    ws_reader: asyncio.Task[str] = asyncio.create_task(websocket.receive_text())
    device_reader: "asyncio.Future[str]" = loop.run_in_executor(None, net_connect.read_channel)
    
    async def send_to_device(data: str):
        """Helper to centralize writing to the device."""
        await loop.run_in_executor(None, net_connect.write_channel, data)

    try:
        while True:
            done, _ = await asyncio.wait([ws_reader, device_reader], return_when=asyncio.FIRST_COMPLETED)

            if device_reader in done:
                device_output: str = device_reader.result()
                if device_output: await websocket.send_text(device_output)
                device_reader = loop.run_in_executor(None, net_connect.read_channel)

            if ws_reader in done:
                user_input: str = ws_reader.result()
                
                # --- START: CRITICAL FIX for command interception race condition ---
                is_enter_key = '\r' in user_input or '\n' in user_input

                # Case 1: Enter key pressed, triggering command check
                if is_enter_key:
                    command_to_check = line_buffer.strip() # Check the buffer before it's cleared
                    
                    violated_rule_name = check_command_against_rules(command_to_check)

                    if violated_rule_name:
                        # Intercept: Clear the line on the device and send a warning to the user
                        logging.warning(f"User '{actor_username}' attempted forbidden command: '{command_to_check}' which violates rule: '{violated_rule_name}'")
                        await send_to_device('\x15') # CTRL+U to clear the line
                        error_msg = f"\r\n\x1b[31m[ChainTrace Interception] Command blocked by rule: '{violated_rule_name}'.\x1b[0m\r\n"
                        await websocket.send_text(error_msg)
                        await send_to_device('\n') # Send a newline to get a fresh prompt
                    else:
                        # Allowed: Mark session as dirty if needed and send the newline to execute
                        if command_to_check and not command_to_check.lower().startswith(READ_ONLY_COMMANDS):
                            with sessions_lock:
                                if session_id in ACTIVE_WEB_SESSIONS and not ACTIVE_WEB_SESSIONS[session_id]['is_dirty']:
                                    ACTIVE_WEB_SESSIONS[session_id]['is_dirty'] = True
                                    logging.info(f"Session {session_id} for device {device_id} marked as DIRTY.")
                        
                        await send_to_device(user_input) # Send the original enter key(s)
                    
                    line_buffer = "" # Always clear buffer after enter
                
                # Case 2: Backspace
                elif user_input == '\x7f':
                    line_buffer = line_buffer[:-1] if line_buffer else ""
                    await send_to_device(user_input) # Forward backspace to device
                
                # Case 3: Other key presses (regular characters, tabs, etc.)
                else:
                    line_buffer += user_input
                    await send_to_device(user_input) # Forward other keys to device for echo/tab-complete
                # --- END: CRITICAL FIX ---

                ws_reader = asyncio.create_task(websocket.receive_text())

    except WebSocketDisconnect:
        logging.info(f"WebSocket disconnected for user {actor_username}.")
    except Exception as e:
        logging.error(f"Error in unified_io_handler for user {actor_username}: {e}")
    finally:
        if not ws_reader.done(): ws_reader.cancel()
        if not device_reader.done(): device_reader.cancel()


@router.websocket("/ws/{device_id}/{session_id}")
async def websocket_endpoint(websocket: WebSocket, device_id: str, session_id: str, db: Session = Depends(get_db)) -> None:
    actor_username = websocket.query_params.get("username", "unknown_ws_user")
    
    await websocket.accept()

    # --- Register Session ---
    with sessions_lock:
        session_state: SessionState = {
            'device_id': device_id, 
            'username': actor_username,
            'timestamp': asyncio.get_running_loop().time(),
            'is_dirty': False
        }
        ACTIVE_WEB_SESSIONS[session_id] = session_state
        logging.info(f"WebSocket session {session_id} for user {actor_username} on device {device_id} registered.")


    device_info: Optional[DeviceInfo] = get_device_info(device_id)  # type: ignore
    if not device_info:
        await websocket.close(code=1008, reason="在配置文件中未找到设备ID。")
        return
        
    net_connect: Optional[CiscoBaseConnection] = None
    loop = asyncio.get_running_loop()
    try:
        await websocket.send_text("[1/3] 正在建立SSH连接...\r\n")
        
        net_connect = await loop.run_in_executor(None, lambda: ConnectHandler(**device_info)) # type: ignore
        
        await websocket.send_text("[2/3] 连接成功, 正在进入特权模式...\r\n")
        if net_connect: await loop.run_in_executor(None, net_connect.enable)
        await websocket.send_text("[3/3] 特权模式已进入, 正在等待设备响应 (最长5秒)...\r\n")
        
        prompt = ""
        if net_connect: prompt = await loop.run_in_executor(None, lambda: net_connect.find_prompt(delay_factor=2))
        await websocket.send_text(f"\r\n{prompt}")

        if net_connect:
            await unified_io_handler(websocket, net_connect, actor_username, session_id, device_id, db)

    except NetmikoBaseException as e:
        error_type = "认证失败" if isinstance(e, NetmikoAuthenticationException) else "连接超时或错误"
        logging.error(f"WS connection failed for {device_id}: {error_type}: {e}")
        await websocket.send_text(f"\r\n--- 连接失败 ---\r\n原因: {error_type}: {e}\r\n")
    except Exception as e:
        logging.error(f"An unexpected WebSocket error occurred for device {device_id}: {e}")
        await websocket.send_text(f"\r\n--- 连接失败 ---\r\n原因: 未知连接错误: {e}\r\n")
    finally:
        # --- Auto-Audit on Disconnect Logic ---
        session_state_to_check = None
        with sessions_lock:
            if session_id in ACTIVE_WEB_SESSIONS:
                session_state_to_check = ACTIVE_WEB_SESSIONS.pop(session_id)
        
        if session_state_to_check and session_state_to_check['is_dirty']:
            logging.warning(f"DIRTY session {session_id} for device {device_id} disconnected. Triggering auto-audit.")
            # Run the synchronous, self-contained audit function in a background thread.
            threading.Thread(target=perform_auto_audit, args=(device_id, session_state_to_check['username'])).start()

        if net_connect and net_connect.is_alive():
            net_connect.disconnect()
        if websocket.client_state != WebSocketState.DISCONNECTED:
            await websocket.close()
        logging.info(f"WebSocket connection closed for device {device_id}, session {session_id}")