import React from 'react';
import { Toast } from 'react-hot-toast';

interface ProgressToastProps {
    t: Toast; // Toast object from react-hot-toast
    title: string;
    progress: number; // 0-100
    message: string;
}

const ProgressToast: React.FC<ProgressToastProps> = ({ t, title, progress, message }) => {
    return (
        <div 
            className={`${t.visible ? 'animate-enter' : 'animate-leave'} max-w-md w-full bg-bg-800 shadow-lg rounded-lg pointer-events-auto flex ring-1 ring-black ring-opacity-5 border border-bg-700`}
        >
            <div className="flex-1 w-0 p-4">
                <div className="flex items-start">
                    <div className="ml-3 flex-1">
                        <p className="text-sm font-medium text-text-100">{title}</p>
                        <p className="mt-1 text-sm text-text-300">{message}</p>
                        <div className="w-full bg-bg-700 rounded-full h-1.5 mt-2">
                            <div 
                                className="bg-primary-500 h-1.5 rounded-full transition-all duration-300" 
                                style={{ width: `${progress}%` }}
                            ></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProgressToast;
