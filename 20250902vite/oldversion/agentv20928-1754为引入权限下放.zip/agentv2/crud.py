# crud.txt - Create, Read, Update, Delete operations for database models.
# This file is the single source of truth for all database interactions.

import json
import logging
import datetime
import uuid
from typing import Dict, List, Any, Optional, cast

from sqlalchemy.orm import Session, joinedload
from sqlalchemy import desc

import models
from core import (
    calculate_block_hash, UserUpdatePayload, DevicePayload,
    ConfigTemplate as TemplatePayload, Policy as PolicyPayload, BlockDataDict
)


# --- Initial Data Structure (For seeding only) ---
INITIAL_DATA_RAW: Dict[str, Any] = {
    "devices": [
        {"id": "RTR01-NYC", "name": "Core Router NYC", "ipAddress": "192.168.1.1", "type": "Router"},
        {"id": "SW01-SFO", "name": "Access Switch SFO", "ipAddress": "10.10.5.254", "type": "Switch"},
        {"id": "FW01-LON", "name": "Edge Firewall London", "ipAddress": "203.0.113.1", "type": "Firewall"},
    ],
    "users": [
        {"id": 1, "username": "admin", "password": "admin", "role": "admin"},
        {"id": 2, "username": "operator1", "password": "password", "role": "operator"},
        {"id": 3, "username": "net_admin", "password": "password123", "role": "operator"},
    ],
    "settings": { "is_ai_analysis_enabled": True },
    "blockchains": {
        "RTR01-NYC": [{"index": 0, "timestamp": "2023-01-01T10:00:00Z", "data": { "deviceId": "RTR01-NYC", "version": 1, "operator": "system_init", "config": "hostname RTR01-NYC\n!\ninterface GigabitEthernet0/0\n ip address 192.168.1.1 255.255.255.0\n no shutdown\n!\nrouter ospf 1\n network 192.168.1.0 0.0.0.255 area 0\n!\nend", "diff": "+ hostname RTR01-NYC\n+ !\n+ interface GigabitEthernet0/0\n+  ip address 192.168.1.1 255.255.255.0\n+  no shutdown\n+ !\n+ router ospf 1\n+  network 192.168.1.0 0.0.0.255 area 0\n+ !\n+ end", "changeType": "initial", "summary": "初始系统配置。", "analysis": "这是设备的第一个配置区块，用于建立基线。", "security_risks": "无。这是一个标准的初始设置。", "compliance_report": {"overall_status": "passed", "results": []}}, "prev_hash": "0"}],
        "SW01-SFO": [{"index": 0, "timestamp": "2023-01-02T11:30:00Z", "data": { "deviceId": "SW01-SFO", "version": 1, "operator": "system_init", "config": "hostname SW01-SFO\n!\nvlan 10\n name USERS\n!\ninterface FastEthernet0/1\n switchport mode access\n switchport access vlan 10\n!\nend", "diff": "+ hostname SW01-SFO\n+ !\n+ vlan 10\n+  name USERS\n+ !\n+ interface FastEthernet0/1\n+  switchport mode access\n+  switchport access vlan 10\n+ !\n+ end", "changeType": "initial", "summary": "初始系统配置。", "analysis": "这是设备的第一个配置区块，用于建立基线。", "security_risks": "无。这是一个标准的初始设置。", "compliance_report": {"overall_status": "passed", "results": []}}, "prev_hash": "0"}],
        "FW01-LON": [{"index": 0, "timestamp": "2023-01-03T09:00:00Z", "data": { "deviceId": "FW01-LON", "version": 1, "operator": "system_init", "config": "hostname FW01-LON\n!\nip access-list extended INCOMING_FILTER\n permit tcp any host 203.0.113.1 eq 443\n deny ip any any log\n!\ninterface GigabitEthernet0/1\n ip access-group INCOMING_FILTER in\n!\nend", "diff": "+ hostname FW01-LON\n+ !\n+ ip access-list extended INCOMING_FILTER\n+  permit tcp any host 203.0.113.1 eq 443\n+  deny ip any any log\n+ !\n+ interface GigabitEthernet0/1\n+  ip access-group INCOMING_FILTER in\n+ !\n+ end", "changeType": "initial", "summary": "初始系统配置。", "analysis": "这是设备的第一个配置区块，用于建立基线。", "security_risks": "无。这是一个标准的初始设置。", "compliance_report": {"overall_status": "passed", "results": []}}, "prev_hash": "0"}],
    }
}

def get_initial_data_with_hashes() -> Dict[str, Any]:
    data = json.loads(json.dumps(INITIAL_DATA_RAW))
    for chain in data["blockchains"].values():
        for block in chain:
            block["hash"] = calculate_block_hash(cast(BlockDataDict, block["data"]), block["index"], block["timestamp"], block["prev_hash"])
    return data

INITIAL_DATA = get_initial_data_with_hashes()
MAX_LOG_ENTRIES = 1000

# --- Seeding ---
def seed_initial_data(db: Session):
    if db.query(models.User).count() > 0: return
    logging.warning("Database is empty. Seeding with initial data...")
    try:
        for user_data in INITIAL_DATA.get("users", []):
            db.add(models.User(**user_data))
        for device_data in INITIAL_DATA.get("devices", []):
            db.add(models.Device(id=device_data["id"], name=device_data["name"], ipAddress=device_data["ipAddress"], type=device_data["type"]))
            for block_data in INITIAL_DATA.get("blockchains", {}).get(device_data["id"], []):
                db.add(models.Block(device_id=device_data["id"], index=block_data["index"], timestamp=block_data["timestamp"], data=json.dumps(block_data["data"], sort_keys=True, separators=(',', ':'), ensure_ascii=False), prev_hash=block_data["prev_hash"], hash=block_data["hash"]))
        for key, value in INITIAL_DATA.get("settings", {}).items():
            db.add(models.Setting(key=key, value=str(value)))
        db.commit()
        logging.info("Initial data seeded successfully.")
    except Exception as e:
        logging.error(f"Error seeding initial data: {e}")
        db.rollback()
        raise

# --- Data Transformation ---
def _format_data_for_frontend(db_devices: List[models.Device], db_users: List[models.User], db_logs: List[models.AuditLog], db_templates: List[models.ConfigTemplate], db_policies: List[models.Policy], db_settings: List[models.Setting], db_deploy_history: List[models.DeploymentRecord]) -> Dict[str, Any]:
    blockchains = {device.id: sorted([{"index": b.index, "timestamp": b.timestamp, "data": json.loads(b.data), "prev_hash": b.prev_hash, "hash": b.hash} for b in device.blocks], key=lambda x: x['index']) for device in db_devices}
    settings = {s.key: json.loads(s.value.lower()) if s.value.lower() in ['true', 'false'] else s.value for s in db_settings}

    return {
        "devices": [{"id": d.id, "name": d.name, "ipAddress": d.ipAddress, "type": d.type, "policyIds": [p.id for p in d.policies]} for d in db_devices],
        "blockchains": blockchains,
        "users": [{"id": u.id, "username": u.username, "password": u.password, "role": u.role} for u in db_users],
        "audit_log": [{"timestamp": l.timestamp.isoformat().replace('+00:00', 'Z'), "username": l.username, "action": l.action} for l in db_logs],
        "templates": [{"id": t.id, "name": t.name, "content": t.content} for t in db_templates],
        "policies": [{"id": p.id, "name": p.name, "severity": p.severity, "description": p.description, "rule": p.rule, "enabled": p.enabled} for p in db_policies],
        "deployment_history": [{"id": h.id, "timestamp": h.timestamp.isoformat().replace('+00:00', 'Z'), "operator": h.operator, "template_name": h.template_name, "status": h.status, "summary": h.summary, "target_devices": json.loads(h.target_devices), "results": json.loads(h.results)} for h in db_deploy_history],
        "settings": settings,
    }

# --- Generic CRUD ---
def get_all_data(db: Session) -> Dict[str, Any]:
    devices = db.query(models.Device).options(joinedload(models.Device.blocks), joinedload(models.Device.policies)).all()
    users = db.query(models.User).all()
    logs = db.query(models.AuditLog).order_by(desc(models.AuditLog.timestamp)).limit(MAX_LOG_ENTRIES).all()
    templates = db.query(models.ConfigTemplate).all()
    policies = db.query(models.Policy).all()
    settings = db.query(models.Setting).all()
    deploy_history = db.query(models.DeploymentRecord).order_by(desc(models.DeploymentRecord.timestamp)).limit(100).all()
    return _format_data_for_frontend(devices, users, logs, templates, policies, settings, deploy_history)

def reset_all_data(db: Session):
    for table in reversed(models.Base.metadata.sorted_tables):
        db.execute(table.delete())
    db.commit()
    seed_initial_data(db)

def log_action(db: Session, username: str, action: str):
    db.add(models.AuditLog(username=username, action=action))
    db.commit()

# --- Device & Block ---
def get_device(db: Session, device_id: str) -> Optional[models.Device]:
    return db.query(models.Device).filter(models.Device.id == device_id).first()

def get_device_with_details(db: Session, device_id: str) -> Optional[models.Device]:
    return db.query(models.Device).options(joinedload(models.Device.blocks), joinedload(models.Device.policies)).filter(models.Device.id == device_id).first()

def create_device_with_genesis_block(db: Session, device_payload: DevicePayload) -> models.Device:
    new_device_orm = models.Device(id=device_payload.id, name=device_payload.name, ipAddress=device_payload.ipAddress, type=device_payload.type)
    if device_payload.policyIds:
        policies = db.query(models.Policy).filter(models.Policy.id.in_(device_payload.policyIds)).all()
        new_device_orm.policies = policies
    
    db.add(new_device_orm)
    
    genesis_data: Dict[str, Any] = {"deviceId": device_payload.id, "version": 1, "operator": "system_init", "config": f"hostname {device_payload.name}\n!\n! Initial configuration created by ChainTrace.", "diff": f"+ hostname {device_payload.name}\n+ !\n+ ! Initial configuration created by ChainTrace.", "changeType": "initial", "summary": "设备已创建。", "analysis": "这是新设备的第一个配置区块...", "security_risks": "无。", "compliance_report": {"overall_status": "passed", "results": []}}
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
    hash_hex = calculate_block_hash(cast(BlockDataDict, genesis_data), 0, timestamp, "0")
    db.add(models.Block(device_id=device_payload.id, index=0, timestamp=timestamp, data=json.dumps(genesis_data, sort_keys=True, separators=(',', ':'), ensure_ascii=False), prev_hash="0", hash=hash_hex))
    
    db.commit()
    db.refresh(new_device_orm)
    return new_device_orm

def update_device(db: Session, device_id: str, device_update: DevicePayload) -> Optional[models.Device]:
    db_device = db.query(models.Device).options(joinedload(models.Device.policies)).filter(models.Device.id == device_id).first()
    if db_device:
        db_device.name = device_update.name
        db_device.ipAddress = device_update.ipAddress
        db_device.type = device_update.type
        
        if device_update.policyIds is not None:
            policies = db.query(models.Policy).filter(models.Policy.id.in_(device_update.policyIds)).all()
            db_device.policies = policies
        
        db.commit()
        db.refresh(db_device)
    return db_device


def delete_device(db: Session, device_id: str) -> bool:
    db_device = get_device(db, device_id)
    if db_device:
        db.delete(db_device)
        db.commit()
        return True
    return False

def add_block(db: Session, device_id: str, new_block: Dict[str, Any]) -> Dict[str, Any]:
    db.add(models.Block(device_id=device_id, index=new_block["index"], timestamp=new_block["timestamp"], data=json.dumps(new_block["data"], sort_keys=True, separators=(',', ':'), ensure_ascii=False), prev_hash=new_block["prev_hash"], hash=new_block["hash"]))
    db.commit()
    return new_block

# --- User ---
def get_user(db: Session, user_id: int) -> Optional[models.User]: return db.query(models.User).filter(models.User.id == user_id).first()
def get_user_by_username(db: Session, username: str) -> Optional[models.User]: return db.query(models.User).filter(models.User.username == username).first()
def get_users(db: Session) -> List[models.User]: return db.query(models.User).all()

def create_user(db: Session, user: UserUpdatePayload) -> models.User:
    db_user = models.User(username=user.username, password=user.password, role=user.role)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def update_user(db: Session, user_id: int, user: UserUpdatePayload) -> models.User:
    db_user = get_user(db, user_id)
    if db_user:
        db_user.username = user.username
        db_user.role = user.role
        if user.password: 
            db_user.password = user.password
        db.commit()
        db.refresh(db_user)
    return db_user

def delete_user(db: Session, user_id: int): 
    db_user = get_user(db, user_id)
    if db_user: 
        db.delete(db_user)
        db.commit()

# --- Template ---
def get_template(db: Session, template_id: str) -> Optional[models.ConfigTemplate]: return db.query(models.ConfigTemplate).filter(models.ConfigTemplate.id == template_id).first()
def get_template_by_name(db: Session, name: str) -> Optional[models.ConfigTemplate]: return db.query(models.ConfigTemplate).filter(models.ConfigTemplate.name == name).first()
def create_template(db: Session, template: TemplatePayload):
    db_template = models.ConfigTemplate(**template.model_dump())
    db.add(db_template); db.commit()
def update_template(db: Session, template_id: str, template: TemplatePayload):
    db_template = get_template(db, template_id)
    if db_template:
        db_template.name = template.name
        db_template.content = template.content
        db.commit()
def delete_template(db: Session, template_id: str):
    db_template = get_template(db, template_id)
    if db_template: db.delete(db_template); db.commit()

# --- Policy ---
def get_policy(db: Session, policy_id: str) -> Optional[models.Policy]: return db.query(models.Policy).filter(models.Policy.id == policy_id).first()
def get_policy_by_name(db: Session, name: str) -> Optional[models.Policy]: return db.query(models.Policy).filter(models.Policy.name == name).first()
def get_policies(db: Session) -> List[models.Policy]: return db.query(models.Policy).all()
def create_policy(db: Session, policy: PolicyPayload):
    db_policy = models.Policy(**policy.model_dump())
    db.add(db_policy); db.commit()
def update_policy(db: Session, policy_id: str, policy: PolicyPayload):
    db_policy = get_policy(db, policy_id)
    if db_policy:
        db_policy.name = policy.name
        db_policy.severity = policy.severity
        db_policy.description = policy.description
        db_policy.rule = policy.rule
        db_policy.enabled = policy.enabled
        db.commit()
def delete_policy(db: Session, policy_id: str):
    db_policy = get_policy(db, policy_id)
    if db_policy: db.delete(db_policy); db.commit()

# --- Settings ---
def get_settings(db: Session) -> List[models.Setting]: return db.query(models.Setting).all()
def get_settings_as_dict(db: Session) -> Dict[str, Any]:
    settings = get_settings(db)
    return {s.key: json.loads(s.value.lower()) if s.value.lower() in ['true', 'false'] else s.value for s in settings}
def update_setting(db: Session, key: str, value: str):
    db_setting = db.query(models.Setting).filter(models.Setting.key == key).first()
    if db_setting: db_setting.value = value
    else: db_setting = models.Setting(key=key, value=value); db.add(db_setting)
    db.commit()

# --- Deployment History ---
def create_deployment_record(db: Session, operator: str, template_name: str, target_devices: List[str], results: List[Dict[str, Any]]):
    success_count = sum(1 for r in results if r['status'] == 'success')
    status = "Completed" if success_count == len(results) else "Completed with Errors"
    summary = f"{success_count} 成功, {len(results) - success_count} 失败。"
    
    record = models.DeploymentRecord(
        id=str(uuid.uuid4()),
        operator=operator,
        template_name=template_name,
        status=status,
        summary=summary,
        target_devices=json.dumps(target_devices),
        results=json.dumps(results)
    )
    db.add(record)
    db.commit()