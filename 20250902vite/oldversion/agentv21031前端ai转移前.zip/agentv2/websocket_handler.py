# websocket_handler.py - WebSocket handling for ChainTrace Agent's interactive console

import logging
import asyncio
import threading
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from fastapi.websockets import WebSocketState
from netmiko import ConnectHandler # type: ignore
from netmiko.exceptions import NetmikoAuthenticationException, NetmikoBaseException # type: ignore
from netmiko.cisco_base_connection import CiscoBaseConnection # type: ignore
from typing import Optional, TypedDict

from sqlalchemy.orm import Session

# Import from our own refactored modules
from core import INTERCEPTION_RULES, ACTIVE_WEB_SESSIONS, sessions_lock, SessionState
from services import get_device_info, perform_auto_audit # type: ignore
from database import get_db

# --- New In-memory "Dirty" Session Tracking ---
# This store will track which sessions have had potential config changes.
READ_ONLY_COMMANDS = ('show', 'display', 'dir', 'ping', 'traceroute')


# Type definition for device information
class DeviceInfo(TypedDict, total=False):
    host: str
    device_type: str
    username: str
    password: str
    secret: Optional[str]
    timeout: int

router = APIRouter()

def check_command_against_rules(command: str) -> Optional[str]:
    """
    Checks a command against the loaded interception rules from config.ini.
    Returns the name of the violated rule if a violation is found, otherwise None.
    """
    # 1. Check 'startswith' rules
    for rule_name, pattern in INTERCEPTION_RULES.get('startswith', []):
        if command.startswith(pattern):
            logging.warning(f"Command '{command}' blocked by startswith rule: '{rule_name}' (pattern: {pattern})")
            return rule_name
            
    # 2. Check 'contains' rules
    for rule_name, pattern in INTERCEPTION_RULES.get('contains', []):
        if pattern in command:
            logging.warning(f"Command '{command}' blocked by contains rule: '{rule_name}' (pattern: {pattern})")
            return rule_name

    # 3. Check 'regex' rules
    for rule_name, compiled_regex in INTERCEPTION_RULES.get('regex', []):
        if compiled_regex.search(command):
            logging.warning(f"Command '{command}' blocked by regex rule: '{rule_name}' (pattern: {compiled_regex.pattern})")
            return rule_name
            
    return None


async def unified_io_handler(websocket: WebSocket, net_connect: CiscoBaseConnection, actor_username: str, session_id: str, device_id: str, db: Session) -> None:
    """
    A unified I/O handler that now performs real-time interception checks based on config.ini rules.
    """
    line_buffer: str = ""
    loop = asyncio.get_running_loop()

    ws_reader: asyncio.Task[str] = asyncio.create_task(websocket.receive_text())
    device_reader: "asyncio.Future[str]" = loop.run_in_executor(None, net_connect.read_channel)

    try:
        while True:
            done, _ = await asyncio.wait([ws_reader, device_reader], return_when=asyncio.FIRST_COMPLETED)

            # --- Handle output from the device ---
            if device_reader in done:
                device_output: str = device_reader.result()
                if device_output: await websocket.send_text(device_output)
                device_reader = loop.run_in_executor(None, net_connect.read_channel)

            # --- Handle input from the user ---
            if ws_reader in done:
                user_input: str = ws_reader.result()
                is_enter_key = '\r' in user_input or '\n' in user_input

                if is_enter_key:
                    # Normalize command: strip whitespace, lowercase, and collapse internal spaces.
                    command_to_check = ' '.join(line_buffer.strip().lower().split())
                    
                    logging.info(f"Intercept check: User='{actor_username}', Buffer='{line_buffer.strip()}', Normalized='{command_to_check}'")

                    if command_to_check and not command_to_check.startswith(READ_ONLY_COMMANDS):
                        with sessions_lock:
                            if session_id in ACTIVE_WEB_SESSIONS and not ACTIVE_WEB_SESSIONS[session_id]['is_dirty']:
                                ACTIVE_WEB_SESSIONS[session_id]['is_dirty'] = True
                                logging.info(f"Session {session_id} for device {device_id} marked as DIRTY.")
                    
                    violated_rule_name: Optional[str] = None
                    if command_to_check:
                        violated_rule_name = check_command_against_rules(command_to_check)

                    if violated_rule_name:
                        logging.warning(f"User '{actor_username}' attempted forbidden command: '{line_buffer.strip()}' which violates rule: '{violated_rule_name}'")
                        error_msg = (
                            f"\r\n\x1b[31m[ChainTrace Interception] Command blocked by rule: '{violated_rule_name}'.\r\n"
                            f"Your command '{line_buffer.strip()}' was not executed.\x1b[0m\r\n"
                        )
                        await websocket.send_text(error_msg)
                        
                        # Use CTRL+U (Kill Line) for a reliable, atomic clearing of the input buffer on the device.
                        clear_line_signal = '\x15' 
                        await loop.run_in_executor(None, net_connect.write_channel, clear_line_signal + '\n')
                    else:
                        # Command is allowed, send it to the device.
                        await loop.run_in_executor(None, net_connect.write_channel, '\n')
                    
                    line_buffer = ""
                
                elif user_input == '\x7f': # Backspace
                    if line_buffer: line_buffer = line_buffer[:-1]
                    await loop.run_in_executor(None, net_connect.write_channel, '\x7f')
                
                else: # Other characters
                    line_buffer += user_input
                    await loop.run_in_executor(None, net_connect.write_channel, user_input)

                ws_reader = asyncio.create_task(websocket.receive_text())

    except WebSocketDisconnect:
        logging.info(f"WebSocket disconnected for user {actor_username}.")
    except Exception as e:
        logging.error(f"Error in unified_io_handler for user {actor_username}: {e}")
    finally:
        if not ws_reader.done(): ws_reader.cancel()
        if not device_reader.done(): device_reader.cancel()


@router.websocket("/ws/{device_id}/{session_id}")
async def websocket_endpoint(websocket: WebSocket, device_id: str, session_id: str, db: Session = Depends(get_db)) -> None:
    actor_username = websocket.query_params.get("username", "unknown_ws_user")
    
    await websocket.accept()

    # --- Register Session ---
    with sessions_lock:
        ACTIVE_WEB_SESSIONS[session_id] = {'device_id': device_id, 'is_dirty': False}
        logging.info(f"WebSocket session {session_id} registered for device {device_id}.")

    device_info: Optional[DeviceInfo] = get_device_info(device_id)  # type: ignore
    if not device_info:
        await websocket.close(code=1008, reason="在配置文件中未找到设备ID。")
        return
        
    net_connect: Optional[CiscoBaseConnection] = None
    loop = asyncio.get_running_loop()
    try:
        await websocket.send_text("[1/3] 正在建立SSH连接...\r\n")
        
        net_connect = await loop.run_in_executor(None, lambda: ConnectHandler(**device_info)) # type: ignore
        
        await websocket.send_text("[2/3] 连接成功, 正在进入特权模式...\r\n")
        if net_connect: await loop.run_in_executor(None, net_connect.enable)
        await websocket.send_text("[3/3] 特权模式已进入, 正在等待设备响应 (最长5秒)...\r\n")
        
        prompt = ""
        if net_connect: prompt = await loop.run_in_executor(None, lambda: net_connect.find_prompt(delay_factor=2))
        await websocket.send_text(f"\r\n{prompt}")

        if net_connect:
            await unified_io_handler(websocket, net_connect, actor_username, session_id, device_id, db)

    except NetmikoBaseException as e:
        error_type = "认证失败" if isinstance(e, NetmikoAuthenticationException) else "连接超时或错误"
        logging.error(f"WS connection failed for {device_id}: {error_type}: {e}")
        await websocket.send_text(f"\r\n--- 连接失败 ---\r\n原因: {error_type}: {e}\r\n")
    except Exception as e:
        logging.error(f"An unexpected WebSocket error occurred for device {device_id}: {e}")
        await websocket.send_text(f"\r\n--- 连接失败 ---\r\n原因: 未知连接错误: {e}\r\n")
    finally:
        # --- Auto-Audit on Disconnect Logic ---
        session_state = None
        with sessions_lock:
            if session_id in ACTIVE_WEB_SESSIONS:
                session_state = ACTIVE_WEB_SESSIONS.pop(session_id)
        
        if session_state and session_state['is_dirty']:
            logging.warning(f"DIRTY session {session_id} for device {device_id} disconnected. Triggering auto-audit.")
            # Run the synchronous, self-contained audit function in a background thread.
            # This is a robust way to handle background tasks without session/thread issues.
            await loop.run_in_executor(None, perform_auto_audit, device_id)

        if net_connect and net_connect.is_alive():
            net_connect.disconnect()
        if websocket.client_state != WebSocketState.DISCONNECTED:
            await websocket.close()
        logging.info(f"WebSocket connection closed for device {device_id}, session {session_id}")