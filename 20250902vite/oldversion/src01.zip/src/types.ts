// FIX: Define SessionUser here to break the circular dependency.
// It was previously imported from './utils/session', which created an import cycle.
export interface SessionUser {
    username: string;
    sessionId: string;
}

export interface Device {
  id: string;
  name: string;
  ipAddress: string;
  type: 'Router' | 'Switch' | 'Firewall';
}

export interface Policy {
  id: string;
  name: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
  rule: string;
  enabled: boolean;
}

export interface ComplianceResult {
  policy_id: string;
  policy_name: string;
  status: 'passed' | 'failed' | 'not_applicable';
  details: string;
}

export interface ComplianceReport {
  overall_status: 'passed' | 'failed' | 'not_applicable';
  results: ComplianceResult[];
}


export interface BlockData {
  deviceId: string;
  version: number;
  operator: string;
  config: string;
  diff: string;
  changeType: 'initial' | 'update' | 'rollback';
  summary: string;
  analysis: string;
  security_risks: string;
  compliance_report?: ComplianceReport;
}

export interface Block {
  index: number;
  timestamp: string;
  data: BlockData;
  prev_hash: string;
  hash: string;
}

export interface AIServiceSettings {
  enabled: boolean;
  apiUrl?: string;
}

export interface AppSettings {
  ai: {
    analysis: AIServiceSettings;
    commandGeneration: AIServiceSettings;
    configCheck: AIServiceSettings;
  };
  agentApiUrl?: string;
}

export interface User {
  id: number;
  username: string;
  password?: string; // Password should be handled securely on a real backend
  role: 'admin' | 'operator';
}


export interface AuditLogEntry {
    timestamp: string;
    username: string;
    action: string;
}

export interface ConfigTemplate {
  id: string;
  name: string;
  content: string;
}
