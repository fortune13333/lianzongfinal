import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Device } from '../types';
import { AppError } from "../utils/errors";
import { useStore } from "../store/useStore";

let aiInstance: GoogleGenAI | null = null;

export const checkKeyAvailability = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new AppError( "Google Gemini API key is not configured.", 'ERR_GEMINI_API_KEY_MISSING');
    }
};

const getAiClient = (): GoogleGenAI => {
    if (aiInstance) return aiInstance;
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error("Google Gemini API key is not configured. Please set it up in your environment configuration.");
    }
    aiInstance = new GoogleGenAI({ apiKey });
    return aiInstance;
};

// --- Resilience Helpers for AI Calls ---

/**
 * Checks if an error from the AI service is temporary and thus retryable.
 * @param error The error object caught.
 * @returns True if the error is a 503/overload error, false otherwise.
 */
const isRetryableError = (error: unknown): boolean => {
    if (error instanceof Error) {
        // Check for specific Google AI API error structure for 503
        if (error.message.includes('"code":503') || error.message.includes('"status":"UNAVAILABLE"')) {
            return true;
        }
        // General check for overload messages
        const lowerCaseMessage = error.message.toLowerCase();
        if (lowerCaseMessage.includes('overloaded') || lowerCaseMessage.includes('try again later')) {
            return true;
        }
    }
    return false;
};

/**
 * Parses a Google AI error to extract a user-friendly message.
 * @param error The error object.
 * @returns A cleaner, more readable error message string.
 */
const parseGoogleAIError = (error: Error): string => {
    try {
        // Errors from the service often come as a JSON string in the message
        const errorJson = JSON.parse(error.message);
        if (errorJson.error && errorJson.error.message) {
            return `AI 服务返回错误: ${errorJson.error.message}`;
        }
    } catch (e) {
        // Not a JSON error, return original message as is
    }
    return error.message;
};


/**
 * A wrapper function that retries an async AI API call with exponential backoff.
 * @param apiCall The async function to call and potentially retry.
 * @returns The result of the successful API call.
 * @throws The last error if all retries fail, or a non-retryable error.
 */
const retryableAIGeneration = async <T>(apiCall: () => Promise<T>): Promise<T> => {
    let lastError: unknown = new Error("AI call failed after multiple retries.");
    const maxRetries = 3;
    let delay = 1000; // Start with 1 second delay

    for (let i = 0; i < maxRetries; i++) {
        try {
            return await apiCall();
        } catch (error) {
            lastError = error;
            if (isRetryableError(error)) {
                // If the error is retryable, wait and try again
                console.warn(`AI model is overloaded. Retrying in ${delay / 1000}s... (Attempt ${i + 1}/${maxRetries})`);
                await new Promise(resolve => setTimeout(resolve, delay));
                delay *= 2; // Double the delay for the next retry (exponential backoff)
                continue;
            }
            // If the error is not retryable, re-throw it immediately
            throw error;
        }
    }
    // If all retries have been exhausted, throw the last captured error
    throw lastError;
};

const getSyntaxTypeFromDevice = (device: Device): string => {
    const deviceType = device.netmiko_device_type?.toLowerCase() || '';

    if (deviceType.includes('huawei') || deviceType.includes('h3c') || deviceType.includes('hp_comware')) {
        return 'H3C Comware / Huawei VRP style';
    }
    if (deviceType.includes('juniper') || deviceType.includes('junos')) {
        return 'Juniper Junos style';
    }
    if (deviceType.includes('cisco_asa')) {
        return 'Cisco ASA style';
    }
    // Default to Cisco IOS as it's the most common
    return 'Cisco IOS style';
};


const generateConfigFromPrompt = async (
  userInput: string,
  device: Device,
  currentConfig: string,
): Promise<string> => {
    const settings = useStore.getState().settings;
    if (!settings.ai.commandGeneration.enabled) {
        throw new Error('AI 命令生成功能已被禁用。');
    }
    const { apiUrl } = settings.ai.commandGeneration;
    
    const syntaxType = getSyntaxTypeFromDevice(device);
    
    if (apiUrl) {
        console.log("Generating config with custom command generation API...");
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userInput, device, currentConfig, syntaxType }),
            });
            if (!response.ok) throw new Error(`Custom API failed with status: ${response.status}`);
            const data = await response.json();
            return data.commands || '';
        } catch (error) {
            console.error("Custom command generation API call failed:", error);
            const msg = error instanceof Error ? error.message : "An unknown error occurred.";
            throw new Error(`自定义 AI 接口调用失败: ${msg}`);
        }
    }

    const prompt = `
    You are an expert network configuration assistant. The target device uses ${syntaxType} syntax.
    
    IMPORTANT: Pay close attention to the specific syntax style requested. For H3C Comware / Huawei VRP, remember these key differences from Cisco IOS:
    - To enter configuration mode, the command is 'system-view'. The prompt will change to contain square brackets, like [H3C].
    - To enable the telnet server, the command is 'telnet server enable' (executed in system-view).
    - To configure protocols on VTY lines, use 'protocol inbound <protocol>'. For example: 'protocol inbound ssh telnet'.
    - Do NOT use 'configure terminal' or 'transport input'. These are Cisco IOS commands.

    The user wants to achieve: "${userInput}".
    
    Current running configuration for context:
    ---
    ${currentConfig}
    ---
    
    Generate ONLY the necessary configuration commands required to fulfill the user's request.
    - Do not include explanations, intro phrases, or markdown.
    - Output only the raw command lines.
    - For multi-step configurations (like entering system-view, then an interface, then a command), provide all necessary commands in sequence.
    `;

    try {
        const ai = getAiClient();
        const apiCall = () => ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        // FIX: Explicitly type the response to resolve 'unknown' type error.
        const response = await retryableAIGeneration<GenerateContentResponse>(apiCall);
        return response.text?.trim() ?? '';
    } catch (error) {
        console.error("Gemini config generation failed:", error);
        const errorMessage = error instanceof Error ? parseGoogleAIError(error) : "An unknown error occurred with the AI model.";
        throw new Error(`AI 命令生成失败: ${errorMessage}`);
    }
};

const checkConfiguration = async (
    config: string,
    deviceType: Device['type'],
): Promise<string> => {
    const settings = useStore.getState().settings;
    if (!settings.ai.configCheck.enabled) {
        throw new Error('AI 配置体检功能已被禁用。');
    }
    const { apiUrl } = settings.ai.configCheck;

    const syntaxType = {
        'Router': 'Cisco IOS style',
        'Switch': 'Cisco IOS style',
        'Firewall': 'Cisco ASA style'
    }[deviceType];

    if (apiUrl) {
        console.log("Checking config with custom check API...");
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ config, deviceType, syntaxType }),
            });
            if (!response.ok) throw new Error(`Custom API failed with status: ${response.status}`);
            const data = await response.json();
            return data.report || '自定义接口未返回报告。';
        } catch (error) {
            console.error("Custom config check API call failed:", error);
            const msg = error instanceof Error ? error.message : "An unknown error occurred.";
            throw new Error(`自定义 AI 接口调用失败: ${msg}`);
        }
    }

    const prompt = `
    You are an expert network security auditor. The device uses ${syntaxType} syntax.
    Analyze this configuration. Your task is to:
    1. Identify security vulnerabilities.
    2. Check for best practice violations.
    3. Find logical errors.
    4. Provide actionable recommendations using bullet points.
    If no issues are found, state that the configuration appears solid.
    Provide the response as a single block of text in Simplified Chinese. Do not use markdown.
    Configuration to analyze:
    ---
    ${config}
    ---
    `;

    try {
        const ai = getAiClient();
        const apiCall = () => ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        // FIX: Explicitly type the response to resolve 'unknown' type error.
        const response = await retryableAIGeneration<GenerateContentResponse>(apiCall);
        return response.text?.trim() ?? '';
    } catch (error) {
        console.error("Gemini config check failed:", error);
        const errorMessage = error instanceof Error ? parseGoogleAIError(error) : "An unknown error occurred with the AI model.";
        throw new Error(`AI 配置体检失败: ${errorMessage}`);
    }
};

export const geminiService = {
  checkKeyAvailability,
  generateConfigFromPrompt,
  checkConfiguration,
};