import React, { useState, useEffect, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { Block, SessionUser, Policy, Device } from '../types';
import { verifyChain } from '../utils/crypto';
import { joinDeviceSessionAPI, getActiveSessionsAPI, leaveDeviceSessionAPI } from '../utils/session';
import HistoryItem from './HistoryItem';
import BlockDetailsModal from './BlockDetailsModal';
import VerificationModal, { VerificationResult } from './VerificationModal';
import { CheckCircleIcon } from './AIIcons';
import InteractiveTerminal from './InteractiveTerminal';

interface DeviceDetailsProps {
  device: Device;
  isActive: boolean;
}

const AppliedPolicies: React.FC<{ appliedPolicyIds: string[], allPolicies: Policy[] }> = ({ appliedPolicyIds, allPolicies }) => {
    const policies = useMemo(() => {
        const policyMap = new Map(allPolicies.map(p => [p.id, p]));
        return appliedPolicyIds.map(id => policyMap.get(id)).filter(Boolean) as Policy[];
    }, [appliedPolicyIds, allPolicies]);

    if (policies.length === 0) {
        return (
            <div className="text-xs text-text-500 italic">
                未应用任何合规策略。
            </div>
        );
    }

    return (
        <div className="flex flex-wrap gap-2">
            {policies.map(policy => (
                <span key={policy.id} className="text-xs font-medium bg-bg-800 text-text-300 px-2 py-1 rounded-full">
                    {policy.name}
                </span>
            ))}
        </div>
    );
};


const DeviceDetails: React.FC<DeviceDetailsProps> = ({ device, isActive }) => {
  const {
    blockchains,
    currentUser,
    settings,
    policies,
    promptRollback,
  } = useStore(state => ({
    blockchains: state.blockchains,
    currentUser: state.currentUser!,
    settings: state.settings,
    policies: state.policies,
    promptRollback: state.promptRollback,
  }));

  const [isVerifying, setIsVerifying] = useState(false);
  
  const [selectedBlock, setSelectedBlock] = useState<Block | null>(null);
  const [verificationResults, setVerificationResults] = useState<VerificationResult[]>([]);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [activeSessions, setActiveSessions] = useState<SessionUser[]>([]);
  const sessionId = useMemo(() => crypto.randomUUID(), []);

  const deviceChain = useMemo(() => blockchains[device.id] || [], [blockchains, device.id]);

  useEffect(() => {
    if (!isActive || !settings.agentApiUrl) return;
    
    const deviceId = device.id;
    const agentApiUrl = settings.agentApiUrl;
    
    const sessionHeartbeat = async () => {
      try {
        await joinDeviceSessionAPI(deviceId, currentUser.username, sessionId, agentApiUrl);
        const sessions = await getActiveSessionsAPI(deviceId, agentApiUrl);
        setActiveSessions(sessions);
      } catch (error) {
        console.error("Session heartbeat failed:", error);
      }
    };

    sessionHeartbeat();
    const intervalId = setInterval(sessionHeartbeat, 3000);

    return () => {
      clearInterval(intervalId);
      if (agentApiUrl && deviceId && sessionId) {
        leaveDeviceSessionAPI(deviceId, sessionId, agentApiUrl);
      }
    };
  }, [isActive, device.id, sessionId, currentUser.username, settings.agentApiUrl]);


  const handleVerifyChain = async () => {
    const chain = blockchains[device.id];
    if (!chain) return;

    setIsVerificationModalOpen(true);
    setIsVerifying(true);
    setVerificationResults(chain.map(block => ({ index: block.index, status: 'pending' })));

    await verifyChain(chain, (index, status, details) => {
      setVerificationResults(prev => prev.map(r => r.index === index ? { ...r, status, details } : r));
    });
    
    setIsVerifying(false);
  };
  
  const handleSelectBlock = (block: Block) => {
    setSelectedBlock(block);
  };

  const otherSessions = activeSessions.filter(s => s.sessionId !== sessionId);

  return (
    <div className="absolute inset-0 flex flex-col" style={{ display: isActive ? 'flex' : 'none' }}>
      {/* Top section with headers and policies. It will not grow. */}
      <div className="flex-shrink-0 space-y-4">
        {/* Header Section */}
        <div className="flex justify-between items-start">
          <div>
              <h2 className="text-3xl font-bold text-text-100">{device.name}</h2>
              <p className="text-text-400 font-mono">{device.ipAddress} ({device.type})</p>
              {otherSessions.length > 0 && (
                  <div className="mt-2 text-xs text-amber-400 animate-pulse">
                      同时查看: {otherSessions.map(s => s.username).join(', ')}
                  </div>
              )}
          </div>
          <div className="flex items-center gap-2">
              <button
                  onClick={handleVerifyChain}
                  className="flex items-center gap-2 text-sm bg-bg-800 hover:bg-bg-700 text-text-100 font-bold py-2 px-3 rounded-md transition-colors"
                  aria-label="验证链完整性"
              >
                  <CheckCircleIcon />
                  <span>验证链完整性</span>
              </button>
          </div>
        </div>
        
        {/* Applied Policies Section */}
        <div className="bg-bg-900 p-3 rounded-lg border border-bg-800">
          <h4 className="text-xs font-semibold text-text-400 uppercase tracking-wider mb-2">应用的合规策略</h4>
          <AppliedPolicies appliedPolicyIds={device.policyIds || []} allPolicies={policies} />
        </div>
      </div>
      
      {/* Main content layout that grows to fill remaining space, now using CSS Grid */}
      <div className="flex-grow mt-4 grid grid-rows-[minmax(0,2fr),minmax(0,1fr)] min-h-0 gap-4">
        {/* Terminal Section: takes 2/3 of available space */}
        <div className="min-h-0">
          <InteractiveTerminal device={device} sessionId={sessionId} />
        </div>
        
        {/* History Section: takes 1/3 of available space */}
        <div className="flex flex-col min-h-0">
          <h3 className="flex-shrink-0 text-xl font-semibold text-text-200 border-b-2 border-bg-800 pb-2 mb-4">配置历史 ({deviceChain.length})</h3>
          <div className="flex-grow overflow-y-auto pr-2 space-y-4 min-h-0">
            {deviceChain.slice().reverse().map((block, index) => (
                <HistoryItem
                key={block.hash}
                block={block}
                isLatest={index === 0}
                onSelectBlock={() => handleSelectBlock(block)}
                onRollback={() => promptRollback(block)}
                />
            ))}
          </div>
        </div>
      </div>
      
      {/* Modals */}
      {selectedBlock && (
        <BlockDetailsModal 
            block={selectedBlock}
            prevConfig={deviceChain.find(b => b.index === selectedBlock.index - 1)?.data.config || ''}
            onClose={() => setSelectedBlock(null)}
        />
      )}
      {isVerificationModalOpen && (
        <VerificationModal 
            results={verificationResults}
            chain={deviceChain}
            isVerifying={isVerifying}
            onClose={() => setIsVerificationModalOpen(false)}
        />
      )}
    </div>
  );
};

export default DeviceDetails;