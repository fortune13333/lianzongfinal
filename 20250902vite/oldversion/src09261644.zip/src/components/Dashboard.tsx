import React, { useState } from 'react';
import { Device, Block, User, AuditLogEntry, ConfigTemplate, Policy } from '../types';
import { TrashIcon, PlusIcon } from './AIIcons';
import AdminPanel from './admin/AdminPanel';
import BulkDeployModal from './admin/BulkDeployModal';
import { useStore } from '../store/useStore';

interface DashboardProps {
  // All props removed and replaced by useStore hook
}

const DeviceIcon: React.FC<{ type: Device['type'] }> = ({ type }) => {
  const iconPath = {
    Router: "M13 10V3L4 14h7v7l9-11h-7z",
    Switch: "M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4",
    Firewall: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z",
  };
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d={iconPath[type]} />
    </svg>
  );
};

const SkeletonCard: React.FC = () => (
  <div className="bg-bg-900 p-4 rounded-lg shadow-md animate-pulse">
    <div className="flex items-center gap-4">
      <div className="w-12 h-12 bg-bg-800 rounded-md"></div>
      <div className="flex-1 space-y-2">
        <div className="h-4 bg-bg-800 rounded w-3/4"></div>
        <div className="h-3 bg-bg-800 rounded w-1/2"></div>
      </div>
    </div>
    <div className="mt-4 border-t border-bg-800 pt-3 space-y-2">
      <div className="h-3 bg-bg-800 rounded w-full"></div>
      <div className="h-3 bg-bg-800 rounded w-1/2"></div>
      <div className="h-3 bg-bg-800 rounded w-1/3"></div>
    </div>
  </div>
);

const BulkActionsToolbar: React.FC<{
    selectedCount: number;
    onClear: () => void;
    onDeploy: () => void;
}> = ({ selectedCount, onClear, onDeploy }) => {
    return (
        <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-xl p-4 z-40">
            <div className="bg-bg-800 rounded-lg shadow-2xl flex items-center justify-between p-3 border border-bg-700">
                <span className="text-text-100 font-semibold">{selectedCount} 台设备已选择</span>
                <div className="flex items-center gap-2">
                    <button onClick={onDeploy} className="text-sm bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-3 rounded-md transition-colors">
                        部署模板
                    </button>
                    <button onClick={onClear} className="text-sm bg-bg-700 hover:bg-bg-600 text-text-100 font-medium py-2 px-3 rounded-md transition-colors">
                        清空选择
                    </button>
                </div>
            </div>
        </div>
    );
};

const Dashboard: React.FC<DashboardProps> = () => {
  const { 
    devices, blockchains, selectDevice, isLoading, resetData, 
    deleteDevice, openAddDeviceModal, currentUser, fetchData
  } = useStore(state => ({
    devices: state.devices,
    blockchains: state.blockchains,
    selectDevice: state.selectDevice,
    isLoading: state.isLoading,
    resetData: state.resetData,
    deleteDevice: state.deleteDevice,
    openAddDeviceModal: state.openAddDeviceModal,
    currentUser: state.currentUser!,
    fetchData: state.fetchData
  }));
  
  const isAdmin = currentUser.role === 'admin';
  const [selectedDeviceIds, setSelectedDeviceIds] = useState<Set<string>>(new Set());
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);

  const handleToggleSelection = (deviceId: string) => {
      setSelectedDeviceIds(prev => {
          const newSelection = new Set(prev);
          if (newSelection.has(deviceId)) {
              newSelection.delete(deviceId);
          } else {
              newSelection.add(deviceId);
          }
          return newSelection;
      });
  };

  const clearSelection = () => {
      setSelectedDeviceIds(new Set());
  };

  const handleDeploymentComplete = () => {
    setIsDeployModalOpen(false);
    clearSelection();
    fetchData(true);
  };

  const handleDelete = (e: React.MouseEvent, deviceId: string) => {
    e.stopPropagation();
    deleteDevice(deviceId);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6 border-b-2 border-bg-800 pb-2 gap-4">
        <h2 className="text-3xl font-bold text-text-100">受管设备</h2>
        {isAdmin && (
          <div className="flex items-center gap-2">
              <button
                onClick={openAddDeviceModal}
                className="flex items-center gap-2 text-sm bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-3 rounded-md transition-colors duration-200"
              >
                <PlusIcon />
                <span>添加新设备</span>
              </button>
              <button
                onClick={resetData}
                className="text-sm bg-bg-800 hover:bg-red-600/50 text-text-300 hover:text-red-300 font-medium py-2 px-3 rounded-md transition-colors duration-200"
              >
                重置数据
              </button>
          </div>
        )}
      </div>
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : devices.length === 0 ? (
          <div className="text-center py-20 bg-bg-900 rounded-lg">
              <h3 className="text-xl font-semibold text-text-100">未找到任何设备</h3>
              <p className="text-text-400 mt-2 mb-6">开始您的链踪之旅，请先添加您的第一个网络设备。</p>
              {isAdmin && (
                <button
                  onClick={openAddDeviceModal}
                  className="flex items-center gap-2 text-sm bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200 mx-auto"
                >
                  <PlusIcon />
                  <span>添加第一个设备</span>
                </button>
              )}
          </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {devices.map(device => {
            const lastBlock = blockchains[device.id]?.[blockchains[device.id].length - 1];
            const isSelected = selectedDeviceIds.has(device.id);

            return (
              <div 
                key={device.id}
                onClick={() => selectDevice(device)}
                className={`relative bg-bg-900 p-4 rounded-lg shadow-md cursor-pointer hover:bg-bg-800 transition-all duration-200 group flex flex-col justify-between border ${isSelected ? 'border-primary-500 shadow-lg shadow-primary-500/10' : 'border-bg-800 hover:border-primary-500/50'}`}
              >
                 {isAdmin && (
                    <div 
                      className="absolute top-4 left-4 z-10 h-5 w-5"
                      onClick={(e) => e.stopPropagation()}
                   >
                       <input 
                           type="checkbox"
                           checked={isSelected}
                           onChange={() => handleToggleSelection(device.id)}
                           className="h-5 w-5 rounded bg-bg-800 border-bg-600 text-primary-600 focus:ring-primary-500"
                           aria-label={`选择设备 ${device.name}`}
                       />
                   </div>
                 )}
                {isAdmin && (
                  <button
                    onClick={(e) => handleDelete(e, device.id)}
                    className="absolute top-2 right-2 p-1.5 rounded-full bg-bg-800/50 text-text-400 opacity-0 group-hover:opacity-100 hover:bg-red-500/50 hover:text-red-300 transition-all duration-200 z-10"
                    aria-label={`删除设备 ${device.name}`}
                    title={`删除设备 ${device.name}`}
                  >
                      <TrashIcon />
                  </button>
                )}
                <div className={isAdmin ? 'pl-8' : ''}>
                  <div className="flex items-center gap-4">
                    <div className="bg-bg-950 p-2 rounded-md">
                      <DeviceIcon type={device.type} />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-text-100 group-hover:text-primary-400 transition-colors">{device.name}</h3>
                      <p className="text-sm text-text-400 font-mono">{device.ipAddress}</p>
                    </div>
                  </div>
                </div>
                <div className={`mt-4 text-sm text-text-300 border-t border-bg-800 pt-3 space-y-2 ${isAdmin ? 'pl-8' : ''}`}>
                  {lastBlock ? (
                    <>
                      <p className="truncate text-text-300" title={lastBlock.data.summary}>
                        <span className="font-semibold text-text-400">最新摘要: </span>{lastBlock.data.summary}
                      </p>
                      <p className="text-xs">
                        <span className="font-semibold text-text-400">版本:</span> {lastBlock.data.version} | <span className="font-semibold text-text-400">操作员:</span> <span className="font-mono">{lastBlock.data.operator}</span>
                      </p>
                      <p className="text-xs text-text-500">
                        {new Date(lastBlock.timestamp).toLocaleString()}
                      </p>
                    </>
                  ) : (
                    <p>未找到配置历史。</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {isAdmin && selectedDeviceIds.size > 0 && (
          <BulkActionsToolbar 
              selectedCount={selectedDeviceIds.size}
              onClear={clearSelection}
              onDeploy={() => setIsDeployModalOpen(true)}
          />
      )}
      {isAdmin && (
        <AdminPanel />
      )}
      {isDeployModalOpen && (
          <BulkDeployModal 
              isOpen={isDeployModalOpen}
              onClose={() => setIsDeployModalOpen(false)}
              selectedDeviceIds={Array.from(selectedDeviceIds)}
              onDeploymentComplete={handleDeploymentComplete}
          />
      )}
    </div>
  );
};

export default Dashboard;