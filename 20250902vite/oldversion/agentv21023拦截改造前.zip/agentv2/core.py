# core.py - Core components for ChainTrace Agent
# Contains configuration loading, data handling, and Pydantic models.

import sys
import configparser
import logging
import json
import threading
import hashlib
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional, Set, TypedDict

from pydantic import BaseModel

# --- AI Integration Imports ---
try:
    import google.generativeai as genai
except ImportError:
    genai = None


# --- Basic Setup ---

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Command-line Argument Parsing ---
parser = argparse.ArgumentParser(description="ChainTrace Agent: A LAN collaboration server for network configuration tracking.")
parser.add_argument(
    '--config',
    type=Path,
    default=Path("config.ini"),
    help="Path to the configuration file (default: config.ini)"
)
# Use parse_known_args to prevent conflicts when running with uvicorn
args, _ = parser.parse_known_args()
CONFIG_FILE = args.config

# --- In-memory store for active user/device sessions (ephemeral, not persisted) ---
ACTIVE_SESSIONS: Dict[str, List[Dict[str, Any]]] = {}
sessions_lock = threading.Lock()


# --- Typed Dictionaries for more precise type hinting ---
class ComplianceReportDict(TypedDict, total=False):
    overall_status: str
    results: List[Dict[str, Any]]
    details: Optional[str]

class BlockDataDict(TypedDict):
    deviceId: str
    version: int
    operator: str
    config: str
    diff: str
    changeType: Optional[str]
    summary: str
    analysis: Any # This can be string or dict from old rollback data
    security_risks: Any # This can be string or list
    compliance_report: Optional[ComplianceReportDict]

class BlockDict(TypedDict):
    index: int
    timestamp: str
    data: BlockDataDict
    prev_hash: str
    hash: str


# --- Hashing Helper ---
def calculate_block_hash(block_data_dict: BlockDataDict, index: int, timestamp: str, prev_hash: str) -> str:
    """Calculates a deterministic SHA-256 hash for a block's content."""
    # Using separators=(',', ':') and sort_keys=True to match JavaScript's deterministic stringify
    block_content_str = (
        f"{index}{timestamp}"
        f"{json.dumps(block_data_dict, sort_keys=True, separators=(',', ':'), ensure_ascii=False)}"
        f"{prev_hash}"
    )
    return hashlib.sha256(block_content_str.encode('utf-8')).hexdigest()

# --- Configuration Loading ---
config = configparser.ConfigParser()
forbidden_commands: Set[str] = set()
try:
    if not CONFIG_FILE.exists(): raise FileNotFoundError(f"{CONFIG_FILE} not found.")
    config.read(CONFIG_FILE, encoding='utf-8');
    if not config.sections(): raise FileNotFoundError(f"{CONFIG_FILE} is empty.")
    
    # --- Gemini AI Configuration ---
    if genai:
        GEMINI_API_KEY: Optional[str] = config.get('gemini', 'api_key', fallback=None)
        if GEMINI_API_KEY and 'your_gemini_api_key' not in GEMINI_API_KEY:
            try:
                genai.configure(api_key=GEMINI_API_KEY) # type: ignore
                logging.info("Gemini API key loaded and configured successfully.")
            except Exception as e:
                logging.error(f"Failed to configure Gemini API, AI features will be disabled. Error: {e}")
                genai = None
        else:
            logging.warning("Gemini API key not found or is a placeholder in config.ini. AI features will be disabled.")
            genai = None
    else:
        logging.warning("google-generativeai library not found. AI features will be disabled. Please run 'pip install -r requirements.txt'")
    
    # --- Security Configuration ---
    if config.has_section('security'):
        commands_str: str = config.get('security', 'forbidden_commands', fallback='')
        if commands_str:
            # Normalize commands on load: lowercase, strip whitespace, and collapse internal spaces.
            raw_commands = [cmd.strip().lower() for cmd in commands_str.split(',') if cmd.strip()]
            forbidden_commands = {' '.join(cmd.split()) for cmd in raw_commands}
            logging.info(f"Loaded {len(forbidden_commands)} forbidden commands: {', '.join(sorted(list(forbidden_commands)))}")

except (configparser.Error, FileNotFoundError, UnicodeDecodeError) as e:
    logging.error(f"CRITICAL: An unexpected error occurred while reading {CONFIG_FILE}: {e}"); sys.exit(1)

# --- API Models ---
class DevicePayload(BaseModel):
    id: str
    name: str
    ipAddress: str
    type: str
    policyIds: Optional[List[str]] = []

class ConfigPayload(BaseModel): config: str
class SubmissionPayload(BaseModel): 
    operator: str
    config: str
    changeType: Optional[str] = "update"
class RollbackPayload(BaseModel):
    operator: str
    target_version: int
class AuditTriggerPayload(BaseModel): operator: str
class SessionPayload(BaseModel): username: str; sessionId: str
class User(BaseModel): id: int; username: str; password: str; role: str
class UserUpdatePayload(BaseModel): 
    username: str
    role: str
    password: Optional[str] = None
    extra_permissions: Optional[str] = None
class ConfigTemplate(BaseModel): id: str; name: str; content: str
class BulkDeployPayload(BaseModel): template_id: str; device_ids: List[str]
class Policy(BaseModel): id: str; name: str; severity: str; description: str; rule: str; enabled: bool
class AISettingsPayload(BaseModel): 
    is_ai_analysis_enabled: bool
    auto_audit_ai_analysis_mode: Optional[str] = None