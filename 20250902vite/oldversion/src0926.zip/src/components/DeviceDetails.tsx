import React, { useState, useEffect, useRef } from 'react';
import { Device, Block, SessionUser } from '../types';
import HistoryItem from './HistoryItem';
import BlockDetailsModal from './BlockDetailsModal';
import VerificationModal, { VerificationResult } from './VerificationModal';
import Loader from './Loader';
import { verifyChain } from '../utils/crypto';
import { toast } from 'react-hot-toast';
import { PlusIcon, SparklesIcon, BrainIcon, DocumentDuplicateIcon, XCircleSolid, CheckCircleSolid } from './AIIcons';
import { geminiService } from '../services/geminiService';
import { joinDeviceSessionAPI, leaveDeviceSessionAPI, getActiveSessionsAPI } from '../utils/session';
import { createApiUrl } from '../utils/apiUtils';
import { getAIFailureMessage } from '../utils/errorUtils';
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import { useStore } from '../store/useStore';


interface DeviceDetailsProps {
  sessionId: string;
}

const ShieldCheckIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
);

const CollaborationWarning: React.FC<{ users: SessionUser[] }> = ({ users }) => {
    if (users.length === 0) return null;
    const userNames = users.map(u => u.username).join(', ');
    return (
        <div className="bg-yellow-900/50 border border-yellow-700/50 text-yellow-300 p-3 rounded-md mb-4 text-sm flex items-center gap-3">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
            <span>注意: 用户 <strong className="font-bold text-yellow-200">{userNames}</strong> 也正在查看此设备。</span>
        </div>
    );
};

type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'failed';

const StatusIndicator: React.FC<{ status: ConnectionStatus }> = ({ status }) => {
    const statusMap = {
        disconnected: { text: '未连接', color: 'bg-bg-500', icon: null },
        connecting: { text: '正在连接...', color: 'bg-yellow-500', icon: <Loader /> },
        connected: { text: '已连接', color: 'bg-emerald-500', icon: <CheckCircleSolid className="h-4 w-4 text-emerald-300" /> },
        failed: { text: '连接失败', color: 'bg-red-500', icon: <XCircleSolid className="h-4 w-4 text-red-300" /> },
    };
    const { text, color, icon } = statusMap[status];

    return (
        <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${color}`}></div>
            <span className="text-sm text-text-300">{text}</span>
            {icon}
        </div>
    );
};

const DeviceDetails: React.FC<DeviceDetailsProps> = ({ sessionId }) => {
  const { 
    device, allDevices, chain, settings, currentUser, agentMode, 
    selectDevice, openAddDeviceModal, isLoading, fetchData, promptRollback 
  } = useStore(state => ({
    device: state.selectedDevice!,
    allDevices: state.devices,
    chain: state.blockchains[state.selectedDevice?.id || ''] || [],
    settings: state.settings,
    currentUser: state.currentUser!,
    agentMode: state.agentMode,
    selectDevice: state.selectDevice,
    openAddDeviceModal: state.openAddDeviceModal,
    isLoading: state.isLoading,
    fetchData: state.fetchData,
    promptRollback: state.promptRollback
  }));

  const [selectedBlockInfo, setSelectedBlockInfo] = useState<{ block: Block; prevConfig: string } | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [verificationResults, setVerificationResults] = useState<VerificationResult[]>([]);
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [otherViewingUsers, setOtherViewingUsers] = useState<SessionUser[]>([]);
  
  const [isSaving, setIsSaving] = useState(false);
  const terminalRef = useRef<HTMLDivElement>(null);
  const xtermRef = useRef<Terminal | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const fitAddonRef = useRef<FitAddon | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [fontSize, setFontSize] = useState(16);

  const xtermTheme = {
      background: 'rgb(var(--color-bg-950))',
      foreground: 'rgb(var(--color-text-300))',
      cursor: 'rgb(var(--color-text-100))',
      selectionBackground: 'rgb(var(--color-primary-700))',
      selectionForeground: 'rgb(var(--color-text-100))',
  };

  // Initialize Terminal UI
  useEffect(() => {
    if (terminalRef.current && !xtermRef.current) {
        const term = new Terminal({
            cursorBlink: true,
            theme: xtermTheme,
            fontFamily: 'Menlo, Monaco, "Courier New", monospace',
            fontSize: fontSize,
            rows: 30,
            convertEol: true, // FIX: Normalize line endings to prevent "staircase effect".
        });
        const fitAddon = new FitAddon();
        fitAddonRef.current = fitAddon;
        term.loadAddon(fitAddon);
        term.open(terminalRef.current);
        fitAddon.fit();
        term.write('\x1b[33m--- 控制台已就绪，请点击“连接”按钮以启动会话 ---\x1b[0m\r\n');
        xtermRef.current = term;

        const resizeObserver = new ResizeObserver(() => {
            fitAddon.fit();
        });
        resizeObserver.observe(terminalRef.current);
        
        return () => resizeObserver.disconnect();
    }
  }, []);

  useEffect(() => {
    if (xtermRef.current) {
        xtermRef.current.options.fontSize = fontSize;
        fitAddonRef.current?.fit();
    }
  }, [fontSize]);

  // Effect to clean up WebSocket on component unmount or device change
  useEffect(() => {
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
    };
  }, [device.id]);
  
  const handleConnect = () => {
    const term = xtermRef.current;
    if (!term || !settings.agentApiUrl || !device.id || !sessionId) return;
    
    if (socketRef.current) socketRef.current.close();

    term.reset();

    if (agentMode === 'simulation') {
        term.write('\x1b[33m--- 模拟模式，交互式控制台已禁用 ---\x1b[0m\r\n');
        return;
    }

    setConnectionStatus('connecting');
    term.write(`\x1b[33m正在连接到 ${device.name} (${device.id})...\x1b[0m\r\n`);

    const wsUrl = new URL(createApiUrl(settings.agentApiUrl, `/ws/${device.id}/${sessionId}`));
    wsUrl.protocol = wsUrl.protocol.replace('http', 'ws');

    const socket = new WebSocket(wsUrl.toString());
    socketRef.current = socket;
    let isConnectionEstablished = false;

    socket.onmessage = (event) => {
        if (!isConnectionEstablished) {
            setConnectionStatus('connected');
            isConnectionEstablished = true;
            term.focus();
        }
        term.write(event.data);
    };

    socket.onerror = (error) => {
        console.error('WebSocket Error:', error);
        if (!isConnectionEstablished) {
            setConnectionStatus('failed');
        }
    };
    
    socket.onclose = () => {
      if (!isConnectionEstablished) {
          setConnectionStatus('failed');
      } else {
          setConnectionStatus('disconnected');
          term.write('\r\n\x1b[33m--- 连接已断开 ---\x1b[0m\r\n');
      }
    };
  };
  
  const handleDisconnect = () => {
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }
  };
  
  // Terminal data listener setup
  useEffect(() => {
    const term = xtermRef.current;
    if (!term) return;

    const dataListener = term.onData((data: string) => {
        if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
            socketRef.current.send(data);
        }
    });

    return () => dataListener.dispose();
  }, [connectionStatus]); // Re-attach listener if connection status changes


  // Handle session tracking
  useEffect(() => {
    if (!settings.agentApiUrl) { setOtherViewingUsers([]); return; }
    joinDeviceSessionAPI(device.id, currentUser.username, sessionId, settings.agentApiUrl);
    const intervalId = setInterval(async () => {
        joinDeviceSessionAPI(device.id, currentUser.username, sessionId, settings.agentApiUrl);
        const viewers = await getActiveSessionsAPI(device.id, settings.agentApiUrl!);
        setOtherViewingUsers(viewers.filter(u => u.sessionId !== sessionId));
    }, 3000);
    return () => {
      clearInterval(intervalId);
      leaveDeviceSessionAPI(device.id, sessionId, settings.agentApiUrl!);
    };
  }, [device.id, currentUser.username, sessionId, settings.agentApiUrl]);

  const handleSelectBlock = (block: Block) => {
    const prevBlock = chain.find(b => b.index === block.index - 1);
    const prevConfig = prevBlock ? prevBlock.data.config : '';
    setSelectedBlockInfo({ block, prevConfig });
  };
  
  const handleSaveSession = async () => {
    if (agentMode === 'simulation') {
        toast.error('模拟模式下无法保存会话。');
        return;
    }
    setIsSaving(true);
    const toastId = toast.loading('正在保存并审计会话...');
    try {
        const url = createApiUrl(settings.agentApiUrl!, `/api/sessions/${device.id}/save`);
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ operator: currentUser.username }),
        });

        if (!response.ok) {
            let errorMessage = '代理返回了未知错误。';
            try {
                const errorData = await response.json();
                if (errorData.detail) {
                    if (typeof errorData.detail === 'string') {
                        errorMessage = errorData.detail;
                    } else if (Array.isArray(errorData.detail) && errorData.detail.length > 0) {
                        // Handle FastAPI validation errors
                        const firstError = errorData.detail[0];
                        const fieldPath = firstError.loc ? firstError.loc.slice(1).join(' -> ') : '未知字段';
                        errorMessage = `${firstError.msg} (字段: ${fieldPath})`;
                    } else {
                        errorMessage = JSON.stringify(errorData.detail);
                    }
                }
            } catch (e) {
                errorMessage = `代理返回了非JSON格式的错误响应 (${response.status} ${response.statusText})。`;
            }
            throw new Error(errorMessage);
        }

        await response.json();
        toast.success('会话已成功审计并记录!', { id: toastId });
        fetchData(true);
    } catch (error) {
        const errorMessage = getAIFailureMessage(error);
        toast.error(`保存失败: ${errorMessage}`, { id: toastId, duration: 6000 });
    } finally {
        setIsSaving(false);
    }
  };

  const handleVerifyChain = async () => {
    setIsVerifying(true); setIsVerificationModalOpen(true);
    setVerificationResults(chain.map(block => ({ index: block.index, status: 'pending' })));
    await new Promise(resolve => setTimeout(resolve, 100));
    await verifyChain(chain, (index, status, details) => {
      setVerificationResults(prev => {
        const newResults = [...prev];
        const resultIndex = newResults.findIndex(r => r.index === index);
        if (resultIndex > -1) { newResults[resultIndex] = { ...newResults[resultIndex], status, details }; }
        return newResults;
      });
    });
    setIsVerifying(false);
  };
  
  const handleGenerateConfig = async () => {
      if (!aiPrompt.trim()) { toast.error('请输入您的配置意图。'); return; }
      setIsGenerating(true);
      const toastId = toast.loading('AI 助手正在生成命令...');
      try {
          const lastConfig = chain.length > 0 ? chain[chain.length-1].data.config : `hostname ${device.name}`;
          const generatedCommands = await geminiService.generateConfigFromPrompt(aiPrompt, device, lastConfig);
          if (generatedCommands) {
              navigator.clipboard.writeText(generatedCommands);
              toast.success('AI 命令已生成并复制到剪贴板！请在终端中粘贴。', { id: toastId });
              setAiPrompt('');
          } else {
              toast.error('AI 未能生成命令，请检查您的输入或稍后再试。', { id: toastId });
          }
      } catch (error) {
          const errorMessage = getAIFailureMessage(error);
          toast.error(`生成失败: ${errorMessage}`, { id: toastId });
      } finally { setIsGenerating(false); }
  };
  
  const sortedChain = [...chain].sort((a, b) => b.index - a.index);
  
  return (
    <div>
       <button onClick={() => selectDevice(null)} className="flex items-center gap-2 mb-6 text-primary-400 hover:text-primary-300 transition-colors">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
        返回仪表盘
      </button>

      <div className="flex flex-col gap-8">
        <div className="bg-bg-900 p-6 rounded-lg shadow-xl flex flex-col">
          <CollaborationWarning users={otherViewingUsers} />
          <h3 className="text-2xl font-bold text-text-100 mb-2">交互式控制台</h3>
          <p className="text-text-400 mb-4 text-sm">操作员: <span className="font-mono text-primary-400">{currentUser.username}</span>。会话结束后，所有成功执行的命令将被审计并记录。</p>
          
           <div className="flex-grow flex flex-col bg-bg-950 border border-bg-700 rounded-md p-2 min-h-[500px]">
                 <div className="flex-shrink-0 flex justify-between items-center p-1 mb-2 border-b border-bg-700/50">
                    <StatusIndicator status={connectionStatus} />
                     <div className="flex items-center gap-2">
                        <span className="text-xs text-text-400">字体大小:</span>
                        <button onClick={() => setFontSize(s => Math.max(10, s - 1))} className="w-6 h-6 bg-bg-700 rounded text-text-200 hover:bg-bg-600 transition-colors" aria-label="减小字体大小">-</button>
                        <span className="text-sm font-mono text-text-200 w-6 text-center">{fontSize}</span>
                        <button onClick={() => setFontSize(s => s + 1)} className="w-6 h-6 bg-bg-700 rounded text-text-200 hover:bg-bg-600 transition-colors" aria-label="增大字体大小">+</button>
                    </div>
                    {connectionStatus === 'connected' ? (
                        <button onClick={handleDisconnect} className="bg-red-600 hover:bg-red-700 text-white font-bold py-1 px-3 rounded-md text-sm transition-colors">断开</button>
                    ) : (
                        <button onClick={handleConnect} disabled={connectionStatus === 'connecting'} className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-bg-600 text-white font-bold py-1 px-3 rounded-md text-sm transition-colors">连接</button>
                    )}
                </div>
                <div ref={terminalRef} className="w-full h-full flex-grow" />
           </div>
            
          {settings.ai.commandGeneration.enabled && (
                <div className="mt-4 bg-bg-950/50 p-3 rounded-md">
                    <label htmlFor="ai-prompt" className="flex items-center gap-2 text-sm font-medium text-text-300 mb-2"><SparklesIcon className="h-5 w-5 text-primary-400" /><span>AI 助手</span></label>
                    <div className="flex items-center gap-2">
                        <input type="text" id="ai-prompt" value={aiPrompt} onChange={(e) => setAiPrompt(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleGenerateConfig(); }}}
                            className="flex-grow bg-bg-800 border border-bg-700 rounded-md p-2 text-text-200 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 text-sm" placeholder="例如：为 VLAN 10 添加端口 G0/1" disabled={isGenerating || agentMode === 'simulation'}/>
                        <button type="button" onClick={handleGenerateConfig} disabled={isGenerating || agentMode === 'simulation'} className="flex-shrink-0 flex items-center justify-center gap-2 w-32 bg-bg-800 hover:bg-primary-600/50 text-text-100 font-bold py-2 px-3 rounded-md transition-colors text-sm disabled:opacity-50 disabled:cursor-wait">
                           {isGenerating ? <Loader/> : <><DocumentDuplicateIcon className="h-4 w-4" /><span>生成并复制</span></>}
                        </button>
                    </div>
                </div>
          )}

          <div className="mt-auto pt-4">
              <button onClick={handleSaveSession} disabled={agentMode === 'simulation' || isSaving} className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-bg-600 text-white font-bold py-3 px-4 rounded-md transition-colors flex justify-center items-center gap-2">
                  {isSaving ? <Loader /> : <BrainIcon />}
                  保存会话并审计
              </button>
          </div>
        </div>

        <div className="bg-bg-900 p-6 rounded-lg shadow-xl">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-2xl font-bold text-text-100">配置历史</h3>
            <button onClick={handleVerifyChain} disabled={isVerifying || isLoading} className="flex items-center gap-2 bg-bg-800 hover:bg-bg-700 disabled:bg-bg-950 disabled:text-text-500 disabled:cursor-not-allowed text-text-100 font-bold py-2 px-3 rounded-md transition-colors text-sm">
              {isVerifying ? <Loader/> : <ShieldCheckIcon/>} <span>验证完整性</span>
            </button>
          </div>
          <div className="mb-6">
            <label htmlFor="device-switcher" className="block text-sm font-medium text-text-400 mb-1">当前设备</label>
             <div className="flex items-center gap-2">
                <select id="device-switcher" value={device.id} onChange={(e) => { const newDevice = allDevices.find(d => d.id === e.target.value); if (newDevice) selectDevice(newDevice); }}
                    className="flex-grow bg-bg-800 border border-bg-700 rounded-md p-2 text-text-100 font-mono focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
                    {allDevices.map(d => (<option key={d.id} value={d.id}>{d.name} ({d.id})</option>))}
                </select>
                {currentUser.role === 'admin' && (
                  <button onClick={openAddDeviceModal} className="flex-shrink-0 bg-bg-800 hover:bg-primary-600/50 text-text-300 hover:text-primary-300 font-medium p-2 rounded-md transition-colors" aria-label="添加新设备" title="添加新设备"><PlusIcon /></button>
                )}
            </div>
          </div>
          <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
            {sortedChain.map((block, index) => (
              <HistoryItem key={block.hash} block={block} isLatest={index === 0} onSelectBlock={() => handleSelectBlock(block)} onRollback={() => promptRollback(block)} />
            ))}
            {sortedChain.length === 0 && (<div className="text-center py-8 text-text-500"><p>未找到该设备的历史配置。</p></div>)}
          </div>
        </div>
      </div>

      {selectedBlockInfo && <BlockDetailsModal block={selectedBlockInfo.block} prevConfig={selectedBlockInfo.prevConfig} onClose={() => setSelectedBlockInfo(null)} />}
      {isVerificationModalOpen && <VerificationModal results={verificationResults} chain={chain} onClose={() => setIsVerificationModalOpen(false)} isVerifying={isVerifying}/>}
    </div>
  );
};
export default DeviceDetails;