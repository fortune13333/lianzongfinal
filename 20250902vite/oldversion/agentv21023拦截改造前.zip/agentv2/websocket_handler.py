# websocket_handler.py - WebSocket handling for ChainTrace Agent's interactive console

import logging
import asyncio
import re
import threading
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from fastapi.websockets import WebSocketState
from netmiko import ConnectHandler # type: ignore
from netmiko.exceptions import NetmikoAuthenticationException, NetmikoBaseException # type: ignore
from netmiko.cisco_base_connection import CiscoBaseConnection # type: ignore
from typing import Optional, TypedDict, Dict, List

from sqlalchemy.orm import Session

# Import from our own refactored modules
import crud
import models
from core import forbidden_commands
from services import get_device_info, perform_auto_audit # type: ignore
from database import SessionLocal, get_db

# --- New In-memory "Dirty" Session Tracking ---
# This store will track which sessions have had potential config changes.
class SessionState(TypedDict):
    device_id: str
    is_dirty: bool

ACTIVE_WEB_SESSIONS: Dict[str, SessionState] = {}
sessions_lock = threading.Lock()
READ_ONLY_COMMANDS = ('show', 'display', 'dir', 'ping', 'traceroute')


# Type definition for device information
class DeviceInfo(TypedDict, total=False):
    host: str
    device_type: str
    username: str
    password: str
    secret: Optional[str]
    timeout: int

router = APIRouter()

def is_command_violating_policies(command: str, policies: List[models.Policy]) -> Optional[str]:
    """
    Checks a command against a list of policies using keyword matching.
    Returns the name of the violated policy if a violation is found, otherwise None.
    """
    for policy in policies:
        if not policy.enabled:
            continue
        
        # Simple keyword extraction from the rule (e.g., from "禁止使用 telnet", extract "telnet")
        # This is a heuristic and can be improved with more advanced parsing.
        # We'll look for simple keywords like 'telnet', 'snmp-server community', etc.
        rule_lower = policy.rule.lower()
        
        # A simple heuristic: find a likely command keyword in the rule.
        # This is a basic implementation and can be made more sophisticated.
        keywords_to_check: List[str] = []
        if 'telnet' in rule_lower: keywords_to_check.append('telnet')
        if 'snmp' in rule_lower: keywords_to_check.append('snmp-server community')
        if 'http server' in rule_lower: keywords_to_check.append('ip http server')
        
        # Regex to find quoted text, e.g. "transport input telnet"
        quoted_phrases = re.findall(r'[\'"](.+?)[\'"]', rule_lower)
        keywords_to_check.extend(quoted_phrases)

        if not keywords_to_check: # If no obvious keyword, do a simple contains check
            keywords_to_check.append(policy.rule.lower())

        for keyword in keywords_to_check:
            if keyword.strip() and keyword.strip() in command:
                logging.warning(f"Command '{command}' violates policy '{policy.name}' due to keyword '{keyword.strip()}'.")
                return policy.name # Return the name of the first violated policy
    
    return None

async def unified_io_handler(websocket: WebSocket, net_connect: CiscoBaseConnection, actor_username: str, session_id: str, device_id: str, db: Session) -> None:
    """
    A unified I/O handler that now performs real-time policy checks on command entry.
    """
    line_buffer: str = ""
    loop = asyncio.get_running_loop()

    ws_reader: asyncio.Task[str] = asyncio.create_task(websocket.receive_text())
    device_reader: "asyncio.Future[str]" = loop.run_in_executor(None, net_connect.read_channel)

    try:
        # Fetch device policies once at the beginning of the session for efficiency
        device_with_policies = crud.get_device_with_details(db, device_id)
        active_policies = device_with_policies.policies if device_with_policies else []

        while True:
            done, _ = await asyncio.wait([ws_reader, device_reader], return_when=asyncio.FIRST_COMPLETED)

            # --- Handle output from the device ---
            if device_reader in done:
                device_output: str = device_reader.result()
                if device_output: await websocket.send_text(device_output)
                device_reader = loop.run_in_executor(None, net_connect.read_channel)

            # --- Handle input from the user ---
            if ws_reader in done:
                user_input: str = ws_reader.result()
                is_enter_key = '\r' in user_input or '\n' in user_input

                if is_enter_key:
                    command_to_check = line_buffer.strip().lower()
                    normalized_command = ' '.join(command_to_check.split())
                    
                    logging.info(f"Intercept check: User='{actor_username}', Buffer='{line_buffer.strip()}', Normalized='{normalized_command}'")

                    if normalized_command and not normalized_command.startswith(READ_ONLY_COMMANDS):
                        with sessions_lock:
                            if session_id in ACTIVE_WEB_SESSIONS and not ACTIVE_WEB_SESSIONS[session_id]['is_dirty']:
                                ACTIVE_WEB_SESSIONS[session_id]['is_dirty'] = True
                                logging.info(f"Session {session_id} for device {device_id} marked as DIRTY.")
                    
                    # --- Real-time Policy Interception (Plan A) ---
                    violated_policy_name: Optional[str] = None
                    is_forbidden_by_blacklist = False
                    
                    if normalized_command:
                        # 1. Check static blacklist from config.ini first (fastest)
                        if any(cmd.startswith(normalized_command) for cmd in forbidden_commands):
                            is_forbidden_by_blacklist = True
                            violated_policy_name = "a system security rule (e.g., write memory)"
                        
                        # 2. If not blacklisted, check dynamic policies from DB
                        if not is_forbidden_by_blacklist:
                            violated_policy_name = is_command_violating_policies(normalized_command, active_policies)

                    if violated_policy_name:
                        logging.warning(f"User '{actor_username}' attempted forbidden command: '{line_buffer.strip()}' which violates policy: '{violated_policy_name}'")
                        error_msg = (
                            f"\r\n\x1b[31m[ChainTrace Policy Violation] Error: The command '{line_buffer.strip()}' "
                            f"violates policy: \"{violated_policy_name}\".\r\nCommand has been blocked.\x1b[0m\r\n"
                        )
                        await websocket.send_text(error_msg)
                        
                        clear_line_signal = '\x15' # CTRL+U (Kill Line)
                        await loop.run_in_executor(None, net_connect.write_channel, clear_line_signal + '\n')
                    else:
                        await loop.run_in_executor(None, net_connect.write_channel, '\n')
                    
                    line_buffer = ""
                
                elif user_input == '\x7f': # Backspace
                    if line_buffer: line_buffer = line_buffer[:-1]
                    await loop.run_in_executor(None, net_connect.write_channel, '\x7f')
                
                else: # Other characters
                    line_buffer += user_input
                    await loop.run_in_executor(None, net_connect.write_channel, user_input)

                ws_reader = asyncio.create_task(websocket.receive_text())

    except WebSocketDisconnect:
        logging.info(f"WebSocket disconnected for user {actor_username}.")
    except Exception as e:
        logging.error(f"Error in unified_io_handler for user {actor_username}: {e}")
    finally:
        if not ws_reader.done(): ws_reader.cancel()
        if not device_reader.done(): device_reader.cancel()


@router.websocket("/ws/{device_id}/{session_id}")
async def websocket_endpoint(websocket: WebSocket, device_id: str, session_id: str, db: Session = Depends(get_db)) -> None:
    actor_username = websocket.query_params.get("username", "unknown_ws_user")
    
    await websocket.accept()

    # --- Register Session ---
    with sessions_lock:
        ACTIVE_WEB_SESSIONS[session_id] = {'device_id': device_id, 'is_dirty': False}
        logging.info(f"WebSocket session {session_id} registered for device {device_id}.")

    device_info: Optional[DeviceInfo] = get_device_info(device_id)  # type: ignore
    if not device_info:
        await websocket.close(code=1008, reason="在配置文件中未找到设备ID。")
        return
        
    net_connect: Optional[CiscoBaseConnection] = None
    try:
        await websocket.send_text("[1/3] 正在建立SSH连接...\r\n")
        loop = asyncio.get_running_loop()
        
        net_connect = await loop.run_in_executor(None, lambda: ConnectHandler(**device_info)) # type: ignore
        
        await websocket.send_text("[2/3] 连接成功, 正在进入特权模式...\r\n")
        if net_connect: await loop.run_in_executor(None, net_connect.enable)
        await websocket.send_text("[3/3] 特权模式已进入, 正在等待设备响应 (最长5秒)...\r\n")
        
        prompt = ""
        if net_connect: prompt = await loop.run_in_executor(None, lambda: net_connect.find_prompt(delay_factor=2))
        await websocket.send_text(f"\r\n{prompt}")

        if net_connect:
            await unified_io_handler(websocket, net_connect, actor_username, session_id, device_id, db)

    except NetmikoBaseException as e:
        error_type = "认证失败" if isinstance(e, NetmikoAuthenticationException) else "连接超时或错误"
        logging.error(f"WS connection failed for {device_id}: {error_type}: {e}")
        await websocket.send_text(f"\r\n--- 连接失败 ---\r\n原因: {error_type}: {e}\r\n")
    except Exception as e:
        logging.error(f"An unexpected WebSocket error occurred for device {device_id}: {e}")
        await websocket.send_text(f"\r\n--- 连接失败 ---\r\n原因: 未知连接错误: {e}\r\n")
    finally:
        # --- Auto-Audit on Disconnect Logic ---
        session_state = None
        with sessions_lock:
            if session_id in ACTIVE_WEB_SESSIONS:
                session_state = ACTIVE_WEB_SESSIONS.pop(session_id)
        
        if session_state and session_state['is_dirty']:
            logging.warning(f"DIRTY session {session_id} for device {device_id} disconnected. Triggering auto-audit.")
            # Use a task to run the audit in the background without blocking the disconnect.
            # We must create a new DB session for this background task.
            async def audit_task():
                db_session = SessionLocal()
                try:
                    await perform_auto_audit(db_session, device_id)
                finally:
                    db_session.close()
            asyncio.create_task(audit_task())

        if net_connect and net_connect.is_alive():
            net_connect.disconnect()
        if websocket.client_state != WebSocketState.DISCONNECTED:
            await websocket.close()
        logging.info(f"WebSocket connection closed for device {device_id}, session {session_id}")