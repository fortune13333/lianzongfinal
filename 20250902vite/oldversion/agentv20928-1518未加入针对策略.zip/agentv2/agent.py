# agent.py - Main entry point for the ChainTrace Agent server.
# This file initializes the FastAPI application and includes the routers.

import sys
import uvicorn
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Import from our own refactored modules
from core import config, CONFIG_FILE
from api_routes import router as api_router
from websocket_handler import router as websocket_router

# New database imports
from database import init_db, SessionLocal
import crud


# --- FastAPI App Initialization ---
# Version updated to reflect the major architectural refactoring.
app = FastAPI(title="ChainTrace Local Agent", version="8.0.0-database")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# --- Include Routers ---
app.include_router(api_router)
app.include_router(websocket_router)

# --- Main Execution ---
if __name__ == "__main__":
    # Initialize the database and create tables if they don't exist.
    init_db()
    # Use a database session to seed initial data if the DB is empty.
    with SessionLocal() as db:
        crud.seed_initial_data(db)
    
    try:
        host: str = config.get('server', 'host', fallback='127.0.0.1')
        port: int = config.getint('server', 'port', fallback=8000)
    except Exception as e: # Catch any config parser error here
        logging.critical(f"CRITICAL: Failed to read [server] configuration from {CONFIG_FILE}. Error: {e}")
        logging.critical("Please ensure the [server] section exists and the 'port' is a valid integer.")
        sys.exit(1)
    
    logging.info(f"Starting ChainTrace Agent server at http://{host}:{port} using config {CONFIG_FILE}")
    # Note: --reload is not used here for production startup. 
    # For development, run uvicorn from the command line: uvicorn agent:app --reload
    uvicorn.run("agent:app", host=host, port=port, reload=False)