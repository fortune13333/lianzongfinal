export interface Device {
  id: string;
  name: string;
  ipAddress: string;
  type: 'Router' | 'Switch' | 'Firewall';
  netmiko_device_type?: string;
}

export interface ComplianceReport {
  overall_status: 'passed' | 'failed';
  results: {
    policy_id: string;
    policy_name: string;
    status: 'passed' | 'failed';
    details: string;
  }[];
}


export interface BlockData {
  deviceId: string;
  version: number;
  operator: string;
  config: string;
  diff: string;
  changeType: 'initial' | 'update' | 'rollback';
  summary: string;
  analysis: any; // Can be string or object for old rollback data
  security_risks: string;
  compliance_report?: ComplianceReport;
}

export interface Block {
  index: number;
  timestamp: string;
  data: BlockData;
  prev_hash: string;
  hash: string;
}

export interface AIServiceSettings {
  enabled: boolean;
  apiUrl: string;
}

export interface AppSettings {
  ai: {
    analysis: {
      apiUrl: string;
    };
    commandGeneration: AIServiceSettings;
    configCheck: AIServiceSettings;
  };
  agentApiUrl: string;
  theme: string;
  bgTheme: string;
  agentUrlHistory: string[];
}

export interface BackendSettings {
  is_ai_analysis_enabled: boolean;
}

export interface User {
  id: number;
  username: string;
  password?: string; // Password should be optional on the frontend
  role: 'admin' | 'operator';
}

export interface SessionUser {
  username: string;
  sessionId: string;
}

export interface AuditLogEntry {
  timestamp: string;
  username: string;
  action: string;
}

export interface ConfigTemplate {
  id: string;
  name: string;
  content: string;
}

export interface Policy {
  id: string;
  name: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  description: string;
  rule: string;
  enabled: boolean;
}

export interface DeploymentResult {
  device_id: string;
  device_name: string;
  status: 'success' | 'failure';
  message: string;
}

export interface DeploymentRecord {
  id: string;
  timestamp: string;
  operator: string;
  template_name: string;
  status: 'Completed' | 'Completed with Errors';
  summary: string;
  target_devices: string[];
  results: DeploymentResult[];
}
