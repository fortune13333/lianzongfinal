# models.txt - SQLAlchemy ORM models for all database tables.

from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from database import Base

class Device(Base):
    __tablename__ = "devices"
    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    ipAddress = Column(String, nullable=False)
    type = Column(String, nullable=False)
    blocks = relationship("Block", back_populates="device", cascade="all, delete-orphan", lazy="joined")

class Block(Base):
    __tablename__ = "blocks"
    id = Column(Integer, primary_key=True, autoincrement=True)
    device_id = Column(String, ForeignKey("devices.id"), nullable=False)
    index = Column(Integer, nullable=False)
    timestamp = Column(String, nullable=False)
    # Store complex block data as a JSON string in a Text column
    data = Column(Text, nullable=False) 
    prev_hash = Column(String, nullable=False)
    hash = Column(String, nullable=False, index=True, unique=True)
    
    device = relationship("Device", back_populates="blocks")

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String, unique=True, index=True, nullable=False)
    password = Column(String, nullable=False)
    role = Column(String, nullable=False)
    
class AuditLog(Base):
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True, autoincrement=True)
    # Use server_default for UTC timestamp generation by the database itself
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    username = Column(String, nullable=False)
    action = Column(String, nullable=False)
    
class ConfigTemplate(Base):
    __tablename__ = "templates"
    id = Column(String, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    content = Column(Text, nullable=False)
    
class Policy(Base):
    __tablename__ = "policies"
    id = Column(String, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    severity = Column(String, nullable=False)
    description = Column(String, nullable=False)
    rule = Column(Text, nullable=False)
    enabled = Column(Boolean, default=True, nullable=False)

class Setting(Base):
    __tablename__ = "settings"
    key = Column(String, primary_key=True)
    value = Column(String, nullable=False)
