# services.py - Business logic layer for the ChainTrace Agent.
# This file sits between the API routes and the database CRUD operations.

import logging
import json
import asyncio
import importlib
from datetime import datetime, timezone
from typing import Dict, Any, Optional, cast

from sqlalchemy.orm import Session
from netmiko import ConnectHandler, NetmikoBaseException
from netmiko.exceptions import NetmikoAuthenticationException
from fastapi import HTTPException

import crud
from core import (
    calculate_block_hash, 
    config as app_config,
    SubmissionPayload, 
    RollbackPayload, 
    BlockDict, 
    BlockDataDict, 
    ComplianceReportDict
)

# --- AI Driver Dynamic Loading ---
ai_driver_module = None
driver_name = "unknown" # Pre-define to prevent UnboundLocalError in exception logging
try:
    driver_name = app_config.get('ai_provider', 'driver', fallback='gemini')
    ai_driver_module = importlib.import_module(f"ai_drivers.{driver_name}_driver")
    logging.info(f"AI driver '{driver_name}' loaded successfully.")
except ImportError:
    logging.error(f"Failed to load AI driver '{driver_name}'. AI-related features will be disabled.")
    ai_driver_module = None # Ensure it's None on failure
except Exception as e:
    logging.error(f"An unexpected error occurred while loading the AI driver '{driver_name}': {e}")
    ai_driver_module = None # Ensure it's None on failure


# --- Simulation & Device Utilities ---
def is_simulation_mode() -> bool:
    if not app_config: return False
    for section in app_config.sections():
        if section.lower().startswith('credentials') and app_config.get(section, 'username', fallback='').upper() == 'SIM_USER':
            logging.info("Simulation mode is ACTIVE because SIM_USER was found.")
            return True
    return False

def get_device_info(device_id: str) -> Optional[Dict[str, Any]]:
    """
    Retrieves connection information for a device from the config.ini file.
    """
    device_id_upper = device_id.upper()
    if not app_config.has_section('device_map') or not app_config.has_option('device_map', device_id_upper):
        logging.error(f"Device ID '{device_id}' not found in [device_map] of config.ini")
        return None
    
    try:
        ip_address, device_type, creds_section = [part.strip() for part in app_config.get('device_map', device_id_upper).split(',', 2)]
        
        if not app_config.has_section(creds_section):
            logging.error(f"Credentials section '[{creds_section}]' for device '{device_id}' not found in config.ini")
            return None
            
        creds = dict(app_config.items(creds_section))
        
        device_info: Dict[str, Any] = {
            'device_type': device_type,
            'host': ip_address,
            'username': creds.get('username'),
            'password': creds.get('password'),
            'secret': creds.get('secret'), # Will be None if not present, which is fine
            'timeout': 60, # A generous timeout
        }
        return device_info
    except Exception as e:
        logging.error(f"Failed to parse device info for '{device_id}' from config.ini: {e}")
        return None

def get_running_config(device_id: str) -> Dict[str, str]:
    """
    Connects to a device and retrieves its running configuration.
    """
    device_info = get_device_info(device_id)
    if not device_info:
        raise HTTPException(status_code=404, detail=f"在配置文件中未找到设备 ID '{device_id}'。")

    try:
        with ConnectHandler(**device_info) as net_connect:
            net_connect.enable()
            output = net_connect.send_command("show running-config", read_timeout=120)
            if not isinstance(output, str):
                raise TypeError("The 'show running-config' command did not return a string as expected.")
        return {"config": output}
    except NetmikoAuthenticationException as e:
        logging.error(f"Authentication failed for {device_id}: {e}")
        raise HTTPException(status_code=401, detail=f"设备 '{device_id}' 认证失败。请检查 config.ini 中的凭据。")
    except NetmikoBaseException as e:
        logging.error(f"Netmiko connection error for {device_id}: {e}")
        raise HTTPException(status_code=504, detail=f"连接设备 '{device_id}' 失败: {e}")
    except Exception as e:
        logging.error(f"Unexpected error getting running-config for {device_id}: {e}")
        raise HTTPException(status_code=500, detail=f"获取设备配置时发生意外错误: {e}")


# --- Blockchain Services ---
def perform_add_block(db: Session, device_id: str, payload: SubmissionPayload, skip_compliance_check: bool = False) -> BlockDict:
    device = crud.get_device_with_details(db, device_id)
    if not device:
        raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}' 的区块链。")
    
    # Sort blocks by index to be certain the last one is correct
    sorted_blocks = sorted(device.blocks, key=lambda b: b.index)
    last_block = sorted_blocks[-1] if sorted_blocks else None
    previous_config = json.loads(last_block.data).get('config', '') if last_block else ''
    
    policies_for_audit = device.policies
    settings = crud.get_settings_as_dict(db)
    compliance_report: Optional[ComplianceReportDict] = None
    analysis_results: Dict[str, Any] = {"diff": "N/A", "summary": "N/A", "analysis": "N/A", "security_risks": "N/A"}

    is_ai_enabled = settings.get("is_ai_analysis_enabled", True) and ai_driver_module is not None

    if is_ai_enabled:
        try:
            analysis_context = ""
            if payload.changeType == 'auto_audit':
                ai_mode = settings.get('auto_audit_ai_analysis_mode', 'best_effort')
                if ai_mode == 'best_effort':
                    analysis_context = "auto-audit"
                    try:
                         analysis_results = ai_driver_module.analyze_changes(previous_config, payload.config, analysis_context) # type: ignore
                    except Exception as e:
                        logging.error(f"Best-effort AI analysis failed for auto-audit on {device_id}: {e}")
                        analysis_results = {"summary": "自动审计期间AI分析失败。", "analysis": str(e), "security_risks": "无法评估。"}
                # If mode is 'disabled', analysis_results remains at its default "N/A" value.
            else: # For 'update' and 'rollback'
                if payload.changeType == 'rollback':
                    analysis_context = "rollback"
                # Compliance check runs only for 'update' and if not skipped
                if payload.changeType == 'update' and not skip_compliance_check:
                    compliance_report = ai_driver_module.audit_compliance([p.__dict__ for p in policies_for_audit], previous_config, payload.config) # type: ignore
                
                analysis_results = ai_driver_module.analyze_changes(previous_config, payload.config, analysis_context) # type: ignore

        except HTTPException as e:
            raise e
        except Exception as e:
            logging.error(f"Unexpected AI-phase error for {device_id}: {e}")
            raise HTTPException(status_code=500, detail=f"AI处理阶段发生未知错误: {e}")
    else:
        if not ai_driver_module:
            analysis_results = {"summary": "AI驱动加载失败，分析功能已禁用。"}
        else:
            analysis_results = {"summary": "AI分析功能已禁用。"}

    # --- Block Creation ---
    new_index = last_block.index + 1 if last_block else 0
    timestamp = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    prev_hash = last_block.hash if last_block else "0"
    
    new_block_data: BlockDataDict = {
        "deviceId": device_id, "version": new_index + 1, "operator": payload.operator,
        "config": payload.config, 
        "diff": analysis_results.get("diff", "差异信息不可用。"), 
        "changeType": cast(Any, payload.changeType),
        "summary": analysis_results.get("summary", "摘要信息不可用。"), 
        "analysis": analysis_results.get("analysis"),
        "security_risks": analysis_results.get("security_risks"), 
        "compliance_report": compliance_report,
    }
    
    new_hash = calculate_block_hash(new_block_data, new_index, timestamp, prev_hash)
    new_block: BlockDict = {"index": new_index, "timestamp": timestamp, "data": new_block_data, "prev_hash": prev_hash, "hash": new_hash}

    return crud.add_block(db, device_id, new_block)

async def perform_auto_audit(db: Session, device_id: str):
    """Asynchronous service to perform an auto-audit for a given device."""
    try:
        latest_config_dict = get_running_config(device_id)
        latest_config = latest_config_dict["config"]
        
        loop = asyncio.get_running_loop()
        audit_payload = SubmissionPayload(
            operator="system_auto_audit", 
            config=latest_config, 
            changeType='auto_audit'
        )
        await loop.run_in_executor(
            None, 
            perform_add_block, 
            db, 
            device_id, 
            audit_payload
        )
        crud.log_action(db, "system", f"为设备 '{device_id}' 自动审计了因断开连接而未保存的会话。")
    except Exception as e:
        logging.error(f"Auto-audit failed for device {device_id}: {e}")
        crud.log_action(db, "system", f"为设备 '{device_id}' 尝试自动审计失败: {e}")


def perform_rollback(db: Session, device_id: str, payload: RollbackPayload) -> BlockDict:
    device = crud.get_device_with_details(db, device_id)
    if not device: raise HTTPException(status_code=404, detail=f"未找到设备 ID '{device_id}' 的区块链。")
    
    target_block = next((b for b in device.blocks if json.loads(b.data)['version'] == payload.target_version), None)
    if not target_block: raise HTTPException(status_code=404, detail=f"未找到目标回滚版本 '{payload.target_version}'。")

    target_config = json.loads(target_block.data).get('config', '')
    
    # --- START OF BUG FIX ---
    # Step 1: Push the target configuration to the device first.
    if not is_simulation_mode():
        device_info = get_device_info(device_id)
        if not device_info:
            raise HTTPException(status_code=404, detail=f"在配置文件中未找到设备 '{device_id}' 的连接信息。")
        
        config_commands = target_config.splitlines()
        try:
            logging.info(f"Rollback: Connecting to {device_id} to push target config.")
            with ConnectHandler(**device_info) as net_connect:
                net_connect.enable()
                output = net_connect.send_config_set(config_commands)
                logging.info(f"Rollback: Config push output for {device_id}: {output}")
        except NetmikoBaseException as e:
            logging.error(f"Rollback failed during config push for {device_id}: {e}")
            raise HTTPException(status_code=504, detail=f"回滚失败：推送到设备时出错: {e}")

    # Step 2: Get the REAL, final running config from the device after the push.
    final_config = target_config # Fallback for simulation mode
    if not is_simulation_mode():
        try:
            logging.info(f"Rollback: Fetching final running config from {device_id}.")
            final_config = get_running_config(device_id)["config"]
        except HTTPException as e:
            # If fetching fails, we proceed with target_config but log a warning.
            logging.warning(f"Rollback: Could not fetch final config from {device_id} after push: {e.detail}. Proceeding with target config for record.")
    
    # Step 3: Use the REAL final config to create the block.
    submission_payload = SubmissionPayload(
        operator=payload.operator, 
        config=final_config,  # Use the verified, final config
        changeType='rollback'
    )
    # --- END OF BUG FIX ---
    
    try:
        # This will now analyze the change from the last version to the NEWLY APPLIED version.
        return perform_add_block(db, device_id, submission_payload)
    except HTTPException as e:
        raise HTTPException(status_code=e.status_code, detail=f"记录回滚时出错: {e.detail}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"记录回滚时发生意外错误: {e}")

def perform_pre_deployment_check(db: Session, device_id: str, new_config: str) -> None:
    """
    Performs a pre-deployment compliance check. Raises HTTPException on failure.
    """
    if not ai_driver_module: return # Skip if AI is not loaded

    device = crud.get_device_with_details(db, device_id)
    if not device:
        raise HTTPException(status_code=404, detail=f"Device {device_id} not found for pre-check.")
    
    sorted_blocks = sorted(device.blocks, key=lambda b: b.index)
    last_block = sorted_blocks[-1] if sorted_blocks else None
    previous_config = json.loads(last_block.data).get('config', '') if last_block else ''
    
    policies_for_audit = device.policies
    settings = crud.get_settings_as_dict(db)

    if settings.get("is_ai_analysis_enabled", True):
        ai_driver_module.audit_compliance([p.__dict__ for p in policies_for_audit], previous_config, new_config) # type: ignore